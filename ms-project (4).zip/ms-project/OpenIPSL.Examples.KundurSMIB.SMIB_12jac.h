/* Jacobians */
static const REAL_ATTRIBUTE dummyREAL_ATTRIBUTE = omc_dummyRealAttribute;

#if defined(__cplusplus)
extern "C" {
#endif

/* Jacobian Variables */
#define OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_LSJac6 0
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacLSJac6_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianLSJac6(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_LSJac7 1
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacLSJac7_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianLSJac7(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_H 2
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacH_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianH(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_F 3
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacF_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianF(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_D 4
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacD_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianD(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_C 5
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacC_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianC(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_B 6
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacB_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianB(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_A 7
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacA_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianA(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);

#if defined(__cplusplus)
}
#endif
