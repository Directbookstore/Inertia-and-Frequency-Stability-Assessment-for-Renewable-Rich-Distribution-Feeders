#if defined(__cplusplus)
  extern "C" {
#endif
  int ThesisFreqCases_DroopFFRCase_mayer(DATA* data, modelica_real** res, short*);
  int ThesisFreqCases_DroopFFRCase_lagrange(DATA* data, modelica_real** res, short *, short *);
  int ThesisFreqCases_DroopFFRCase_getInputVarIndicesInOptimization(DATA* data, int* input_var_indices);
  int ThesisFreqCases_DroopFFRCase_pickUpBoundsForInputsInOptimization(DATA* data, modelica_real* min, modelica_real* max, modelica_real*nominal, modelica_boolean *useNominal, char ** name, modelica_real * start, modelica_real * startTimeOpt);
  int ThesisFreqCases_DroopFFRCase_setInputData(DATA *data, const modelica_boolean file);
  int ThesisFreqCases_DroopFFRCase_getTimeGrid(DATA *data, modelica_integer * nsi, modelica_real**t);
#if defined(__cplusplus)
}
#endif
