/* DAE residuals is empty */
#include "ThesisFreqCases.DroopFFRCase_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int ThesisFreqCases_DroopFFRCase_initializeDAEmodeData(DATA* data, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
