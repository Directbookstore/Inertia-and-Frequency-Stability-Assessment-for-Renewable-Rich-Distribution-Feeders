/* Mixed Systems */
#include "ThesisFreqCases.DroopCase_model.h"
#include "ThesisFreqCases.DroopCase_11mix.h"
/* initial mixed systems */
/* initial_lambda0 mixed systems */
/* parameter mixed systems */
/* model mixed systems */
/* jacobians mixed systems */

