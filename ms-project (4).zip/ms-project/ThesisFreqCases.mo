
within ;
package ThesisFreqCases
  partial model BaseFreqCase
    parameter Real f0 = 50 "Nominal frequency (Hz)";
    parameter Real H = 4.0 "Virtual inertia constant (s)";
    parameter Real D = 1.0 "Damping coefficient (pu/Hz)";
    parameter Real R = 0.06 "Droop gain (Hz/pu)";
    parameter Real deadband = 0.02 "Deadband (Hz)";

    // Make FFR faster than droop (to show benefit)
    parameter Real T_droop = 0.30 "Droop measurement/actuation time constant (s)";
    parameter Real T_ffr   = 0.05 "FFR time constant (s)";

    parameter Real PmaxDroop = 0.20 "Droop support cap (pu)";
    parameter Real PmaxFFR = 0.15 "FFR support cap (pu)";
    parameter Real PmaxTotal = 0.30 "Total support cap (pu)";
    parameter Real ffrGain = 1.00 "FFR gain (pu/Hz)";
    parameter Real ffrDuration = 2.0 "FFR duration after event (s)";

    parameter Real tEvent = 1.0 "Disturbance start time (s)";
    parameter Real dPstep = -0.10 "Disturbance (pu), negative = deficit";

    // Fix initial conditions to remove warning
    Real df(start=0, fixed=true) "Frequency deviation (Hz)";
    Real fHz "Frequency (Hz)";
    Real rocofHzps "RoCoF (Hz/s)";

    Real Pdist "Disturbance power (pu)";
    Real Pdroop "Droop support (pu)";
    Real Pffr "FFR support (pu)";
    Real Psupport "Total support (pu)";

  protected
    Real df_droop(start=0, fixed=true);
    Real df_ffr(start=0, fixed=true);
    Real Pdroop_raw;
    Real Pffr_raw;

  equation
    // Disturbance step
    Pdist = if time < tEvent then 0 else dPstep;

    // Filtered measurements
    der(df_droop) = (df - df_droop)/T_droop;
    der(df_ffr)   = (df - df_ffr)/T_ffr;

    // Droop
    Pdroop_raw = if noEvent(abs(df_droop) <= deadband) then 0 else -df_droop / R;
    Pdroop = min(max(Pdroop_raw, -PmaxDroop), PmaxDroop);

    // FFR
    Pffr_raw = if noEvent(time < tEvent or time > tEvent + ffrDuration or abs(df_ffr) <= deadband) then 0 else -ffrGain * df_ffr;
    Pffr = min(max(Pffr_raw, -PmaxFFR), PmaxFFR);

    Psupport = min(max(Pdroop + Pffr, -PmaxTotal), PmaxTotal);

    // Dynamics
    der(df) = (f0 / (2 * H)) * (Pdist + Psupport - D * df);

    // Outputs
    fHz = f0 + df;
    rocofHzps = der(fHz);

    annotation(experiment(StopTime=12, Interval=0.01));
  end BaseFreqCase;

  model BaseCase
    extends BaseFreqCase(
      PmaxDroop=0.0, PmaxFFR=0.0, PmaxTotal=0.0,
      ffrGain=0.0, ffrDuration=0.0
    );
    annotation(experiment(StopTime=12, Interval=0.01));
  end BaseCase;

  model DroopCase
    extends BaseFreqCase(
      PmaxDroop=0.20, PmaxFFR=0.0, PmaxTotal=0.20,
      ffrGain=0.0, ffrDuration=0.0
    );
    annotation(experiment(StopTime=12, Interval=0.01));
  end DroopCase;

  // DroopFFRCase remains defined for readability, but notebook does NOT depend on it compiling.
  model DroopFFRCase
    extends BaseFreqCase(
      PmaxDroop=0.20, PmaxFFR=0.15, PmaxTotal=0.30,
      ffrGain=1.0, ffrDuration=2.0
    );
    annotation(experiment(StopTime=12, Interval=0.01));
  end DroopFFRCase;

end ThesisFreqCases;
