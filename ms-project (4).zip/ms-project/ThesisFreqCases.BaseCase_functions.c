#include "omc_simulation_settings.h"
#include "ThesisFreqCases.BaseCase_functions.h"
#ifdef __cplusplus
extern "C" {
#endif

#include "ThesisFreqCases.BaseCase_includes.h"



#ifdef __cplusplus
}
#endif
