@echo off
SET PATH=;C:/Program Files/OpenModelica1.26.2-64bit/bin/;%PATH%;
SET ERRORLEVEL=
CALL "%CD%/OpenIPSL.Examples.KundurSMIB.SMIB.exe" %*
SET RESULT=%ERRORLEVEL%

EXIT /b %RESULT%
