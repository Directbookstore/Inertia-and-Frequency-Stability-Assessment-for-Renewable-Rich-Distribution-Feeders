#ifndef ThesisFreqCases_DroopCase__H
#define ThesisFreqCases_DroopCase__H
#include "meta/meta_modelica.h"
#include "util/modelica.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include "simulation/simulation_runtime.h"
#ifdef __cplusplus
extern "C" {
#endif


#include "ThesisFreqCases.DroopCase_model.h"


#ifdef __cplusplus
}
#endif
#endif
