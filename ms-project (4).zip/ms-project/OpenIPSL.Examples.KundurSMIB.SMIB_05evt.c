/* Events: Sample, Zero Crossings, Relations, Discrete Changes */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* Initializes the raw time events of the simulation using the now
   calcualted parameters. */
void OpenIPSL_Examples_KundurSMIB_SMIB_function_initSample(DATA *data, threadData_t *threadData)
{
  long i=0;
}

const char *OpenIPSL_Examples_KundurSMIB_SMIB_zeroCrossingDescription(int i, int **out_EquationIndexes)
{
  static const char *res[] = {"time >= line_2.t1 and time < line_2.t2",
  "time >= line_2.t1",
  "time < line_2.t2",
  "time >= line_1.t1 and time < line_1.t2",
  "time < fault.t1",
  "time < fault.t2 and fault.ground",
  "time < fault.t2",
  "time >= line_1.t1",
  "time < line_1.t2"};
  static const int occurEqs0[] = {1,-1};
  static const int occurEqs1[] = {1,-1};
  static const int occurEqs2[] = {1,-1};
  static const int occurEqs3[] = {1,-1};
  static const int occurEqs4[] = {1,-1};
  static const int occurEqs5[] = {1,-1};
  static const int occurEqs6[] = {1,-1};
  static const int occurEqs7[] = {1,-1};
  static const int occurEqs8[] = {1,-1};
  static const int *occurEqs[] = {occurEqs0,occurEqs1,occurEqs2,occurEqs3,occurEqs4,occurEqs5,occurEqs6,occurEqs7,occurEqs8};
  *out_EquationIndexes = (int*) occurEqs[i];
  return res[i];
}

/* forwarded equations */

int OpenIPSL_Examples_KundurSMIB_SMIB_function_ZeroCrossingsEquations(DATA *data, threadData_t *threadData)
{
  data->simulationInfo->callStatistics.functionZeroCrossingsEquations++;

  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_function_ZeroCrossings(DATA *data, threadData_t *threadData, double *gout)
{
  const int *equationIndexes = NULL;

  modelica_boolean tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_boolean tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_boolean tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_boolean tmp9;
  modelica_real tmp10;
  modelica_real tmp11;
  modelica_boolean tmp12;
  modelica_real tmp13;
  modelica_real tmp14;
  modelica_boolean tmp15;
  modelica_real tmp16;
  modelica_real tmp17;
  modelica_boolean tmp18;
  modelica_real tmp19;
  modelica_real tmp20;
  modelica_boolean tmp21;
  modelica_real tmp22;
  modelica_real tmp23;
  modelica_boolean tmp24;
  modelica_real tmp25;
  modelica_real tmp26;
  modelica_boolean tmp27;
  modelica_real tmp28;
  modelica_real tmp29;
  modelica_boolean tmp30;
  modelica_real tmp31;
  modelica_real tmp32;
  modelica_integer current_index = 0;
  modelica_integer start_index;
  
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_ZC);
#endif
  data->simulationInfo->callStatistics.functionZeroCrossings++;

  start_index = current_index;
  tmp1 = 1.0;
  tmp2 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp0 = GreaterEqZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp1, tmp2, data->simulationInfo->storedRelations[0]);
  tmp4 = 1.0;
  tmp5 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  tmp3 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp4, tmp5, data->simulationInfo->storedRelations[1]);
  gout[start_index] = ((tmp0 && tmp3)) ? 1 : -1;
  current_index++;

  start_index = current_index;
  tmp7 = 1.0;
  tmp8 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp6 = GreaterEqZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp7, tmp8, data->simulationInfo->storedRelations[0]);
  gout[start_index] = (tmp6) ? 1 : -1;
  current_index++;

  start_index = current_index;
  tmp10 = 1.0;
  tmp11 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  tmp9 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp10, tmp11, data->simulationInfo->storedRelations[1]);
  gout[start_index] = (tmp9) ? 1 : -1;
  current_index++;

  start_index = current_index;
  tmp13 = 1.0;
  tmp14 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp12 = GreaterEqZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp13, tmp14, data->simulationInfo->storedRelations[2]);
  tmp16 = 1.0;
  tmp17 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  tmp15 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp16, tmp17, data->simulationInfo->storedRelations[3]);
  gout[start_index] = ((tmp12 && tmp15)) ? 1 : -1;
  current_index++;

  start_index = current_index;
  tmp19 = 1.0;
  tmp20 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */));
  tmp18 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */), tmp19, tmp20, data->simulationInfo->storedRelations[4]);
  gout[start_index] = (tmp18) ? 1 : -1;
  current_index++;

  start_index = current_index;
  tmp22 = 1.0;
  tmp23 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
  tmp21 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */), tmp22, tmp23, data->simulationInfo->storedRelations[5]);
  gout[start_index] = ((tmp21 && (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[45]] /* fault.ground PARAM */))) ? 1 : -1;
  current_index++;

  start_index = current_index;
  tmp25 = 1.0;
  tmp26 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
  tmp24 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */), tmp25, tmp26, data->simulationInfo->storedRelations[5]);
  gout[start_index] = (tmp24) ? 1 : -1;
  current_index++;

  start_index = current_index;
  tmp28 = 1.0;
  tmp29 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp27 = GreaterEqZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp28, tmp29, data->simulationInfo->storedRelations[2]);
  gout[start_index] = (tmp27) ? 1 : -1;
  current_index++;

  start_index = current_index;
  tmp31 = 1.0;
  tmp32 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  tmp30 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp31, tmp32, data->simulationInfo->storedRelations[3]);
  gout[start_index] = (tmp30) ? 1 : -1;
  current_index++;

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_ZC);
#endif

  return 0;
}

const char *OpenIPSL_Examples_KundurSMIB_SMIB_relationDescription(int i)
{
  const char *res[] = {"time >= line_2.t1",
  "time < line_2.t2",
  "time >= line_1.t1",
  "time < line_1.t2",
  "time < fault.t1",
  "time < fault.t2"};
  return res[i];
}

int OpenIPSL_Examples_KundurSMIB_SMIB_function_updateRelations(DATA *data, threadData_t *threadData, int evalforZeroCross)
{
  const int *equationIndexes = NULL;

  modelica_boolean tmp33;
  modelica_real tmp34;
  modelica_real tmp35;
  modelica_boolean tmp36;
  modelica_real tmp37;
  modelica_real tmp38;
  modelica_boolean tmp39;
  modelica_real tmp40;
  modelica_real tmp41;
  modelica_boolean tmp42;
  modelica_real tmp43;
  modelica_real tmp44;
  modelica_boolean tmp45;
  modelica_real tmp46;
  modelica_real tmp47;
  modelica_boolean tmp48;
  modelica_real tmp49;
  modelica_real tmp50;
  modelica_integer current_index = 0;
  modelica_integer start_index;
  
  if(evalforZeroCross) {
    start_index = current_index;
    tmp34 = 1.0;
    tmp35 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
    tmp33 = GreaterEqZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp34, tmp35, data->simulationInfo->storedRelations[0]);
    data->simulationInfo->relations[start_index] = tmp33;
    current_index++;

    start_index = current_index;
    tmp37 = 1.0;
    tmp38 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
    tmp36 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp37, tmp38, data->simulationInfo->storedRelations[1]);
    data->simulationInfo->relations[start_index] = tmp36;
    current_index++;

    start_index = current_index;
    tmp40 = 1.0;
    tmp41 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
    tmp39 = GreaterEqZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp40, tmp41, data->simulationInfo->storedRelations[2]);
    data->simulationInfo->relations[start_index] = tmp39;
    current_index++;

    start_index = current_index;
    tmp43 = 1.0;
    tmp44 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
    tmp42 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp43, tmp44, data->simulationInfo->storedRelations[3]);
    data->simulationInfo->relations[start_index] = tmp42;
    current_index++;

    start_index = current_index;
    tmp46 = 1.0;
    tmp47 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */));
    tmp45 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */), tmp46, tmp47, data->simulationInfo->storedRelations[4]);
    data->simulationInfo->relations[start_index] = tmp45;
    current_index++;

    start_index = current_index;
    tmp49 = 1.0;
    tmp50 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
    tmp48 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */), tmp49, tmp50, data->simulationInfo->storedRelations[5]);
    data->simulationInfo->relations[start_index] = tmp48;
    current_index++;
  } else {
    start_index = current_index;
    data->simulationInfo->relations[start_index] = (data->localData[0]->timeValue >= (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
    current_index++;

    start_index = current_index;
    data->simulationInfo->relations[start_index] = (data->localData[0]->timeValue < (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
    current_index++;

    start_index = current_index;
    data->simulationInfo->relations[start_index] = (data->localData[0]->timeValue >= (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
    current_index++;

    start_index = current_index;
    data->simulationInfo->relations[start_index] = (data->localData[0]->timeValue < (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
    current_index++;

    start_index = current_index;
    data->simulationInfo->relations[start_index] = (data->localData[0]->timeValue < (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */));
    current_index++;

    start_index = current_index;
    data->simulationInfo->relations[start_index] = (data->localData[0]->timeValue < (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
    current_index++;
  }
  
  return 0;
}

#if defined(__cplusplus)
}
#endif
