/* Linear Systems */
#include "ThesisFreqCases.BaseCase_model.h"
#include "ThesisFreqCases.BaseCase_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* linear systems */


#if defined(__cplusplus)
}
#endif
