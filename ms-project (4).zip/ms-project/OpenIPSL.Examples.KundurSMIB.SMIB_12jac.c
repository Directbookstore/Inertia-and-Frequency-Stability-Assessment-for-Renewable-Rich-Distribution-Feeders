/* Jacobians 8 */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#include "OpenIPSL.Examples.KundurSMIB.SMIB_12jac.h"
#include "simulation/jacobian_util.h"
#include "util/omc_file.h"
/* constant equations */
/* dynamic equations */

/*
equation index: 67
type: SIMPLE_ASSIGN
$cse1 = sin(G1.machine.delta)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_67(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 0;
  const int equationIndexes[2] = {1,67};
  jacobian->tmpVars[1] /* $cse1 JACOBIAN_TMP_VAR */ = sin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */));
  threadData->lastEquationSolved = 67;
}

/*
equation index: 68
type: SIMPLE_ASSIGN
$cse2 = cos(G1.machine.delta)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_68(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 1;
  const int equationIndexes[2] = {1,68};
  jacobian->tmpVars[0] /* $cse2 JACOBIAN_TMP_VAR */ = cos((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */));
  threadData->lastEquationSolved = 68;
}

/*
equation index: 69
type: SIMPLE_ASSIGN
G1.machine.e1d.$pDERLSJac6.dummyVarLSJac6 = G1.machine.iq.SeedLSJac6 * (G1.machine.xq + (-G1.machine.x1q) - G1.machine.T2q0 * G1.machine.x2q * (G1.machine.xq - G1.machine.x1q) / (G1.machine.T1q0 * G1.machine.x1q))
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_69(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 2;
  const int equationIndexes[2] = {1,69};
  jacobian->tmpVars[2] /* G1.machine.e1d.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = (jacobian->seedVars[6] /* G1.machine.iq.SeedLSJac6 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */) + (-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[46]] /* G1.machine.T2q0 PARAM */)) * (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * (DIVISION((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */),((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[44]] /* G1.machine.T1q0 PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */)),"G1.machine.T1q0 * G1.machine.x1q")))));
  threadData->lastEquationSolved = 69;
}

/*
equation index: 70
type: SIMPLE_ASSIGN
G1.machine.e2d.$pDERLSJac6.dummyVarLSJac6 = (G1.machine.x1q + G1.machine.T2q0 * G1.machine.x2q * (G1.machine.xq - G1.machine.x1q) / (G1.machine.T1q0 * G1.machine.x1q) - G1.machine.x2q) * G1.machine.iq.SeedLSJac6 + G1.machine.e1d.$pDERLSJac6.dummyVarLSJac6
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_70(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 3;
  const int equationIndexes[2] = {1,70};
  jacobian->tmpVars[3] /* G1.machine.e2d.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[46]] /* G1.machine.T2q0 PARAM */)) * (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * (DIVISION((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */),((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[44]] /* G1.machine.T1q0 PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */)),"G1.machine.T1q0 * G1.machine.x1q"))) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * (jacobian->seedVars[6] /* G1.machine.iq.SeedLSJac6 SEED_VAR */) + jacobian->tmpVars[2] /* G1.machine.e1d.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */;
  threadData->lastEquationSolved = 70;
}

/*
equation index: 71
type: SIMPLE_ASSIGN
transformer.is.im.$pDERLSJac6.dummyVarLSJac6 = ($cse1 * G1.machine.iq.SeedLSJac6 - $cse2 * G1.machine.id.SeedLSJac6) * G1.machine.I_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_71(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 4;
  const int equationIndexes[2] = {1,71};
  jacobian->tmpVars[4] /* transformer.is.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = ((jacobian->tmpVars[1] /* $cse1 JACOBIAN_TMP_VAR */) * (jacobian->seedVars[6] /* G1.machine.iq.SeedLSJac6 SEED_VAR */) - ((jacobian->tmpVars[0] /* $cse2 JACOBIAN_TMP_VAR */) * (jacobian->seedVars[5] /* G1.machine.id.SeedLSJac6 SEED_VAR */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */));
  threadData->lastEquationSolved = 71;
}

/*
equation index: 72
type: SIMPLE_ASSIGN
transformer.is.re.$pDERLSJac6.dummyVarLSJac6 = ($cse2 * G1.machine.iq.SeedLSJac6 + $cse1 * G1.machine.id.SeedLSJac6) * G1.machine.I_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_72(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 5;
  const int equationIndexes[2] = {1,72};
  jacobian->tmpVars[5] /* transformer.is.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = ((jacobian->tmpVars[0] /* $cse2 JACOBIAN_TMP_VAR */) * (jacobian->seedVars[6] /* G1.machine.iq.SeedLSJac6 SEED_VAR */) + (jacobian->tmpVars[1] /* $cse1 JACOBIAN_TMP_VAR */) * (jacobian->seedVars[5] /* G1.machine.id.SeedLSJac6 SEED_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */));
  threadData->lastEquationSolved = 72;
}

/*
equation index: 73
type: SIMPLE_ASSIGN
G1.machine.vd.$pDERLSJac6.dummyVarLSJac6 = G1.machine.e2d.$pDERLSJac6.dummyVarLSJac6 - (G1.machine.ra * G1.machine.id.SeedLSJac6 - G1.machine.x2q * G1.machine.iq.SeedLSJac6)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_73(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 6;
  const int equationIndexes[2] = {1,73};
  jacobian->tmpVars[6] /* G1.machine.vd.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = jacobian->tmpVars[3] /* G1.machine.e2d.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * (jacobian->seedVars[5] /* G1.machine.id.SeedLSJac6 SEED_VAR */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * (jacobian->seedVars[6] /* G1.machine.iq.SeedLSJac6 SEED_VAR */)));
  threadData->lastEquationSolved = 73;
}

/*
equation index: 74
type: SIMPLE_ASSIGN
G1.machine.vq.$pDERLSJac6.dummyVarLSJac6 = (-G1.machine.ra) * G1.machine.iq.SeedLSJac6 - G1.machine.x2d * G1.machine.id.SeedLSJac6
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_74(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 7;
  const int equationIndexes[2] = {1,74};
  jacobian->tmpVars[7] /* G1.machine.vq.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = ((-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */))) * (jacobian->seedVars[6] /* G1.machine.iq.SeedLSJac6 SEED_VAR */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[80]] /* G1.machine.x2d PARAM */)) * (jacobian->seedVars[5] /* G1.machine.id.SeedLSJac6 SEED_VAR */));
  threadData->lastEquationSolved = 74;
}

/*
equation index: 75
type: SIMPLE_ASSIGN
transformer.vs.re.$pDERLSJac6.dummyVarLSJac6 = ($cse1 * G1.machine.vd.$pDERLSJac6.dummyVarLSJac6 + $cse2 * G1.machine.vq.$pDERLSJac6.dummyVarLSJac6) * G1.machine.V_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_75(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 8;
  const int equationIndexes[2] = {1,75};
  jacobian->tmpVars[8] /* transformer.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = ((jacobian->tmpVars[1] /* $cse1 JACOBIAN_TMP_VAR */) * (jacobian->tmpVars[6] /* G1.machine.vd.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) + (jacobian->tmpVars[0] /* $cse2 JACOBIAN_TMP_VAR */) * (jacobian->tmpVars[7] /* G1.machine.vq.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */));
  threadData->lastEquationSolved = 75;
}

/*
equation index: 76
type: SIMPLE_ASSIGN
line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 = (transformer.vs.re.$pDERLSJac6.dummyVarLSJac6 / transformer.m ^ 2.0 - (transformer.r * transformer.is.re.$pDERLSJac6.dummyVarLSJac6 - transformer.x * transformer.is.im.$pDERLSJac6.dummyVarLSJac6)) * transformer.m
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_76(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 9;
  const int equationIndexes[2] = {1,76};
  modelica_real tmp0;
  tmp0 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */);
  jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = (DIVISION(jacobian->tmpVars[8] /* transformer.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */,(tmp0 * tmp0),"transformer.m ^ 2.0") - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * (jacobian->tmpVars[5] /* transformer.is.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * (jacobian->tmpVars[4] /* transformer.is.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */));
  threadData->lastEquationSolved = 76;
}

/*
equation index: 77
type: SIMPLE_ASSIGN
transformer.vs.im.$pDERLSJac6.dummyVarLSJac6 = ($cse1 * G1.machine.vq.$pDERLSJac6.dummyVarLSJac6 - $cse2 * G1.machine.vd.$pDERLSJac6.dummyVarLSJac6) * G1.machine.V_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_77(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 10;
  const int equationIndexes[2] = {1,77};
  jacobian->tmpVars[10] /* transformer.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = ((jacobian->tmpVars[1] /* $cse1 JACOBIAN_TMP_VAR */) * (jacobian->tmpVars[7] /* G1.machine.vq.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) - ((jacobian->tmpVars[0] /* $cse2 JACOBIAN_TMP_VAR */) * (jacobian->tmpVars[6] /* G1.machine.vd.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */));
  threadData->lastEquationSolved = 77;
}

/*
equation index: 78
type: SIMPLE_ASSIGN
line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 = (transformer.vs.im.$pDERLSJac6.dummyVarLSJac6 / transformer.m ^ 2.0 - (transformer.r * transformer.is.im.$pDERLSJac6.dummyVarLSJac6 + transformer.x * transformer.is.re.$pDERLSJac6.dummyVarLSJac6)) * transformer.m
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_78(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 11;
  const int equationIndexes[2] = {1,78};
  modelica_real tmp1;
  tmp1 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */);
  jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = (DIVISION(jacobian->tmpVars[10] /* transformer.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */,(tmp1 * tmp1),"transformer.m ^ 2.0") - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * (jacobian->tmpVars[4] /* transformer.is.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * (jacobian->tmpVars[5] /* transformer.is.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */));
  threadData->lastEquationSolved = 78;
}

/*
equation index: 79
type: SIMPLE_ASSIGN
transformer.ir.re.$pDERLSJac6.dummyVarLSJac6 = (line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 - transformer.vs.im.$pDERLSJac6.dummyVarLSJac6 / transformer.m - transformer.r * transformer.ir.im.SeedLSJac6) / transformer.x
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_79(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 12;
  const int equationIndexes[2] = {1,79};
  jacobian->tmpVars[12] /* transformer.ir.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = DIVISION(jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ - (DIVISION(jacobian->tmpVars[10] /* transformer.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */),"transformer.m")) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * (jacobian->seedVars[4] /* transformer.ir.im.SeedLSJac6 SEED_VAR */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */),"transformer.x");
  threadData->lastEquationSolved = 79;
}

/*
equation index: 80
type: SIMPLE_ASSIGN
fault.p.ii.$pDERLSJac6.dummyVarLSJac6 = (-line_2.is.im.SeedLSJac6) - line_1.is.im.SeedLSJac6 - transformer.ir.im.SeedLSJac6
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_80(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 13;
  const int equationIndexes[2] = {1,80};
  jacobian->tmpVars[13] /* fault.p.ii.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = (-jacobian->seedVars[2] /* line_2.is.im.SeedLSJac6 SEED_VAR */) - jacobian->seedVars[3] /* line_1.is.im.SeedLSJac6 SEED_VAR */ - jacobian->seedVars[4] /* transformer.ir.im.SeedLSJac6 SEED_VAR */;
  threadData->lastEquationSolved = 80;
}

/*
equation index: 81
type: SIMPLE_ASSIGN
fault.p.ir.$pDERLSJac6.dummyVarLSJac6 = (-line_2.is.re.SeedLSJac6) - line_1.is.re.SeedLSJac6 - transformer.ir.re.$pDERLSJac6.dummyVarLSJac6
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_81(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 14;
  const int equationIndexes[2] = {1,81};
  jacobian->tmpVars[14] /* fault.p.ir.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ = (-jacobian->seedVars[1] /* line_2.is.re.SeedLSJac6 SEED_VAR */) - jacobian->seedVars[0] /* line_1.is.re.SeedLSJac6 SEED_VAR */ - jacobian->tmpVars[12] /* transformer.ir.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */;
  threadData->lastEquationSolved = 81;
}

/*
equation index: 82
type: SIMPLE_ASSIGN
$res_LSJac6_1.$pDERLSJac6.dummyVarLSJac6 = if time < fault.t1 then fault.p.ii.$pDERLSJac6.dummyVarLSJac6 else if time < fault.t2 and fault.ground then line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 else if time < fault.t2 then fault.p.ii.$pDERLSJac6.dummyVarLSJac6 - (fault.R * line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 - fault.X * line_2.vs.re.$pDERLSJac6.dummyVarLSJac6) * (fault.X ^ 2.0 + fault.R ^ 2.0) / (fault.X ^ 2.0 + fault.R ^ 2.0) ^ 2.0 else fault.p.ii.$pDERLSJac6.dummyVarLSJac6
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_82(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 15;
  const int equationIndexes[2] = {1,82};
  modelica_boolean tmp2;
  modelica_boolean tmp3;
  modelica_boolean tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  modelica_boolean tmp10;
  modelica_real tmp11;
  modelica_boolean tmp12;
  modelica_real tmp13;
  modelica_boolean tmp14;
  modelica_real tmp15;
  tmp2 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */));
  tmp14 = (modelica_boolean)tmp2;
  if(tmp14)
  {
    tmp15 = jacobian->tmpVars[13] /* fault.p.ii.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */;
  }
  else
  {
    tmp3 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
    tmp12 = (modelica_boolean)(tmp3 && (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[45]] /* fault.ground PARAM */));
    if(tmp12)
    {
      tmp13 = jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */;
    }
    else
    {
      tmp4 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
      tmp10 = (modelica_boolean)tmp4;
      if(tmp10)
      {
        tmp5 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp6 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp7 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp8 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp9 = (tmp7 * tmp7) + (tmp8 * tmp8);
        tmp11 = jacobian->tmpVars[13] /* fault.p.ii.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ - (DIVISION((((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */)) * (jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */)) * (jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */))) * ((tmp5 * tmp5) + (tmp6 * tmp6)),(tmp9 * tmp9),"(fault.X ^ 2.0 + fault.R ^ 2.0) ^ 2.0"));
      }
      else
      {
        tmp11 = jacobian->tmpVars[13] /* fault.p.ii.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */;
      }
      tmp13 = tmp11;
    }
    tmp15 = tmp13;
  }
  jacobian->resultVars[0] /* $res_LSJac6_1.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_VAR */ = tmp15;
  threadData->lastEquationSolved = 82;
}

/*
equation index: 83
type: SIMPLE_ASSIGN
$res_LSJac6_2.$pDERLSJac6.dummyVarLSJac6 = if time < fault.t1 then fault.p.ir.$pDERLSJac6.dummyVarLSJac6 else if time < fault.t2 and fault.ground then line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 else if time < fault.t2 then fault.p.ir.$pDERLSJac6.dummyVarLSJac6 - (fault.R * line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 + fault.X * line_2.vs.im.$pDERLSJac6.dummyVarLSJac6) * (fault.R ^ 2.0 + fault.X ^ 2.0) / (fault.R ^ 2.0 + fault.X ^ 2.0) ^ 2.0 else fault.p.ir.$pDERLSJac6.dummyVarLSJac6
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_83(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 16;
  const int equationIndexes[2] = {1,83};
  modelica_boolean tmp16;
  modelica_boolean tmp17;
  modelica_boolean tmp18;
  modelica_real tmp19;
  modelica_real tmp20;
  modelica_real tmp21;
  modelica_real tmp22;
  modelica_real tmp23;
  modelica_boolean tmp24;
  modelica_real tmp25;
  modelica_boolean tmp26;
  modelica_real tmp27;
  modelica_boolean tmp28;
  modelica_real tmp29;
  tmp16 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */));
  tmp28 = (modelica_boolean)tmp16;
  if(tmp28)
  {
    tmp29 = jacobian->tmpVars[14] /* fault.p.ir.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */;
  }
  else
  {
    tmp17 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
    tmp26 = (modelica_boolean)(tmp17 && (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[45]] /* fault.ground PARAM */));
    if(tmp26)
    {
      tmp27 = jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */;
    }
    else
    {
      tmp18 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
      tmp24 = (modelica_boolean)tmp18;
      if(tmp24)
      {
        tmp19 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp20 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp21 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp22 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp23 = (tmp21 * tmp21) + (tmp22 * tmp22);
        tmp25 = jacobian->tmpVars[14] /* fault.p.ir.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ - (DIVISION((((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */)) * (jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */)) * (jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */)) * ((tmp19 * tmp19) + (tmp20 * tmp20)),(tmp23 * tmp23),"(fault.R ^ 2.0 + fault.X ^ 2.0) ^ 2.0"));
      }
      else
      {
        tmp25 = jacobian->tmpVars[14] /* fault.p.ir.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */;
      }
      tmp27 = tmp25;
    }
    tmp29 = tmp27;
  }
  jacobian->resultVars[1] /* $res_LSJac6_2.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_VAR */ = tmp29;
  threadData->lastEquationSolved = 83;
}

/*
equation index: 84
type: SIMPLE_ASSIGN
$res_LSJac6_3.$pDERLSJac6.dummyVarLSJac6 = if time >= line_1.t1 and time < line_1.t2 then line_1.is.re.SeedLSJac6 else line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 - (line_1.Z.re * (line_1.is.re.SeedLSJac6 + line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 * line_1.Y.im - line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 * line_1.Y.re) - line_1.Z.im * (line_1.is.im.SeedLSJac6 + (-line_2.vs.re.$pDERLSJac6.dummyVarLSJac6) * line_1.Y.im - line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 * line_1.Y.re))
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_84(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 17;
  const int equationIndexes[2] = {1,84};
  modelica_boolean tmp30;
  modelica_boolean tmp31;
  tmp30 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp31 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  jacobian->resultVars[2] /* $res_LSJac6_3.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_VAR */ = ((tmp30 && tmp31)?jacobian->seedVars[0] /* line_1.is.re.SeedLSJac6 SEED_VAR */:jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * (jacobian->seedVars[0] /* line_1.is.re.SeedLSJac6 SEED_VAR */ + (jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - ((jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * (jacobian->seedVars[3] /* line_1.is.im.SeedLSJac6 SEED_VAR */ + ((-jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - ((jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))))));
  threadData->lastEquationSolved = 84;
}

/*
equation index: 85
type: SIMPLE_ASSIGN
$res_LSJac6_4.$pDERLSJac6.dummyVarLSJac6 = if time >= line_2.t1 and time < line_2.t2 then line_2.is.re.SeedLSJac6 else line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 - (line_2.Z.re * (line_2.is.re.SeedLSJac6 + line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 * line_2.Y.im - line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 * line_2.Y.re) - line_2.Z.im * (line_2.is.im.SeedLSJac6 + (-line_2.vs.re.$pDERLSJac6.dummyVarLSJac6) * line_2.Y.im - line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 * line_2.Y.re))
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_85(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 18;
  const int equationIndexes[2] = {1,85};
  modelica_boolean tmp32;
  modelica_boolean tmp33;
  tmp32 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp33 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  jacobian->resultVars[3] /* $res_LSJac6_4.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_VAR */ = ((tmp32 && tmp33)?jacobian->seedVars[1] /* line_2.is.re.SeedLSJac6 SEED_VAR */:jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * (jacobian->seedVars[1] /* line_2.is.re.SeedLSJac6 SEED_VAR */ + (jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - ((jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * (jacobian->seedVars[2] /* line_2.is.im.SeedLSJac6 SEED_VAR */ + ((-jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - ((jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))))));
  threadData->lastEquationSolved = 85;
}

/*
equation index: 86
type: SIMPLE_ASSIGN
$res_LSJac6_5.$pDERLSJac6.dummyVarLSJac6 = line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 * transformer.m + transformer.x * transformer.ir.im.SeedLSJac6 * transformer.m + (-transformer.r) * transformer.ir.re.$pDERLSJac6.dummyVarLSJac6 * transformer.m - transformer.vs.re.$pDERLSJac6.dummyVarLSJac6
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_86(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 19;
  const int equationIndexes[2] = {1,86};
  jacobian->resultVars[4] /* $res_LSJac6_5.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_VAR */ = (jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * ((jacobian->seedVars[4] /* transformer.ir.im.SeedLSJac6 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */))) + ((-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */))) * ((jacobian->tmpVars[12] /* transformer.ir.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */))) - jacobian->tmpVars[8] /* transformer.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */;
  threadData->lastEquationSolved = 86;
}

/*
equation index: 87
type: SIMPLE_ASSIGN
$res_LSJac6_6.$pDERLSJac6.dummyVarLSJac6 = if time >= line_2.t1 and time < line_2.t2 then line_2.is.im.SeedLSJac6 else line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 - (line_2.Z.re * (line_2.is.im.SeedLSJac6 + (-line_2.vs.re.$pDERLSJac6.dummyVarLSJac6) * line_2.Y.im - line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 * line_2.Y.re) + line_2.Z.im * (line_2.is.re.SeedLSJac6 + line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 * line_2.Y.im - line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 * line_2.Y.re))
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_87(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 20;
  const int equationIndexes[2] = {1,87};
  modelica_boolean tmp34;
  modelica_boolean tmp35;
  tmp34 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp35 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  jacobian->resultVars[5] /* $res_LSJac6_6.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_VAR */ = ((tmp34 && tmp35)?jacobian->seedVars[2] /* line_2.is.im.SeedLSJac6 SEED_VAR */:jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * (jacobian->seedVars[2] /* line_2.is.im.SeedLSJac6 SEED_VAR */ + ((-jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - ((jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * (jacobian->seedVars[1] /* line_2.is.re.SeedLSJac6 SEED_VAR */ + (jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - ((jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */))))));
  threadData->lastEquationSolved = 87;
}

/*
equation index: 88
type: SIMPLE_ASSIGN
$res_LSJac6_7.$pDERLSJac6.dummyVarLSJac6 = if time >= line_1.t1 and time < line_1.t2 then line_1.is.im.SeedLSJac6 else line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 - (line_1.Z.re * (line_1.is.im.SeedLSJac6 + (-line_2.vs.re.$pDERLSJac6.dummyVarLSJac6) * line_1.Y.im - line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 * line_1.Y.re) + line_1.Z.im * (line_1.is.re.SeedLSJac6 + line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 * line_1.Y.im - line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 * line_1.Y.re))
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_88(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 21;
  const int equationIndexes[2] = {1,88};
  modelica_boolean tmp36;
  modelica_boolean tmp37;
  tmp36 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp37 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  jacobian->resultVars[6] /* $res_LSJac6_7.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_VAR */ = ((tmp36 && tmp37)?jacobian->seedVars[3] /* line_1.is.im.SeedLSJac6 SEED_VAR */:jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */ - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * (jacobian->seedVars[3] /* line_1.is.im.SeedLSJac6 SEED_VAR */ + ((-jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - ((jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * (jacobian->seedVars[0] /* line_1.is.re.SeedLSJac6 SEED_VAR */ + (jacobian->tmpVars[11] /* line_2.vs.im.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - ((jacobian->tmpVars[9] /* line_2.vs.re.$pDERLSJac6.dummyVarLSJac6 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */))))));
  threadData->lastEquationSolved = 88;
}

OMC_DISABLE_OPT
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacLSJac6_constantEqns(DATA* data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  int index = OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_LSJac6;
  
  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacLSJac6_column(DATA* data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  int index = OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_LSJac6;
  
  static void (*const eqFunctions[22])(DATA*, threadData_t*, JACOBIAN*, JACOBIAN*) = {
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_67,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_68,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_69,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_70,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_71,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_72,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_73,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_74,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_75,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_76,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_77,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_78,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_79,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_80,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_81,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_82,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_83,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_84,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_85,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_86,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_87,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_88
  };
  
  for (int id = 0; id < 22; id++) {
    eqFunctions[id](data, threadData, jacobian, parentJacobian);
  }
  
  return 0;
}
/* constant equations */
/* dynamic equations */

/*
equation index: 153
type: SIMPLE_ASSIGN
transformer.is.re.$pDERLSJac7.dummyVarLSJac7 = ($cse4 * G1.machine.iq.SeedLSJac7 + $cse3 * G1.machine.id.SeedLSJac7) * G1.machine.I_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_153(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 0;
  const int equationIndexes[2] = {1,153};
  jacobian->tmpVars[0] /* transformer.is.re.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */ = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* $cse4 variable */)) * (jacobian->seedVars[6] /* G1.machine.iq.SeedLSJac7 SEED_VAR */) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* $cse3 variable */)) * (jacobian->seedVars[5] /* G1.machine.id.SeedLSJac7 SEED_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */));
  threadData->lastEquationSolved = 153;
}

/*
equation index: 154
type: SIMPLE_ASSIGN
transformer.is.im.$pDERLSJac7.dummyVarLSJac7 = ($cse3 * G1.machine.iq.SeedLSJac7 - $cse4 * G1.machine.id.SeedLSJac7) * G1.machine.I_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_154(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 1;
  const int equationIndexes[2] = {1,154};
  jacobian->tmpVars[1] /* transformer.is.im.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */ = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* $cse3 variable */)) * (jacobian->seedVars[6] /* G1.machine.iq.SeedLSJac7 SEED_VAR */) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* $cse4 variable */)) * (jacobian->seedVars[5] /* G1.machine.id.SeedLSJac7 SEED_VAR */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */));
  threadData->lastEquationSolved = 154;
}

/*
equation index: 155
type: SIMPLE_ASSIGN
transformer.vs.re.$pDERLSJac7.dummyVarLSJac7 = (transformer.r * transformer.is.re.$pDERLSJac7.dummyVarLSJac7 - transformer.x * transformer.is.im.$pDERLSJac7.dummyVarLSJac7 + line_2.vs.re.SeedLSJac7 / transformer.m) * transformer.m ^ 2.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_155(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 2;
  const int equationIndexes[2] = {1,155};
  modelica_real tmp38;
  tmp38 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */);
  jacobian->tmpVars[2] /* transformer.vs.re.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */ = (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * (jacobian->tmpVars[0] /* transformer.is.re.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * (jacobian->tmpVars[1] /* transformer.is.im.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */)) + DIVISION(jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */),"transformer.m")) * ((tmp38 * tmp38));
  threadData->lastEquationSolved = 155;
}

/*
equation index: 156
type: SIMPLE_ASSIGN
transformer.vs.im.$pDERLSJac7.dummyVarLSJac7 = (transformer.r * transformer.is.im.$pDERLSJac7.dummyVarLSJac7 + transformer.x * transformer.is.re.$pDERLSJac7.dummyVarLSJac7 + line_2.vs.im.SeedLSJac7 / transformer.m) * transformer.m ^ 2.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_156(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 3;
  const int equationIndexes[2] = {1,156};
  modelica_real tmp39;
  tmp39 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */);
  jacobian->tmpVars[3] /* transformer.vs.im.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */ = (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * (jacobian->tmpVars[1] /* transformer.is.im.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * (jacobian->tmpVars[0] /* transformer.is.re.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */) + DIVISION(jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */),"transformer.m")) * ((tmp39 * tmp39));
  threadData->lastEquationSolved = 156;
}

/*
equation index: 157
type: SIMPLE_ASSIGN
G1.machine.vd.$pDERLSJac7.dummyVarLSJac7 = G1.machine.x2q * G1.machine.iq.SeedLSJac7 - G1.machine.ra * G1.machine.id.SeedLSJac7
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_157(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 4;
  const int equationIndexes[2] = {1,157};
  jacobian->tmpVars[4] /* G1.machine.vd.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */ = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * (jacobian->seedVars[6] /* G1.machine.iq.SeedLSJac7 SEED_VAR */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * (jacobian->seedVars[5] /* G1.machine.id.SeedLSJac7 SEED_VAR */));
  threadData->lastEquationSolved = 157;
}

/*
equation index: 158
type: SIMPLE_ASSIGN
G1.machine.vq.$pDERLSJac7.dummyVarLSJac7 = (-G1.machine.ra) * G1.machine.iq.SeedLSJac7 - G1.machine.x2d * G1.machine.id.SeedLSJac7
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_158(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 5;
  const int equationIndexes[2] = {1,158};
  jacobian->tmpVars[5] /* G1.machine.vq.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */ = ((-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */))) * (jacobian->seedVars[6] /* G1.machine.iq.SeedLSJac7 SEED_VAR */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[80]] /* G1.machine.x2d PARAM */)) * (jacobian->seedVars[5] /* G1.machine.id.SeedLSJac7 SEED_VAR */));
  threadData->lastEquationSolved = 158;
}

/*
equation index: 159
type: SIMPLE_ASSIGN
transformer.ir.re.$pDERLSJac7.dummyVarLSJac7 = (line_2.vs.im.SeedLSJac7 - transformer.vs.im.$pDERLSJac7.dummyVarLSJac7 / transformer.m - transformer.r * transformer.ir.im.SeedLSJac7) / transformer.x
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_159(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 6;
  const int equationIndexes[2] = {1,159};
  jacobian->tmpVars[6] /* transformer.ir.re.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */ = DIVISION(jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */ - (DIVISION(jacobian->tmpVars[3] /* transformer.vs.im.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */),"transformer.m")) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * (jacobian->seedVars[4] /* transformer.ir.im.SeedLSJac7 SEED_VAR */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */),"transformer.x");
  threadData->lastEquationSolved = 159;
}

/*
equation index: 160
type: SIMPLE_ASSIGN
fault.p.ii.$pDERLSJac7.dummyVarLSJac7 = (-line_2.is.im.SeedLSJac7) - line_1.is.im.SeedLSJac7 - transformer.ir.im.SeedLSJac7
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_160(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 7;
  const int equationIndexes[2] = {1,160};
  jacobian->tmpVars[7] /* fault.p.ii.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */ = (-jacobian->seedVars[3] /* line_2.is.im.SeedLSJac7 SEED_VAR */) - jacobian->seedVars[2] /* line_1.is.im.SeedLSJac7 SEED_VAR */ - jacobian->seedVars[4] /* transformer.ir.im.SeedLSJac7 SEED_VAR */;
  threadData->lastEquationSolved = 160;
}

/*
equation index: 161
type: SIMPLE_ASSIGN
fault.p.ir.$pDERLSJac7.dummyVarLSJac7 = (-line_2.is.re.SeedLSJac7) - line_1.is.re.SeedLSJac7 - transformer.ir.re.$pDERLSJac7.dummyVarLSJac7
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_161(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 8;
  const int equationIndexes[2] = {1,161};
  jacobian->tmpVars[8] /* fault.p.ir.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */ = (-jacobian->seedVars[1] /* line_2.is.re.SeedLSJac7 SEED_VAR */) - jacobian->seedVars[0] /* line_1.is.re.SeedLSJac7 SEED_VAR */ - jacobian->tmpVars[6] /* transformer.ir.re.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */;
  threadData->lastEquationSolved = 161;
}

/*
equation index: 162
type: SIMPLE_ASSIGN
$res_LSJac7_1.$pDERLSJac7.dummyVarLSJac7 = line_2.vs.re.SeedLSJac7 * transformer.m + transformer.x * transformer.ir.im.SeedLSJac7 * transformer.m + (-transformer.r) * transformer.ir.re.$pDERLSJac7.dummyVarLSJac7 * transformer.m - transformer.vs.re.$pDERLSJac7.dummyVarLSJac7
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_162(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 9;
  const int equationIndexes[2] = {1,162};
  jacobian->resultVars[0] /* $res_LSJac7_1.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_VAR */ = (jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * ((jacobian->seedVars[4] /* transformer.ir.im.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */))) + ((-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */))) * ((jacobian->tmpVars[6] /* transformer.ir.re.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */))) - jacobian->tmpVars[2] /* transformer.vs.re.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */;
  threadData->lastEquationSolved = 162;
}

/*
equation index: 163
type: SIMPLE_ASSIGN
$res_LSJac7_2.$pDERLSJac7.dummyVarLSJac7 = if time >= line_2.t1 and time < line_2.t2 then line_2.is.re.SeedLSJac7 else line_2.vs.re.SeedLSJac7 - (line_2.Z.re * (line_2.is.re.SeedLSJac7 + line_2.vs.im.SeedLSJac7 * line_2.Y.im - line_2.vs.re.SeedLSJac7 * line_2.Y.re) - line_2.Z.im * (line_2.is.im.SeedLSJac7 + (-line_2.vs.re.SeedLSJac7) * line_2.Y.im - line_2.vs.im.SeedLSJac7 * line_2.Y.re))
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_163(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 10;
  const int equationIndexes[2] = {1,163};
  modelica_boolean tmp40;
  modelica_real tmp41;
  modelica_real tmp42;
  modelica_boolean tmp43;
  modelica_real tmp44;
  modelica_real tmp45;
  tmp41 = 1.0;
  tmp42 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  relationhysteresis(data, &tmp40, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp41, tmp42, 0, GreaterEq, GreaterEqZC);
  tmp44 = 1.0;
  tmp45 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  relationhysteresis(data, &tmp43, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp44, tmp45, 1, Less, LessZC);
  jacobian->resultVars[1] /* $res_LSJac7_2.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_VAR */ = ((tmp40 && tmp43)?jacobian->seedVars[1] /* line_2.is.re.SeedLSJac7 SEED_VAR */:jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */ - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * (jacobian->seedVars[1] /* line_2.is.re.SeedLSJac7 SEED_VAR */ + (jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - ((jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * (jacobian->seedVars[3] /* line_2.is.im.SeedLSJac7 SEED_VAR */ + ((-jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - ((jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))))));
  threadData->lastEquationSolved = 163;
}

/*
equation index: 164
type: SIMPLE_ASSIGN
$res_LSJac7_3.$pDERLSJac7.dummyVarLSJac7 = if time >= line_2.t1 and time < line_2.t2 then line_2.is.im.SeedLSJac7 else line_2.vs.im.SeedLSJac7 - (line_2.Z.re * (line_2.is.im.SeedLSJac7 + (-line_2.vs.re.SeedLSJac7) * line_2.Y.im - line_2.vs.im.SeedLSJac7 * line_2.Y.re) + line_2.Z.im * (line_2.is.re.SeedLSJac7 + line_2.vs.im.SeedLSJac7 * line_2.Y.im - line_2.vs.re.SeedLSJac7 * line_2.Y.re))
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_164(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 11;
  const int equationIndexes[2] = {1,164};
  modelica_boolean tmp46;
  modelica_real tmp47;
  modelica_real tmp48;
  modelica_boolean tmp49;
  modelica_real tmp50;
  modelica_real tmp51;
  tmp47 = 1.0;
  tmp48 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  relationhysteresis(data, &tmp46, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp47, tmp48, 0, GreaterEq, GreaterEqZC);
  tmp50 = 1.0;
  tmp51 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  relationhysteresis(data, &tmp49, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp50, tmp51, 1, Less, LessZC);
  jacobian->resultVars[2] /* $res_LSJac7_3.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_VAR */ = ((tmp46 && tmp49)?jacobian->seedVars[3] /* line_2.is.im.SeedLSJac7 SEED_VAR */:jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */ - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * (jacobian->seedVars[3] /* line_2.is.im.SeedLSJac7 SEED_VAR */ + ((-jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - ((jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * (jacobian->seedVars[1] /* line_2.is.re.SeedLSJac7 SEED_VAR */ + (jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - ((jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */))))));
  threadData->lastEquationSolved = 164;
}

/*
equation index: 165
type: SIMPLE_ASSIGN
$res_LSJac7_4.$pDERLSJac7.dummyVarLSJac7 = if time >= line_1.t1 and time < line_1.t2 then line_1.is.re.SeedLSJac7 else line_2.vs.re.SeedLSJac7 - (line_1.Z.re * (line_1.is.re.SeedLSJac7 + line_2.vs.im.SeedLSJac7 * line_1.Y.im - line_2.vs.re.SeedLSJac7 * line_1.Y.re) - line_1.Z.im * (line_1.is.im.SeedLSJac7 + (-line_2.vs.re.SeedLSJac7) * line_1.Y.im - line_2.vs.im.SeedLSJac7 * line_1.Y.re))
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_165(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 12;
  const int equationIndexes[2] = {1,165};
  modelica_boolean tmp52;
  modelica_real tmp53;
  modelica_real tmp54;
  modelica_boolean tmp55;
  modelica_real tmp56;
  modelica_real tmp57;
  tmp53 = 1.0;
  tmp54 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  relationhysteresis(data, &tmp52, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp53, tmp54, 2, GreaterEq, GreaterEqZC);
  tmp56 = 1.0;
  tmp57 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  relationhysteresis(data, &tmp55, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp56, tmp57, 3, Less, LessZC);
  jacobian->resultVars[3] /* $res_LSJac7_4.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_VAR */ = ((tmp52 && tmp55)?jacobian->seedVars[0] /* line_1.is.re.SeedLSJac7 SEED_VAR */:jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */ - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * (jacobian->seedVars[0] /* line_1.is.re.SeedLSJac7 SEED_VAR */ + (jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - ((jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * (jacobian->seedVars[2] /* line_1.is.im.SeedLSJac7 SEED_VAR */ + ((-jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - ((jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))))));
  threadData->lastEquationSolved = 165;
}

/*
equation index: 166
type: SIMPLE_ASSIGN
$res_LSJac7_5.$pDERLSJac7.dummyVarLSJac7 = if time < fault.t1 then fault.p.ii.$pDERLSJac7.dummyVarLSJac7 else if time < fault.t2 and fault.ground then line_2.vs.re.SeedLSJac7 else if time < fault.t2 then fault.p.ii.$pDERLSJac7.dummyVarLSJac7 - (fault.R * line_2.vs.im.SeedLSJac7 - fault.X * line_2.vs.re.SeedLSJac7) * (fault.X ^ 2.0 + fault.R ^ 2.0) / (fault.X ^ 2.0 + fault.R ^ 2.0) ^ 2.0 else fault.p.ii.$pDERLSJac7.dummyVarLSJac7
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_166(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 13;
  const int equationIndexes[2] = {1,166};
  modelica_boolean tmp58;
  modelica_real tmp59;
  modelica_real tmp60;
  modelica_boolean tmp61;
  modelica_real tmp62;
  modelica_real tmp63;
  modelica_boolean tmp64;
  modelica_real tmp65;
  modelica_real tmp66;
  modelica_real tmp67;
  modelica_real tmp68;
  modelica_real tmp69;
  modelica_real tmp70;
  modelica_real tmp71;
  modelica_boolean tmp72;
  modelica_real tmp73;
  modelica_boolean tmp74;
  modelica_real tmp75;
  modelica_boolean tmp76;
  modelica_real tmp77;
  tmp59 = 1.0;
  tmp60 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */));
  relationhysteresis(data, &tmp58, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */), tmp59, tmp60, 4, Less, LessZC);
  tmp76 = (modelica_boolean)tmp58;
  if(tmp76)
  {
    tmp77 = jacobian->tmpVars[7] /* fault.p.ii.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */;
  }
  else
  {
    tmp62 = 1.0;
    tmp63 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
    relationhysteresis(data, &tmp61, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */), tmp62, tmp63, 5, Less, LessZC);
    tmp74 = (modelica_boolean)(tmp61 && (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[45]] /* fault.ground PARAM */));
    if(tmp74)
    {
      tmp75 = jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */;
    }
    else
    {
      tmp65 = 1.0;
      tmp66 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
      relationhysteresis(data, &tmp64, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */), tmp65, tmp66, 5, Less, LessZC);
      tmp72 = (modelica_boolean)tmp64;
      if(tmp72)
      {
        tmp67 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp68 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp69 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp70 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp71 = (tmp69 * tmp69) + (tmp70 * tmp70);
        tmp73 = jacobian->tmpVars[7] /* fault.p.ii.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */ - (DIVISION((((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */)) * (jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */)) * (jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */))) * ((tmp67 * tmp67) + (tmp68 * tmp68)),(tmp71 * tmp71),"(fault.X ^ 2.0 + fault.R ^ 2.0) ^ 2.0"));
      }
      else
      {
        tmp73 = jacobian->tmpVars[7] /* fault.p.ii.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */;
      }
      tmp75 = tmp73;
    }
    tmp77 = tmp75;
  }
  jacobian->resultVars[4] /* $res_LSJac7_5.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_VAR */ = tmp77;
  threadData->lastEquationSolved = 166;
}

/*
equation index: 167
type: SIMPLE_ASSIGN
$res_LSJac7_6.$pDERLSJac7.dummyVarLSJac7 = if time < fault.t1 then fault.p.ir.$pDERLSJac7.dummyVarLSJac7 else if time < fault.t2 and fault.ground then line_2.vs.im.SeedLSJac7 else if time < fault.t2 then fault.p.ir.$pDERLSJac7.dummyVarLSJac7 - (fault.R * line_2.vs.re.SeedLSJac7 + fault.X * line_2.vs.im.SeedLSJac7) * (fault.R ^ 2.0 + fault.X ^ 2.0) / (fault.R ^ 2.0 + fault.X ^ 2.0) ^ 2.0 else fault.p.ir.$pDERLSJac7.dummyVarLSJac7
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_167(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 14;
  const int equationIndexes[2] = {1,167};
  modelica_boolean tmp78;
  modelica_real tmp79;
  modelica_real tmp80;
  modelica_boolean tmp81;
  modelica_real tmp82;
  modelica_real tmp83;
  modelica_boolean tmp84;
  modelica_real tmp85;
  modelica_real tmp86;
  modelica_real tmp87;
  modelica_real tmp88;
  modelica_real tmp89;
  modelica_real tmp90;
  modelica_real tmp91;
  modelica_boolean tmp92;
  modelica_real tmp93;
  modelica_boolean tmp94;
  modelica_real tmp95;
  modelica_boolean tmp96;
  modelica_real tmp97;
  tmp79 = 1.0;
  tmp80 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */));
  relationhysteresis(data, &tmp78, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */), tmp79, tmp80, 4, Less, LessZC);
  tmp96 = (modelica_boolean)tmp78;
  if(tmp96)
  {
    tmp97 = jacobian->tmpVars[8] /* fault.p.ir.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */;
  }
  else
  {
    tmp82 = 1.0;
    tmp83 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
    relationhysteresis(data, &tmp81, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */), tmp82, tmp83, 5, Less, LessZC);
    tmp94 = (modelica_boolean)(tmp81 && (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[45]] /* fault.ground PARAM */));
    if(tmp94)
    {
      tmp95 = jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */;
    }
    else
    {
      tmp85 = 1.0;
      tmp86 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
      relationhysteresis(data, &tmp84, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */), tmp85, tmp86, 5, Less, LessZC);
      tmp92 = (modelica_boolean)tmp84;
      if(tmp92)
      {
        tmp87 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp88 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp89 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp90 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp91 = (tmp89 * tmp89) + (tmp90 * tmp90);
        tmp93 = jacobian->tmpVars[8] /* fault.p.ir.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */ - (DIVISION((((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */)) * (jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */)) * (jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */)) * ((tmp87 * tmp87) + (tmp88 * tmp88)),(tmp91 * tmp91),"(fault.R ^ 2.0 + fault.X ^ 2.0) ^ 2.0"));
      }
      else
      {
        tmp93 = jacobian->tmpVars[8] /* fault.p.ir.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */;
      }
      tmp95 = tmp93;
    }
    tmp97 = tmp95;
  }
  jacobian->resultVars[5] /* $res_LSJac7_6.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_VAR */ = tmp97;
  threadData->lastEquationSolved = 167;
}

/*
equation index: 168
type: SIMPLE_ASSIGN
$res_LSJac7_7.$pDERLSJac7.dummyVarLSJac7 = if time >= line_1.t1 and time < line_1.t2 then line_1.is.im.SeedLSJac7 else line_2.vs.im.SeedLSJac7 - (line_1.Z.re * (line_1.is.im.SeedLSJac7 + (-line_2.vs.re.SeedLSJac7) * line_1.Y.im - line_2.vs.im.SeedLSJac7 * line_1.Y.re) + line_1.Z.im * (line_1.is.re.SeedLSJac7 + line_2.vs.im.SeedLSJac7 * line_1.Y.im - line_2.vs.re.SeedLSJac7 * line_1.Y.re))
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_168(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 15;
  const int equationIndexes[2] = {1,168};
  modelica_boolean tmp98;
  modelica_real tmp99;
  modelica_real tmp100;
  modelica_boolean tmp101;
  modelica_real tmp102;
  modelica_real tmp103;
  tmp99 = 1.0;
  tmp100 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  relationhysteresis(data, &tmp98, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp99, tmp100, 2, GreaterEq, GreaterEqZC);
  tmp102 = 1.0;
  tmp103 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  relationhysteresis(data, &tmp101, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp102, tmp103, 3, Less, LessZC);
  jacobian->resultVars[6] /* $res_LSJac7_7.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_VAR */ = ((tmp98 && tmp101)?jacobian->seedVars[2] /* line_1.is.im.SeedLSJac7 SEED_VAR */:jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */ - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * (jacobian->seedVars[2] /* line_1.is.im.SeedLSJac7 SEED_VAR */ + ((-jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - ((jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * (jacobian->seedVars[0] /* line_1.is.re.SeedLSJac7 SEED_VAR */ + (jacobian->seedVars[7] /* line_2.vs.im.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - ((jacobian->seedVars[8] /* line_2.vs.re.SeedLSJac7 SEED_VAR */) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */))))));
  threadData->lastEquationSolved = 168;
}

/*
equation index: 169
type: SIMPLE_ASSIGN
$res_LSJac7_8.$pDERLSJac7.dummyVarLSJac7 = ($cse3 * G1.machine.vq.$pDERLSJac7.dummyVarLSJac7 - $cse4 * G1.machine.vd.$pDERLSJac7.dummyVarLSJac7) * G1.machine.V_MBtoSB - transformer.vs.im.$pDERLSJac7.dummyVarLSJac7
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_169(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 16;
  const int equationIndexes[2] = {1,169};
  jacobian->resultVars[7] /* $res_LSJac7_8.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_VAR */ = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* $cse3 variable */)) * (jacobian->tmpVars[5] /* G1.machine.vq.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* $cse4 variable */)) * (jacobian->tmpVars[4] /* G1.machine.vd.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */)) - jacobian->tmpVars[3] /* transformer.vs.im.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */;
  threadData->lastEquationSolved = 169;
}

/*
equation index: 170
type: SIMPLE_ASSIGN
$res_LSJac7_9.$pDERLSJac7.dummyVarLSJac7 = ($cse3 * G1.machine.vd.$pDERLSJac7.dummyVarLSJac7 + $cse4 * G1.machine.vq.$pDERLSJac7.dummyVarLSJac7) * G1.machine.V_MBtoSB - transformer.vs.re.$pDERLSJac7.dummyVarLSJac7
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_170(DATA *data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  const int baseClockIndex = 0;
  const int subClockIndex = 17;
  const int equationIndexes[2] = {1,170};
  jacobian->resultVars[8] /* $res_LSJac7_9.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_VAR */ = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* $cse3 variable */)) * (jacobian->tmpVars[4] /* G1.machine.vd.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* $cse4 variable */)) * (jacobian->tmpVars[5] /* G1.machine.vq.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */)) - jacobian->tmpVars[2] /* transformer.vs.re.$pDERLSJac7.dummyVarLSJac7 JACOBIAN_TMP_VAR */;
  threadData->lastEquationSolved = 170;
}

OMC_DISABLE_OPT
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacLSJac7_constantEqns(DATA* data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  int index = OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_LSJac7;
  
  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacLSJac7_column(DATA* data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  int index = OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_LSJac7;
  
  static void (*const eqFunctions[18])(DATA*, threadData_t*, JACOBIAN*, JACOBIAN*) = {
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_153,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_154,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_155,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_156,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_157,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_158,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_159,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_160,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_161,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_162,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_163,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_164,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_165,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_166,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_167,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_168,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_169,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_170
  };
  
  for (int id = 0; id < 18; id++) {
    eqFunctions[id](data, threadData, jacobian, parentJacobian);
  }
  
  return 0;
}
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacH_column(DATA* data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  return 0;
}
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacF_column(DATA* data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  return 0;
}
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacD_column(DATA* data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  return 0;
}
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacC_column(DATA* data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  return 0;
}
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacB_column(DATA* data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  return 0;
}
/* constant equations */
/* dynamic equations */

OMC_DISABLE_OPT
int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacA_constantEqns(DATA* data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  int index = OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_A;
  
  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_functionJacA_column(DATA* data, threadData_t *threadData, JACOBIAN *jacobian, JACOBIAN *parentJacobian)
{
  int index = OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_A;
  
  
  return 0;
}

OMC_DISABLE_OPT
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianLSJac6(DATA* data, threadData_t *threadData, JACOBIAN *jacobian)
{
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "OpenIPSL.Examples.KundurSMIB.SMIB_JacLSJac6.bin");
  
  initJacobian(jacobian, 7, 7, 22, OpenIPSL_Examples_KundurSMIB_SMIB_functionJacLSJac6_column, NULL, NULL);
  jacobian->sparsePattern = allocSparsePattern(7, 29, 5);
  jacobian->availability = JACOBIAN_AVAILABLE;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 7+1, pFile, FALSE);
  if (count != 7+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %zu", 7+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 29, pFile, FALSE);
  if (count != 29) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %zu", 29, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1, 7);
  /* color 2 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 2, 1, 7);
  /* color 3 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 3, 1, 7);
  /* color 4 with 2 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 4, 2, 7);
  /* color 5 with 2 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 5, 2, 7);
  
  omc_fclose(pFile);
  
  return 0;
}
OMC_DISABLE_OPT
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianLSJac7(DATA* data, threadData_t *threadData, JACOBIAN *jacobian)
{
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "OpenIPSL.Examples.KundurSMIB.SMIB_JacLSJac7.bin");
  
  initJacobian(jacobian, 9, 9, 18, OpenIPSL_Examples_KundurSMIB_SMIB_functionJacLSJac7_column, NULL, NULL);
  jacobian->sparsePattern = allocSparsePattern(9, 39, 7);
  jacobian->availability = JACOBIAN_AVAILABLE;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 9+1, pFile, FALSE);
  if (count != 9+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %zu", 9+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 39, pFile, FALSE);
  if (count != 39) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %zu", 39, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1, 9);
  /* color 2 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 2, 1, 9);
  /* color 3 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 3, 1, 9);
  /* color 4 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 4, 1, 9);
  /* color 5 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 5, 1, 9);
  /* color 6 with 2 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 6, 2, 9);
  /* color 7 with 2 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 7, 2, 9);
  
  omc_fclose(pFile);
  
  return 0;
}
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianH(DATA* data, threadData_t *threadData, JACOBIAN *jacobian)
{
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianF(DATA* data, threadData_t *threadData, JACOBIAN *jacobian)
{
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianD(DATA* data, threadData_t *threadData, JACOBIAN *jacobian)
{
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianC(DATA* data, threadData_t *threadData, JACOBIAN *jacobian)
{
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianB(DATA* data, threadData_t *threadData, JACOBIAN *jacobian)
{
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
OMC_DISABLE_OPT
int OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianA(DATA* data, threadData_t *threadData, JACOBIAN *jacobian)
{
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "OpenIPSL.Examples.KundurSMIB.SMIB_JacA.bin");
  
  initJacobian(jacobian, 6, 6, 0, OpenIPSL_Examples_KundurSMIB_SMIB_functionJacA_column, NULL, NULL);
  jacobian->sparsePattern = allocSparsePattern(6, 20, 4);
  jacobian->availability = JACOBIAN_ONLY_SPARSITY;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 6+1, pFile, FALSE);
  if (count != 6+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %zu", 6+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 20, pFile, FALSE);
  if (count != 20) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %zu", 20, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1, 6);
  /* color 2 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 2, 1, 6);
  /* color 3 with 2 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 3, 2, 6);
  /* color 4 with 2 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 4, 2, 6);
  
  omc_fclose(pFile);
  
  return 0;
}


