/* Linearization */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

const char *OpenIPSL_Examples_KundurSMIB_SMIB_linear_model_frame()
{
  errorStreamPrint(OMC_LOG_STDOUT, 0, "Linearization disabled. Use compiler flag `--linearizationDumpLanguage` to change target language.");
  return "";
}
const char *OpenIPSL_Examples_KundurSMIB_SMIB_linear_model_datarecovery_frame()
{
  errorStreamPrint(OMC_LOG_STDOUT, 0, "Linearization disabled. Use compiler flag `--linearizationDumpLanguage` to change target language.");
  return "";
}

#if defined(__cplusplus)
}
#endif
