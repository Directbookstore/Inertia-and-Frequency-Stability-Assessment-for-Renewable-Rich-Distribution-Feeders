/* update bound parameters and variable attributes (start, nominal, min, max) */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#if defined(__cplusplus)
extern "C" {
#endif


/*
equation index: 208
type: SIMPLE_ASSIGN
$START.G1.machine.Q = G1.machine.q0
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_208(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,208};
  ((modelica_real *)((data->modelData->realVarsData[32] /* G1.machine.Q variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[69]] /* G1.machine.q0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[32]] /* G1.machine.Q variable */) = ((modelica_real *)((data->modelData->realVarsData[32] /* G1.machine.Q variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[32].info /* G1.machine.Q */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[32]] /* G1.machine.Q variable */));
  threadData->lastEquationSolved = 208;
}

/*
equation index: 209
type: SIMPLE_ASSIGN
$START.G1.machine.P = G1.machine.p0
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_209(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,209};
  ((modelica_real *)((data->modelData->realVarsData[31] /* G1.machine.P variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[67]] /* G1.machine.p0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[31]] /* G1.machine.P variable */) = ((modelica_real *)((data->modelData->realVarsData[31] /* G1.machine.P variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[31].info /* G1.machine.P */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[31]] /* G1.machine.P variable */));
  threadData->lastEquationSolved = 209;
}

/*
equation index: 210
type: SIMPLE_ASSIGN
$START.line_2.vs.im = B2.v_0 * sin(B2.angle_0)
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_210(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,210};
  ((modelica_real *)((data->modelData->realVarsData[65] /* line_2.vs.im variable */).attribute .start.data))[0] = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[13]] /* B2.v_0 PARAM */)) * (sin((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[11]] /* B2.angle_0 PARAM */)));
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) = ((modelica_real *)((data->modelData->realVarsData[65] /* line_2.vs.im variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[65].info /* line_2.vs.im */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */));
  threadData->lastEquationSolved = 210;
}

/*
equation index: 211
type: SIMPLE_ASSIGN
$START.line_2.vs.re = B2.v_0 * cos(B2.angle_0)
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_211(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,211};
  ((modelica_real *)((data->modelData->realVarsData[66] /* line_2.vs.re variable */).attribute .start.data))[0] = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[13]] /* B2.v_0 PARAM */)) * (cos((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[11]] /* B2.angle_0 PARAM */)));
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) = ((modelica_real *)((data->modelData->realVarsData[66] /* line_2.vs.re variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[66].info /* line_2.vs.re */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */));
  threadData->lastEquationSolved = 211;
}

/*
equation index: 212
type: SIMPLE_ASSIGN
$START.transformer.vs.im = B1.v_0 * sin(B1.angle_0)
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_212(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,212};
  ((modelica_real *)((data->modelData->realVarsData[75] /* transformer.vs.im variable */).attribute .start.data))[0] = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[6]] /* B1.v_0 PARAM */)) * (sin((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[4]] /* B1.angle_0 PARAM */)));
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */) = ((modelica_real *)((data->modelData->realVarsData[75] /* transformer.vs.im variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[75].info /* transformer.vs.im */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */));
  threadData->lastEquationSolved = 212;
}

/*
equation index: 213
type: SIMPLE_ASSIGN
$START.transformer.vs.re = B1.v_0 * cos(B1.angle_0)
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_213(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,213};
  ((modelica_real *)((data->modelData->realVarsData[76] /* transformer.vs.re variable */).attribute .start.data))[0] = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[6]] /* B1.v_0 PARAM */)) * (cos((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[4]] /* B1.angle_0 PARAM */)));
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */) = ((modelica_real *)((data->modelData->realVarsData[76] /* transformer.vs.re variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[76].info /* transformer.vs.re */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */));
  threadData->lastEquationSolved = 213;
}

/*
equation index: 214
type: SIMPLE_ASSIGN
$START.B2.angle = B2.angle_0
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_214(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,214};
  ((modelica_real *)((data->modelData->realVarsData[19] /* B2.angle variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[11]] /* B2.angle_0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[19]] /* B2.angle variable */) = ((modelica_real *)((data->modelData->realVarsData[19] /* B2.angle variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[19].info /* B2.angle */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[19]] /* B2.angle variable */));
  threadData->lastEquationSolved = 214;
}

/*
equation index: 215
type: SIMPLE_ASSIGN
$START.B2.v = B2.v_0
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_215(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,215};
  ((modelica_real *)((data->modelData->realVarsData[23] /* B2.v variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[13]] /* B2.v_0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[23]] /* B2.v variable */) = ((modelica_real *)((data->modelData->realVarsData[23] /* B2.v variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[23].info /* B2.v */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[23]] /* B2.v variable */));
  threadData->lastEquationSolved = 215;
}

/*
equation index: 216
type: SIMPLE_ASSIGN
$START.B1.angle = B1.angle_0
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_216(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,216};
  ((modelica_real *)((data->modelData->realVarsData[14] /* B1.angle variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[4]] /* B1.angle_0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[14]] /* B1.angle variable */) = ((modelica_real *)((data->modelData->realVarsData[14] /* B1.angle variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[14].info /* B1.angle */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[14]] /* B1.angle variable */));
  threadData->lastEquationSolved = 216;
}

/*
equation index: 217
type: SIMPLE_ASSIGN
$START.B1.v = G1.machine.v_0
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_217(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,217};
  ((modelica_real *)((data->modelData->realVarsData[18] /* B1.v variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[71]] /* G1.machine.v_0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[18]] /* B1.v variable */) = ((modelica_real *)((data->modelData->realVarsData[18] /* B1.v variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[18].info /* B1.v */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[18]] /* B1.v variable */));
  threadData->lastEquationSolved = 217;
}

/*
equation index: 218
type: SIMPLE_ASSIGN
$START.G1.machine.v = G1.machine.v_0
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_218(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,218};
  ((modelica_real *)((data->modelData->realVarsData[37] /* G1.machine.v variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[71]] /* G1.machine.v_0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[37]] /* G1.machine.v variable */) = ((modelica_real *)((data->modelData->realVarsData[37] /* G1.machine.v variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[37].info /* G1.machine.v */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[37]] /* G1.machine.v variable */));
  threadData->lastEquationSolved = 218;
}

/*
equation index: 219
type: SIMPLE_ASSIGN
$START.G1.machine.anglev = G1.machine.angle_0
*/
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_219(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,219};
  ((modelica_real *)((data->modelData->realVarsData[33] /* G1.machine.anglev variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[56]] /* G1.machine.angle_0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[33]] /* G1.machine.anglev variable */) = ((modelica_real *)((data->modelData->realVarsData[33] /* G1.machine.anglev variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[33].info /* G1.machine.anglev */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[33]] /* G1.machine.anglev variable */));
  threadData->lastEquationSolved = 219;
}
OMC_DISABLE_OPT
int OpenIPSL_Examples_KundurSMIB_SMIB_updateBoundVariableAttributes(DATA *data, threadData_t *threadData)
{
  /* min ******************************************************** */
  infoStreamPrint(OMC_LOG_INIT, 1, "updating min-values");
  messageClose(OMC_LOG_INIT);
  
  /* max ******************************************************** */
  infoStreamPrint(OMC_LOG_INIT, 1, "updating max-values");
  messageClose(OMC_LOG_INIT);
  
  /* nominal **************************************************** */
  infoStreamPrint(OMC_LOG_INIT, 1, "updating nominal-values");
  messageClose(OMC_LOG_INIT);
  
  /* start ****************************************************** */
  infoStreamPrint(OMC_LOG_INIT, 1, "updating primary start-values");
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_208(data, threadData);
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_209(data, threadData);
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_210(data, threadData);
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_211(data, threadData);
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_212(data, threadData);
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_213(data, threadData);
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_214(data, threadData);
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_215(data, threadData);
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_216(data, threadData);
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_217(data, threadData);
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_218(data, threadData);
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_219(data, threadData);
  messageClose(OMC_LOG_INIT);
  
  return 0;
}

void OpenIPSL_Examples_KundurSMIB_SMIB_updateBoundParameters_0(DATA *data, threadData_t *threadData);

/*
equation index: 220
type: SIMPLE_ASSIGN
G1.machine.V_b = G1.V_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_220(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,220};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[49]] /* G1.machine.V_b PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[24]] /* G1.V_b PARAM */);
  threadData->lastEquationSolved = 220;
}

/*
equation index: 221
type: SIMPLE_ASSIGN
G1.machine.V_MBtoSB = G1.machine.Vn / G1.machine.V_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_221(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,221};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */) = DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[52]] /* G1.machine.Vn PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[49]] /* G1.machine.V_b PARAM */),"G1.machine.V_b",equationIndexes);
  threadData->lastEquationSolved = 221;
}

/*
equation index: 222
type: SIMPLE_ASSIGN
G1.machine.K1 = G1.machine.xd + (-G1.machine.x1d) - G1.machine.T2d0 * G1.machine.x2d * (G1.machine.xd - G1.machine.x1d) / (G1.machine.x1d * G1.machine.T1d0)
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_222(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,222};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[33]] /* G1.machine.K1 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[82]] /* G1.machine.xd PARAM */) + (-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[45]] /* G1.machine.T2d0 PARAM */)) * (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[80]] /* G1.machine.x2d PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[82]] /* G1.machine.xd PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */),((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[43]] /* G1.machine.T1d0 PARAM */)),"G1.machine.x1d * G1.machine.T1d0",equationIndexes))));
  threadData->lastEquationSolved = 222;
}

/*
equation index: 223
type: SIMPLE_ASSIGN
G1.machine.K2 = G1.machine.x1d + G1.machine.T2d0 * G1.machine.x2d * (G1.machine.xd - G1.machine.x1d) / (G1.machine.x1d * G1.machine.T1d0) - G1.machine.x2d
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_223(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,223};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[34]] /* G1.machine.K2 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[45]] /* G1.machine.T2d0 PARAM */)) * (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[80]] /* G1.machine.x2d PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[82]] /* G1.machine.xd PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */),((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[43]] /* G1.machine.T1d0 PARAM */)),"G1.machine.x1d * G1.machine.T1d0",equationIndexes))) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[80]] /* G1.machine.x2d PARAM */);
  threadData->lastEquationSolved = 223;
}

/*
equation index: 224
type: SIMPLE_ASSIGN
G1.machine.S_b = SysData.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_224(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,224};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[41]] /* G1.machine.S_b PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[87]] /* SysData.S_b PARAM */);
  threadData->lastEquationSolved = 224;
}

/*
equation index: 225
type: SIMPLE_ASSIGN
G1.machine.S_SBtoMB = G1.machine.S_b / G1.machine.Sn
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_225(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,225};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[40]] /* G1.machine.S_SBtoMB PARAM */) = DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[41]] /* G1.machine.S_b PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[42]] /* G1.machine.Sn PARAM */),"G1.machine.Sn",equationIndexes);
  threadData->lastEquationSolved = 225;
}

/*
equation index: 226
type: SIMPLE_ASSIGN
G1.machine.Z_MBtoSB = G1.machine.S_b * (G1.machine.Vn / G1.machine.V_b) ^ 2.0 / G1.machine.Sn
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_226(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,226};
  modelica_real tmp0;
  tmp0 = DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[52]] /* G1.machine.Vn PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[49]] /* G1.machine.V_b PARAM */),"G1.machine.V_b",equationIndexes);
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[55]] /* G1.machine.Z_MBtoSB PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[41]] /* G1.machine.S_b PARAM */)) * (DIVISION_SIM((tmp0 * tmp0),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[42]] /* G1.machine.Sn PARAM */),"G1.machine.Sn",equationIndexes));
  threadData->lastEquationSolved = 226;
}

/*
equation index: 227
type: SIMPLE_ASSIGN
G1.machine.xq0 = G1.machine.xq
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_227(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,227};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[84]] /* G1.machine.xq0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */);
  threadData->lastEquationSolved = 227;
}

/*
equation index: 228
type: SIMPLE_ASSIGN
S_b = SysData.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_228(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,228};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[86]] /* S_b PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[87]] /* SysData.S_b PARAM */);
  threadData->lastEquationSolved = 228;
}

/*
equation index: 229
type: SIMPLE_ASSIGN
G1.Q_0 = 0.436002238696658 * S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_229(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,229};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[22]] /* G1.Q_0 PARAM */) = (0.436002238696658) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[86]] /* S_b PARAM */));
  threadData->lastEquationSolved = 229;
}

/*
equation index: 230
type: SIMPLE_ASSIGN
G1.machine.Q_0 = G1.Q_0
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_230(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,230};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[37]] /* G1.machine.Q_0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[22]] /* G1.Q_0 PARAM */);
  threadData->lastEquationSolved = 230;
}

/*
equation index: 231
type: SIMPLE_ASSIGN
G1.machine.q0 = G1.machine.Q_0 / G1.machine.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_231(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,231};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[69]] /* G1.machine.q0 PARAM */) = DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[37]] /* G1.machine.Q_0 PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[41]] /* G1.machine.S_b PARAM */),"G1.machine.S_b",equationIndexes);
  threadData->lastEquationSolved = 231;
}

/*
equation index: 232
type: SIMPLE_ASSIGN
G1.machine.S0.im = -G1.machine.q0
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_232(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,232};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[38]] /* G1.machine.S0.im PARAM */) = (-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[69]] /* G1.machine.q0 PARAM */));
  threadData->lastEquationSolved = 232;
}

/*
equation index: 233
type: SIMPLE_ASSIGN
G1.P_0 = 0.899999999997135 * S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_233(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,233};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[21]] /* G1.P_0 PARAM */) = (0.899999999997135) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[86]] /* S_b PARAM */));
  threadData->lastEquationSolved = 233;
}

/*
equation index: 234
type: SIMPLE_ASSIGN
G1.machine.P_0 = G1.P_0
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_234(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,234};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[36]] /* G1.machine.P_0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[21]] /* G1.P_0 PARAM */);
  threadData->lastEquationSolved = 234;
}

/*
equation index: 235
type: SIMPLE_ASSIGN
G1.machine.p0 = G1.machine.P_0 / G1.machine.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_235(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,235};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[67]] /* G1.machine.p0 PARAM */) = DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[36]] /* G1.machine.P_0 PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[41]] /* G1.machine.S_b PARAM */),"G1.machine.S_b",equationIndexes);
  threadData->lastEquationSolved = 235;
}

/*
equation index: 236
type: SIMPLE_ASSIGN
G1.machine.S0.re = G1.machine.p0
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_236(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,236};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[39]] /* G1.machine.S0.re PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[67]] /* G1.machine.p0 PARAM */);
  threadData->lastEquationSolved = 236;
}

/*
equation index: 237
type: SIMPLE_ASSIGN
G1.machine.I_MBtoSB = G1.machine.Sn * G1.machine.V_b / (G1.machine.Vn * G1.machine.S_b)
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_237(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,237};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[42]] /* G1.machine.Sn PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[49]] /* G1.machine.V_b PARAM */),((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[52]] /* G1.machine.Vn PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[41]] /* G1.machine.S_b PARAM */)),"G1.machine.Vn * G1.machine.S_b",equationIndexes));
  threadData->lastEquationSolved = 237;
}

/*
equation index: 238
type: SIMPLE_ASSIGN
G1.machine.fn = SysData.fn
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_238(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,238};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[62]] /* G1.machine.fn PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[88]] /* SysData.fn PARAM */);
  threadData->lastEquationSolved = 238;
}

/*
equation index: 239
type: SIMPLE_ASSIGN
G1.machine.w_b = 6.283185307179586 * G1.machine.fn
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_239(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,239};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[77]] /* G1.machine.w_b PARAM */) = (6.283185307179586) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[62]] /* G1.machine.fn PARAM */));
  threadData->lastEquationSolved = 239;
}

/*
equation index: 243
type: SIMPLE_ASSIGN
G1.machine.angle_0 = G1.angle_0
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_243(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,243};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[56]] /* G1.machine.angle_0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[25]] /* G1.angle_0 PARAM */);
  threadData->lastEquationSolved = 243;
}

/*
equation index: 245
type: SIMPLE_ASSIGN
G1.machine.v_0 = G1.v_0
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_245(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,245};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[71]] /* G1.machine.v_0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[85]] /* G1.v_0 PARAM */);
  threadData->lastEquationSolved = 245;
}

/*
equation index: 257
type: SIMPLE_ASSIGN
G1.fn = SysData.fn
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_257(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,257};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[26]] /* G1.fn PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[88]] /* SysData.fn PARAM */);
  threadData->lastEquationSolved = 257;
}

/*
equation index: 260
type: SIMPLE_ASSIGN
G1.S_b = SysData.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_260(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,260};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[23]] /* G1.S_b PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[87]] /* SysData.S_b PARAM */);
  threadData->lastEquationSolved = 260;
}

/*
equation index: 261
type: SIMPLE_ASSIGN
line_2.Z.im = line_2.X
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_261(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,261};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[115]] /* line_2.X PARAM */);
  threadData->lastEquationSolved = 261;
}

/*
equation index: 262
type: SIMPLE_ASSIGN
line_2.Z.re = line_2.R
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_262(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,262};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[113]] /* line_2.R PARAM */);
  threadData->lastEquationSolved = 262;
}

/*
equation index: 263
type: SIMPLE_ASSIGN
line_2.Y.im = line_2.B
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_263(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,263};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[111]] /* line_2.B PARAM */);
  threadData->lastEquationSolved = 263;
}

/*
equation index: 264
type: SIMPLE_ASSIGN
line_2.Y.re = line_2.G
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_264(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,264};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[112]] /* line_2.G PARAM */);
  threadData->lastEquationSolved = 264;
}

/*
equation index: 266
type: SIMPLE_ASSIGN
line_2.S_b = SysData.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_266(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,266};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[114]] /* line_2.S_b PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[87]] /* SysData.S_b PARAM */);
  threadData->lastEquationSolved = 266;
}

/*
equation index: 267
type: SIMPLE_ASSIGN
fault.ground = abs(fault.R) < 2.220446049250313e-16 and abs(fault.X) < 2.220446049250313e-16
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_267(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,267};
  modelica_boolean tmp1;
  modelica_boolean tmp2;
  tmp1 = Less(fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */)),2.220446049250313e-16);
  tmp2 = Less(fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */)),2.220446049250313e-16);
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[45]] /* fault.ground PARAM */) = (tmp1 && tmp2);
  threadData->lastEquationSolved = 267;
}

/*
equation index: 274
type: SIMPLE_ASSIGN
infinite_bus.fn = SysData.fn
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_274(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,274};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[98]] /* infinite_bus.fn PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[88]] /* SysData.fn PARAM */);
  threadData->lastEquationSolved = 274;
}

/*
equation index: 277
type: SIMPLE_ASSIGN
infinite_bus.S_b = SysData.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_277(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,277};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[95]] /* infinite_bus.S_b PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[87]] /* SysData.S_b PARAM */);
  threadData->lastEquationSolved = 277;
}

/*
equation index: 278
type: SIMPLE_ASSIGN
line_1.Z.im = line_1.X
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_278(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,278};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[104]] /* line_1.X PARAM */);
  threadData->lastEquationSolved = 278;
}

/*
equation index: 279
type: SIMPLE_ASSIGN
line_1.Z.re = line_1.R
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_279(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,279};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[102]] /* line_1.R PARAM */);
  threadData->lastEquationSolved = 279;
}

/*
equation index: 280
type: SIMPLE_ASSIGN
line_1.Y.im = line_1.B
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_280(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,280};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[100]] /* line_1.B PARAM */);
  threadData->lastEquationSolved = 280;
}

/*
equation index: 281
type: SIMPLE_ASSIGN
line_1.Y.re = line_1.G
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_281(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,281};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[101]] /* line_1.G PARAM */);
  threadData->lastEquationSolved = 281;
}

/*
equation index: 283
type: SIMPLE_ASSIGN
line_1.S_b = SysData.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_283(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,283};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[103]] /* line_1.S_b PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[87]] /* SysData.S_b PARAM */);
  threadData->lastEquationSolved = 283;
}

/*
equation index: 284
type: SIMPLE_ASSIGN
transformer.tc = transformer.m <> 1.0
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_284(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,284};
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[58]] /* transformer.tc PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */) != 1.0);
  threadData->lastEquationSolved = 284;
}

/*
equation index: 285
type: SIMPLE_ASSIGN
transformer.Zn = transformer.Vn ^ 2.0 / transformer.Sn
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_285(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,285};
  modelica_real tmp3;
  tmp3 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[125]] /* transformer.Vn PARAM */);
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[127]] /* transformer.Zn PARAM */) = DIVISION_SIM((tmp3 * tmp3),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[123]] /* transformer.Sn PARAM */),"transformer.Sn",equationIndexes);
  threadData->lastEquationSolved = 285;
}

/*
equation index: 286
type: SIMPLE_ASSIGN
transformer.S_b = SysData.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_286(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,286};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[122]] /* transformer.S_b PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[87]] /* SysData.S_b PARAM */);
  threadData->lastEquationSolved = 286;
}

/*
equation index: 287
type: SIMPLE_ASSIGN
transformer.Zb = transformer.V_b ^ 2.0 / transformer.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_287(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,287};
  modelica_real tmp4;
  tmp4 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[124]] /* transformer.V_b PARAM */);
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[126]] /* transformer.Zb PARAM */) = DIVISION_SIM((tmp4 * tmp4),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[122]] /* transformer.S_b PARAM */),"transformer.S_b",equationIndexes);
  threadData->lastEquationSolved = 287;
}

/*
equation index: 288
type: SIMPLE_ASSIGN
transformer.x = transformer.xT * transformer.Zn / transformer.Zb
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_288(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,288};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[132]] /* transformer.xT PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[127]] /* transformer.Zn PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[126]] /* transformer.Zb PARAM */),"transformer.Zb",equationIndexes));
  threadData->lastEquationSolved = 288;
}

/*
equation index: 289
type: SIMPLE_ASSIGN
transformer.r = transformer.rT * transformer.Zn / transformer.Zb
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_289(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,289};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[130]] /* transformer.rT PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[127]] /* transformer.Zn PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[126]] /* transformer.Zb PARAM */),"transformer.Zb",equationIndexes));
  threadData->lastEquationSolved = 289;
}

/*
equation index: 296
type: SIMPLE_ASSIGN
B3.fn = SysData.fn
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_296(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,296};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[19]] /* B3.fn PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[88]] /* SysData.fn PARAM */);
  threadData->lastEquationSolved = 296;
}

/*
equation index: 299
type: SIMPLE_ASSIGN
B3.S_b = SysData.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_299(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,299};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[16]] /* B3.S_b PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[87]] /* SysData.S_b PARAM */);
  threadData->lastEquationSolved = 299;
}

/*
equation index: 306
type: SIMPLE_ASSIGN
B2.fn = SysData.fn
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_306(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,306};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[12]] /* B2.fn PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[88]] /* SysData.fn PARAM */);
  threadData->lastEquationSolved = 306;
}

/*
equation index: 309
type: SIMPLE_ASSIGN
B2.S_b = SysData.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_309(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,309};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[9]] /* B2.S_b PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[87]] /* SysData.S_b PARAM */);
  threadData->lastEquationSolved = 309;
}

/*
equation index: 316
type: SIMPLE_ASSIGN
B1.fn = SysData.fn
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_316(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,316};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[5]] /* B1.fn PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[88]] /* SysData.fn PARAM */);
  threadData->lastEquationSolved = 316;
}

/*
equation index: 319
type: SIMPLE_ASSIGN
B1.S_b = SysData.S_b
*/
OMC_DISABLE_OPT
static void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_319(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,319};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[2]] /* B1.S_b PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[87]] /* SysData.S_b PARAM */);
  threadData->lastEquationSolved = 319;
}
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_6(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_5(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_129(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_128(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_127(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_126(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_125(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_124(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_7(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_8(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_9(DATA *data, threadData_t *threadData);

OMC_DISABLE_OPT
void OpenIPSL_Examples_KundurSMIB_SMIB_updateBoundParameters_0(DATA *data, threadData_t *threadData)
{
  static void (*const eqFunctions[60])(DATA*, threadData_t*) = {
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_220,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_221,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_222,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_223,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_224,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_225,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_226,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_227,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_228,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_229,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_230,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_231,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_232,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_233,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_234,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_235,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_236,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_237,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_238,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_239,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_243,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_245,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_257,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_260,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_261,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_262,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_263,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_264,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_266,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_267,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_274,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_277,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_278,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_279,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_280,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_281,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_283,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_284,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_285,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_286,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_287,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_288,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_289,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_296,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_299,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_306,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_309,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_316,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_319,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_6,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_5,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_129,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_128,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_127,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_126,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_125,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_124,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_7,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_8,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_9
  };
  
  for (int id = 0; id < 60; id++) {
    eqFunctions[id](data, threadData);
  }
}
OMC_DISABLE_OPT
int OpenIPSL_Examples_KundurSMIB_SMIB_updateBoundParameters(DATA *data, threadData_t *threadData)
{
  (data->simulationInfo->integerParameter[data->simulationInfo->integerParamsIndex[0]] /* line_1.opening PARAM */) = ((modelica_integer) 1);
  data->modelData->integerParameterData[0].time_unvarying = 1;
  (data->simulationInfo->integerParameter[data->simulationInfo->integerParamsIndex[1]] /* line_2.opening PARAM */) = ((modelica_integer) 1);
  data->modelData->integerParameterData[1].time_unvarying = 1;
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[27]] /* G1.machine.D PARAM */) = 0.0;
  data->modelData->realParameterData[27].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[1]] /* B1.enableP_0 PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[1].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[2]] /* B1.enableQ_0 PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[2].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[3]] /* B1.enableS_b PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[3].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[4]] /* B1.enableV_b PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[4].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[5]] /* B1.enableangle_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[5].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[6]] /* B1.enabledisplayPF PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[6].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[7]] /* B1.enablefn PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[7].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[8]] /* B1.enablev_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[8].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[10]] /* B2.enableP_0 PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[10].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[11]] /* B2.enableQ_0 PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[11].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[12]] /* B2.enableS_b PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[12].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[13]] /* B2.enableV_b PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[13].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[14]] /* B2.enableangle_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[14].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[15]] /* B2.enabledisplayPF PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[15].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[16]] /* B2.enablefn PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[16].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[17]] /* B2.enablev_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[17].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[19]] /* B3.enableP_0 PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[19].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[20]] /* B3.enableQ_0 PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[20].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[21]] /* B3.enableS_b PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[21].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[22]] /* B3.enableV_b PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[22].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[23]] /* B3.enableangle_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[23].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[24]] /* B3.enabledisplayPF PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[24].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[25]] /* B3.enablefn PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[25].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[26]] /* B3.enablev_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[26].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[28]] /* G1.enableP_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[28].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[29]] /* G1.enableQ_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[29].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[30]] /* G1.enableS_b PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[30].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[31]] /* G1.enableV_b PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[31].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[32]] /* G1.enableangle_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[32].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[33]] /* G1.enabledisplayPF PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[33].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[34]] /* G1.enablefn PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[34].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[35]] /* G1.enablev_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[35].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[37]] /* G1.machine.enableP_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[37].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[38]] /* G1.machine.enableQ_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[38].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[39]] /* G1.machine.enableS_b PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[39].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[40]] /* G1.machine.enableV_b PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[40].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[41]] /* G1.machine.enableangle_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[41].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[42]] /* G1.machine.enabledisplayPF PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[42].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[43]] /* G1.machine.enablefn PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[43].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[44]] /* G1.machine.enablev_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[44].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[47]] /* infinite_bus.enableP_0 PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[47].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[48]] /* infinite_bus.enableQ_0 PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[48].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[49]] /* infinite_bus.enableS_b PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[49].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[50]] /* infinite_bus.enableV_b PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[50].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[51]] /* infinite_bus.enableangle_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[51].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[52]] /* infinite_bus.enabledisplayPF PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[52].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[53]] /* infinite_bus.enablefn PARAM */) = 0 /* false */;
  data->modelData->booleanParameterData[53].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[54]] /* infinite_bus.enablev_0 PARAM */) = 1 /* true */;
  data->modelData->booleanParameterData[54].time_unvarying = 1;
  OpenIPSL_Examples_KundurSMIB_SMIB_updateBoundParameters_0(data, threadData);
  return 0;
}

#if defined(__cplusplus)
}
#endif
