/* Algebraic */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"

#ifdef __cplusplus
extern "C" {
#endif

/* forwarded equations */
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_172(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_173(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_174(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_175(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_176(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_177(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_178(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_179(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_180(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_181(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_182(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_183(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_184(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_185(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_186(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_187(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_188(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_189(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_190(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_191(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_192(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_193(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_194(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_195(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_196(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_197(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_198(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_199(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_200(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_201(DATA* data, threadData_t *threadData);

static void functionAlg_system0(DATA *data, threadData_t *threadData)
{
  static void (*const eqFunctions[30])(DATA*, threadData_t*) = {
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_172,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_173,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_174,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_175,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_176,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_177,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_178,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_179,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_180,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_181,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_182,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_183,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_184,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_185,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_186,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_187,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_188,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_189,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_190,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_191,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_192,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_193,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_194,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_195,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_196,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_197,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_198,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_199,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_200,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_201
  };
  
  for (int id = 0; id < 30; id++) {
    eqFunctions[id](data, threadData);
  }
}
/* for continuous time variables */
int OpenIPSL_Examples_KundurSMIB_SMIB_functionAlgebraics(DATA *data, threadData_t *threadData)
{

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_ALGEBRAICS);
#endif
  data->simulationInfo->callStatistics.functionAlgebraics++;

  OpenIPSL_Examples_KundurSMIB_SMIB_function_savePreSynchronous(data, threadData);
  
  functionAlg_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_ALGEBRAICS);
#endif

  return 0;
}

#ifdef __cplusplus
}
#endif
