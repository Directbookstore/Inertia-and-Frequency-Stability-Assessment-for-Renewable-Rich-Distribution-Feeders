/* External objects file */
#include "ThesisFreqCases.BaseCase_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

void ThesisFreqCases_BaseCase_callExternalObjectDestructors(DATA *data, threadData_t *threadData)
{
  if(data->simulationInfo->extObjs)
  {
    free(data->simulationInfo->extObjs);
    data->simulationInfo->extObjs = 0;
  }
}
#if defined(__cplusplus)
}
#endif
