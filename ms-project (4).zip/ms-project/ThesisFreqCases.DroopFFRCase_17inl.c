/* Inline equation file is empty */
#include "ThesisFreqCases.DroopFFRCase_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int ThesisFreqCases_DroopFFRCase_symbolicInlineSystem(DATA *data, threadData_t *threadData){
  return -1;
}
#ifdef __cplusplus
}
#endif
