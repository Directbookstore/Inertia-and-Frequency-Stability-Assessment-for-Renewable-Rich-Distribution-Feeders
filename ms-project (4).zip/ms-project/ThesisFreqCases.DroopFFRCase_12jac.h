/* Jacobians */
static const REAL_ATTRIBUTE dummyREAL_ATTRIBUTE = omc_dummyRealAttribute;

#if defined(__cplusplus)
extern "C" {
#endif

/* Jacobian Variables */
#define ThesisFreqCases_DroopFFRCase_INDEX_JAC_H 0
int ThesisFreqCases_DroopFFRCase_functionJacH_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianH(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define ThesisFreqCases_DroopFFRCase_INDEX_JAC_F 1
int ThesisFreqCases_DroopFFRCase_functionJacF_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianF(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define ThesisFreqCases_DroopFFRCase_INDEX_JAC_D 2
int ThesisFreqCases_DroopFFRCase_functionJacD_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianD(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define ThesisFreqCases_DroopFFRCase_INDEX_JAC_C 3
int ThesisFreqCases_DroopFFRCase_functionJacC_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianC(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define ThesisFreqCases_DroopFFRCase_INDEX_JAC_B 4
int ThesisFreqCases_DroopFFRCase_functionJacB_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianB(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);


#define ThesisFreqCases_DroopFFRCase_INDEX_JAC_A 5
int ThesisFreqCases_DroopFFRCase_functionJacA_column(DATA* data, threadData_t *threadData, JACOBIAN *thisJacobian, JACOBIAN *parentJacobian);
int ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianA(DATA* data, threadData_t *threadData, JACOBIAN *jacobian);

#if defined(__cplusplus)
}
#endif
