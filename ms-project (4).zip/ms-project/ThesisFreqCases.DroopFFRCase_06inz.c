/* Initialization */
#include "ThesisFreqCases.DroopFFRCase_model.h"
#include "ThesisFreqCases.DroopFFRCase_11mix.h"
#include "ThesisFreqCases.DroopFFRCase_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void ThesisFreqCases_DroopFFRCase_functionInitialEquations_0(DATA *data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_12(DATA *data, threadData_t *threadData);


/*
equation index: 2
type: SIMPLE_ASSIGN
fHz = $START.fHz
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_2(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,2};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* fHz STATE(1,rocofHzps) */) = ((modelica_real *)((data->modelData->realVarsData[0] /* fHz STATE(1,rocofHzps) */).attribute .start.data))[0];
  threadData->lastEquationSolved = 2;
}
extern void ThesisFreqCases_DroopFFRCase_eqFunction_13(DATA *data, threadData_t *threadData);

extern void ThesisFreqCases_DroopFFRCase_eqFunction_14(DATA *data, threadData_t *threadData);


/*
equation index: 5
type: SIMPLE_ASSIGN
Pffr = min(max(Pffr_raw, -PmaxFFR), PmaxFFR)
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_5(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,5};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[9]] /* Pffr variable */) = fmin(fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[10]] /* Pffr_raw variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[3]] /* PmaxFFR PARAM */))),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[3]] /* PmaxFFR PARAM */));
  threadData->lastEquationSolved = 5;
}
extern void ThesisFreqCases_DroopFFRCase_eqFunction_17(DATA *data, threadData_t *threadData);


/*
equation index: 7
type: SIMPLE_ASSIGN
Pdroop = min(max(Pdroop_raw, -PmaxDroop), PmaxDroop)
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_7(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,7};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[7]] /* Pdroop variable */) = fmin(fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[8]] /* Pdroop_raw variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[2]] /* PmaxDroop PARAM */))),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[2]] /* PmaxDroop PARAM */));
  threadData->lastEquationSolved = 7;
}

/*
equation index: 8
type: SIMPLE_ASSIGN
Psupport = min(max(Pdroop + Pffr, -PmaxTotal), PmaxTotal)
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_8(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,8};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[11]] /* Psupport variable */) = fmin(fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[7]] /* Pdroop variable */) + (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[9]] /* Pffr variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[4]] /* PmaxTotal PARAM */))),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[4]] /* PmaxTotal PARAM */));
  threadData->lastEquationSolved = 8;
}

/*
equation index: 9
type: SIMPLE_ASSIGN
$DER.df = 0.5 * f0 * (Pdist + Psupport - D * df) / H
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_9(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,9};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* der(df) DUMMY_DER */) = (0.5) * (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[8]] /* f0 PARAM */)) * (DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[6]] /* Pdist variable */) + (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[11]] /* Psupport variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[0]] /* D PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* df DUMMY_STATE */))),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[1]] /* H PARAM */),"H",equationIndexes)));
  threadData->lastEquationSolved = 9;
}

/*
equation index: 10
type: SIMPLE_ASSIGN
rocofHzps = $DER.df
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_10(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,10};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* rocofHzps variable */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* der(df) DUMMY_DER */);
  threadData->lastEquationSolved = 10;
}
extern void ThesisFreqCases_DroopFFRCase_eqFunction_23(DATA *data, threadData_t *threadData);

OMC_DISABLE_OPT
void ThesisFreqCases_DroopFFRCase_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  static void (*const eqFunctions[11])(DATA*, threadData_t*) = {
    ThesisFreqCases_DroopFFRCase_eqFunction_12,
    ThesisFreqCases_DroopFFRCase_eqFunction_2,
    ThesisFreqCases_DroopFFRCase_eqFunction_13,
    ThesisFreqCases_DroopFFRCase_eqFunction_14,
    ThesisFreqCases_DroopFFRCase_eqFunction_5,
    ThesisFreqCases_DroopFFRCase_eqFunction_17,
    ThesisFreqCases_DroopFFRCase_eqFunction_7,
    ThesisFreqCases_DroopFFRCase_eqFunction_8,
    ThesisFreqCases_DroopFFRCase_eqFunction_9,
    ThesisFreqCases_DroopFFRCase_eqFunction_10,
    ThesisFreqCases_DroopFFRCase_eqFunction_23
  };
  
  for (int id = 0; id < 11; id++) {
    eqFunctions[id](data, threadData);
  }
}

int ThesisFreqCases_DroopFFRCase_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  data->simulationInfo->discreteCall = 1;
  ThesisFreqCases_DroopFFRCase_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  return 0;
}

/* No ThesisFreqCases_DroopFFRCase_functionInitialEquations_lambda0 function */

int ThesisFreqCases_DroopFFRCase_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  return 0;
}


#if defined(__cplusplus)
}
#endif
