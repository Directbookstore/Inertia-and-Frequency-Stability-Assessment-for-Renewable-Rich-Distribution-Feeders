#include "omc_simulation_settings.h"
#include "ThesisFreqCases.DroopCase_functions.h"
#ifdef __cplusplus
extern "C" {
#endif

#include "ThesisFreqCases.DroopCase_includes.h"



#ifdef __cplusplus
}
#endif
