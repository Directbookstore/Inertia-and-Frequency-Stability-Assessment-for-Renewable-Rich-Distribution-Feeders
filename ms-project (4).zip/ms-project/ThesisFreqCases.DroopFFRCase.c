/* Main Simulation File */

#if defined(__cplusplus)
extern "C" {
#endif

#include "ThesisFreqCases.DroopFFRCase_model.h"
#include "simulation/solver/events.h"
#include "util/real_array.h"

/* FIXME these defines are ugly and hard to read, why not use direct function pointers instead? */
#define prefixedName_performSimulation ThesisFreqCases_DroopFFRCase_performSimulation
#define prefixedName_updateContinuousSystem ThesisFreqCases_DroopFFRCase_updateContinuousSystem
#include <simulation/solver/perform_simulation.c.inc>

#define prefixedName_performQSSSimulation ThesisFreqCases_DroopFFRCase_performQSSSimulation
#include <simulation/solver/perform_qss_simulation.c.inc>


/* dummy VARINFO and FILEINFO */
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;

int ThesisFreqCases_DroopFFRCase_input_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int ThesisFreqCases_DroopFFRCase_input_function_init(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int ThesisFreqCases_DroopFFRCase_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int ThesisFreqCases_DroopFFRCase_inputNames(DATA *data, char ** names){
  
  return 0;
}

int ThesisFreqCases_DroopFFRCase_data_function(DATA *data, threadData_t *threadData)
{
  return 0;
}

int ThesisFreqCases_DroopFFRCase_dataReconciliationInputNames(DATA *data, char ** names){
  
  return 0;
}

int ThesisFreqCases_DroopFFRCase_dataReconciliationUnmeasuredVariables(DATA *data, char ** names)
{
  
  return 0;
}

int ThesisFreqCases_DroopFFRCase_output_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int ThesisFreqCases_DroopFFRCase_setc_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int ThesisFreqCases_DroopFFRCase_setb_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}


/*
equation index: 12
type: SIMPLE_ASSIGN
Pdist = if time < tEvent then 0.0 else dPstep
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_12(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,12};
  modelica_boolean tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  tmp1 = 1.0;
  tmp2 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[11]] /* tEvent PARAM */));
  relationhysteresis(data, &tmp0, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[11]] /* tEvent PARAM */), tmp1, tmp2, 0, Less, LessZC);
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[6]] /* Pdist variable */) = (tmp0?0.0:(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[6]] /* dPstep PARAM */));
  threadData->lastEquationSolved = 12;
}

/*
equation index: 13
type: SIMPLE_ASSIGN
df = fHz - f0
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_13(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,13};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* df DUMMY_STATE */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* fHz STATE(1,rocofHzps) */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[8]] /* f0 PARAM */);
  threadData->lastEquationSolved = 13;
}

/*
equation index: 14
type: SIMPLE_ASSIGN
Pffr_raw = if noEvent(time < tEvent) or noEvent(time > tEvent + ffrDuration) or noEvent(abs(df) <= deadband) then 0.0 else (-ffrGain) * df
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_14(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,14};
  modelica_boolean tmp3;
  modelica_boolean tmp4;
  modelica_boolean tmp5;
  tmp3 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[11]] /* tEvent PARAM */));
  tmp4 = Greater(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[11]] /* tEvent PARAM */) + (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[9]] /* ffrDuration PARAM */));
  tmp5 = LessEq(fabs((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* df DUMMY_STATE */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[7]] /* deadband PARAM */));
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[10]] /* Pffr_raw variable */) = (((tmp3 || tmp4) || tmp5)?0.0:((-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[10]] /* ffrGain PARAM */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* df DUMMY_STATE */)));
  threadData->lastEquationSolved = 14;
}

/*
equation index: 15
type: SIMPLE_ASSIGN
$cse2 = max(Pffr_raw, -PmaxFFR)
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_15(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,15};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[4]] /* $cse2 variable */) = fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[10]] /* Pffr_raw variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[3]] /* PmaxFFR PARAM */)));
  threadData->lastEquationSolved = 15;
}

/*
equation index: 16
type: SIMPLE_ASSIGN
Pffr = min($cse2, PmaxFFR)
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_16(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,16};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[9]] /* Pffr variable */) = fmin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[4]] /* $cse2 variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[3]] /* PmaxFFR PARAM */));
  threadData->lastEquationSolved = 16;
}

/*
equation index: 17
type: SIMPLE_ASSIGN
Pdroop_raw = if noEvent(abs(df) <= deadband) then 0.0 else (-df) / R
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_17(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,17};
  modelica_boolean tmp6;
  tmp6 = LessEq(fabs((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* df DUMMY_STATE */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[7]] /* deadband PARAM */));
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[8]] /* Pdroop_raw variable */) = (tmp6?0.0:DIVISION_SIM((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* df DUMMY_STATE */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[5]] /* R PARAM */),"R",equationIndexes));
  threadData->lastEquationSolved = 17;
}

/*
equation index: 18
type: SIMPLE_ASSIGN
$cse1 = max(Pdroop_raw, -PmaxDroop)
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_18(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,18};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[3]] /* $cse1 variable */) = fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[8]] /* Pdroop_raw variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[2]] /* PmaxDroop PARAM */)));
  threadData->lastEquationSolved = 18;
}

/*
equation index: 19
type: SIMPLE_ASSIGN
Pdroop = min($cse1, PmaxDroop)
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_19(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,19};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[7]] /* Pdroop variable */) = fmin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[3]] /* $cse1 variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[2]] /* PmaxDroop PARAM */));
  threadData->lastEquationSolved = 19;
}

/*
equation index: 20
type: SIMPLE_ASSIGN
$cse3 = max(Pdroop + Pffr, -PmaxTotal)
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_20(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,20};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[5]] /* $cse3 variable */) = fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[7]] /* Pdroop variable */) + (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[9]] /* Pffr variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[4]] /* PmaxTotal PARAM */)));
  threadData->lastEquationSolved = 20;
}

/*
equation index: 21
type: SIMPLE_ASSIGN
Psupport = min($cse3, PmaxTotal)
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_21(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,21};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[11]] /* Psupport variable */) = fmin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[5]] /* $cse3 variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[4]] /* PmaxTotal PARAM */));
  threadData->lastEquationSolved = 21;
}

/*
equation index: 22
type: SIMPLE_ASSIGN
rocofHzps = 0.5 * f0 * (Pdist + Psupport - D * df) / H
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_22(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,22};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* rocofHzps variable */) = (0.5) * (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[8]] /* f0 PARAM */)) * (DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[6]] /* Pdist variable */) + (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[11]] /* Psupport variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[0]] /* D PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* df DUMMY_STATE */))),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[1]] /* H PARAM */),"H",equationIndexes)));
  threadData->lastEquationSolved = 22;
}

/*
equation index: 23
type: SIMPLE_ASSIGN
$DER.fHz = rocofHzps
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_23(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,23};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[1]] /* der(fHz) STATE_DER */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* rocofHzps variable */);
  threadData->lastEquationSolved = 23;
}

/*
equation index: 24
type: SIMPLE_ASSIGN
$DER.df = rocofHzps
*/
void ThesisFreqCases_DroopFFRCase_eqFunction_24(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,24};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* der(df) DUMMY_DER */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* rocofHzps variable */);
  threadData->lastEquationSolved = 24;
}

OMC_DISABLE_OPT
int ThesisFreqCases_DroopFFRCase_functionDAE(DATA *data, threadData_t *threadData)
{
  int equationIndexes[1] = {0};
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_DAE);
#endif

  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  ThesisFreqCases_DroopFFRCase_functionLocalKnownVars(data, threadData);
  static void (*const eqFunctions[13])(DATA*, threadData_t*) = {
    ThesisFreqCases_DroopFFRCase_eqFunction_12,
    ThesisFreqCases_DroopFFRCase_eqFunction_13,
    ThesisFreqCases_DroopFFRCase_eqFunction_14,
    ThesisFreqCases_DroopFFRCase_eqFunction_15,
    ThesisFreqCases_DroopFFRCase_eqFunction_16,
    ThesisFreqCases_DroopFFRCase_eqFunction_17,
    ThesisFreqCases_DroopFFRCase_eqFunction_18,
    ThesisFreqCases_DroopFFRCase_eqFunction_19,
    ThesisFreqCases_DroopFFRCase_eqFunction_20,
    ThesisFreqCases_DroopFFRCase_eqFunction_21,
    ThesisFreqCases_DroopFFRCase_eqFunction_22,
    ThesisFreqCases_DroopFFRCase_eqFunction_23,
    ThesisFreqCases_DroopFFRCase_eqFunction_24
  };
  
  for (int id = 0; id < 13; id++) {
    eqFunctions[id](data, threadData);
  }
  data->simulationInfo->discreteCall = 0;
  
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_DAE);
#endif
  return 0;
}


int ThesisFreqCases_DroopFFRCase_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

/* forwarded equations */
extern void ThesisFreqCases_DroopFFRCase_eqFunction_12(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_13(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_14(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_15(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_16(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_17(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_18(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_19(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_20(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_21(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_22(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopFFRCase_eqFunction_23(DATA* data, threadData_t *threadData);

static void functionODE_system0(DATA *data, threadData_t *threadData)
{
  static void (*const eqFunctions[12])(DATA*, threadData_t*) = {
    ThesisFreqCases_DroopFFRCase_eqFunction_12,
    ThesisFreqCases_DroopFFRCase_eqFunction_13,
    ThesisFreqCases_DroopFFRCase_eqFunction_14,
    ThesisFreqCases_DroopFFRCase_eqFunction_15,
    ThesisFreqCases_DroopFFRCase_eqFunction_16,
    ThesisFreqCases_DroopFFRCase_eqFunction_17,
    ThesisFreqCases_DroopFFRCase_eqFunction_18,
    ThesisFreqCases_DroopFFRCase_eqFunction_19,
    ThesisFreqCases_DroopFFRCase_eqFunction_20,
    ThesisFreqCases_DroopFFRCase_eqFunction_21,
    ThesisFreqCases_DroopFFRCase_eqFunction_22,
    ThesisFreqCases_DroopFFRCase_eqFunction_23
  };
  
  for (int id = 0; id < 12; id++) {
    eqFunctions[id](data, threadData);
  }
}

int ThesisFreqCases_DroopFFRCase_functionODE(DATA *data, threadData_t *threadData)
{
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_FUNCTION_ODE);
#endif

  
  data->simulationInfo->callStatistics.functionODE++;
  
  ThesisFreqCases_DroopFFRCase_functionLocalKnownVars(data, threadData);
  functionODE_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_FUNCTION_ODE);
#endif

  return 0;
}

/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char **argv, DATA *data, threadData_t *threadData);
extern int _main_OptimizationRuntime(int argc, char **argv, DATA *data, threadData_t *threadData);

#include "ThesisFreqCases.DroopFFRCase_12jac.h"
#include "ThesisFreqCases.DroopFFRCase_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks ThesisFreqCases_DroopFFRCase_callback = {
  (int (*)(DATA *, threadData_t *, void *)) ThesisFreqCases_DroopFFRCase_performSimulation,    /* performSimulation */
  (int (*)(DATA *, threadData_t *, void *)) ThesisFreqCases_DroopFFRCase_performQSSSimulation,    /* performQSSSimulation */
  ThesisFreqCases_DroopFFRCase_updateContinuousSystem,    /* updateContinuousSystem */
  ThesisFreqCases_DroopFFRCase_callExternalObjectDestructors,    /* callExternalObjectDestructors */
  NULL,    /* initialNonLinearSystem */
  NULL,    /* initialLinearSystem */
  NULL,    /* initialMixedSystem */
  #if !defined(OMC_NO_STATESELECTION)
  ThesisFreqCases_DroopFFRCase_initializeStateSets,
  #else
  NULL,
  #endif    /* initializeStateSets */
  ThesisFreqCases_DroopFFRCase_initializeDAEmodeData,
  ThesisFreqCases_DroopFFRCase_functionODE,
  ThesisFreqCases_DroopFFRCase_functionAlgebraics,
  ThesisFreqCases_DroopFFRCase_functionDAE,
  ThesisFreqCases_DroopFFRCase_functionLocalKnownVars,
  ThesisFreqCases_DroopFFRCase_input_function,
  ThesisFreqCases_DroopFFRCase_input_function_init,
  ThesisFreqCases_DroopFFRCase_input_function_updateStartValues,
  ThesisFreqCases_DroopFFRCase_data_function,
  ThesisFreqCases_DroopFFRCase_output_function,
  ThesisFreqCases_DroopFFRCase_setc_function,
  ThesisFreqCases_DroopFFRCase_setb_function,
  ThesisFreqCases_DroopFFRCase_function_storeDelayed,
  ThesisFreqCases_DroopFFRCase_function_storeSpatialDistribution,
  ThesisFreqCases_DroopFFRCase_function_initSpatialDistribution,
  ThesisFreqCases_DroopFFRCase_updateBoundVariableAttributes,
  ThesisFreqCases_DroopFFRCase_functionInitialEquations,
  GLOBAL_EQUIDISTANT_HOMOTOPY,
  NULL,
  ThesisFreqCases_DroopFFRCase_functionRemovedInitialEquations,
  ThesisFreqCases_DroopFFRCase_updateBoundParameters,
  ThesisFreqCases_DroopFFRCase_checkForAsserts,
  ThesisFreqCases_DroopFFRCase_function_ZeroCrossingsEquations,
  ThesisFreqCases_DroopFFRCase_function_ZeroCrossings,
  ThesisFreqCases_DroopFFRCase_function_updateRelations,
  ThesisFreqCases_DroopFFRCase_zeroCrossingDescription,
  ThesisFreqCases_DroopFFRCase_relationDescription,
  ThesisFreqCases_DroopFFRCase_function_initSample,
  ThesisFreqCases_DroopFFRCase_INDEX_JAC_A,
  ThesisFreqCases_DroopFFRCase_INDEX_JAC_B,
  ThesisFreqCases_DroopFFRCase_INDEX_JAC_C,
  ThesisFreqCases_DroopFFRCase_INDEX_JAC_D,
  ThesisFreqCases_DroopFFRCase_INDEX_JAC_F,
  ThesisFreqCases_DroopFFRCase_INDEX_JAC_H,
  ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianA,
  ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianB,
  ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianC,
  ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianD,
  ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianF,
  ThesisFreqCases_DroopFFRCase_initialAnalyticJacobianH,
  ThesisFreqCases_DroopFFRCase_functionJacA_column,
  ThesisFreqCases_DroopFFRCase_functionJacB_column,
  ThesisFreqCases_DroopFFRCase_functionJacC_column,
  ThesisFreqCases_DroopFFRCase_functionJacD_column,
  ThesisFreqCases_DroopFFRCase_functionJacF_column,
  ThesisFreqCases_DroopFFRCase_functionJacH_column,
  ThesisFreqCases_DroopFFRCase_linear_model_frame,
  ThesisFreqCases_DroopFFRCase_linear_model_datarecovery_frame,
  ThesisFreqCases_DroopFFRCase_mayer,
  ThesisFreqCases_DroopFFRCase_lagrange,
  ThesisFreqCases_DroopFFRCase_getInputVarIndicesInOptimization,
  ThesisFreqCases_DroopFFRCase_pickUpBoundsForInputsInOptimization,
  ThesisFreqCases_DroopFFRCase_setInputData,
  ThesisFreqCases_DroopFFRCase_getTimeGrid,
  ThesisFreqCases_DroopFFRCase_symbolicInlineSystem,
  ThesisFreqCases_DroopFFRCase_function_initSynchronous,
  ThesisFreqCases_DroopFFRCase_function_updateSynchronous,
  ThesisFreqCases_DroopFFRCase_function_equationsSynchronous,
  ThesisFreqCases_DroopFFRCase_inputNames,
  ThesisFreqCases_DroopFFRCase_dataReconciliationInputNames,
  ThesisFreqCases_DroopFFRCase_dataReconciliationUnmeasuredVariables,
  NULL,
  NULL,
  NULL,
  NULL,
  -1,
  NULL,
  NULL,
  -1

};

#define _OMC_LIT_RESOURCE_0_name_data "Complex"
#define _OMC_LIT_RESOURCE_0_dir_data "C:/Users/ADMIN/AppData/Roaming/.openmodelica/libraries/Complex 4.1.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_name,7,_OMC_LIT_RESOURCE_0_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir,77,_OMC_LIT_RESOURCE_0_dir_data);

#define _OMC_LIT_RESOURCE_1_name_data "Modelica"
#define _OMC_LIT_RESOURCE_1_dir_data "C:/Users/ADMIN/AppData/Roaming/.openmodelica/libraries/Modelica 4.1.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_name,8,_OMC_LIT_RESOURCE_1_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir,78,_OMC_LIT_RESOURCE_1_dir_data);

#define _OMC_LIT_RESOURCE_2_name_data "ModelicaServices"
#define _OMC_LIT_RESOURCE_2_dir_data "C:/Users/ADMIN/AppData/Roaming/.openmodelica/libraries/ModelicaServices 4.1.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_name,16,_OMC_LIT_RESOURCE_2_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir,86,_OMC_LIT_RESOURCE_2_dir_data);

#define _OMC_LIT_RESOURCE_3_name_data "ThesisFreqCases"
#define _OMC_LIT_RESOURCE_3_dir_data "C:/Users/ADMIN/Desktop/ms-project"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_name,15,_OMC_LIT_RESOURCE_3_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir,33,_OMC_LIT_RESOURCE_3_dir_data);

static const MMC_DEFSTRUCTLIT(_OMC_LIT_RESOURCES,8,MMC_ARRAY_TAG) {MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir)}};
void ThesisFreqCases_DroopFFRCase_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  threadData->localRoots[LOCAL_ROOT_SIMULATION_DATA] = data;
  data->callback = &ThesisFreqCases_DroopFFRCase_callback;
  OpenModelica_updateUriMapping(threadData, MMC_REFSTRUCTLIT(_OMC_LIT_RESOURCES));
  data->modelData->modelName = "ThesisFreqCases.DroopFFRCase";
  data->modelData->modelFilePrefix = "ThesisFreqCases.DroopFFRCase";
  data->modelData->modelFileName = "ThesisFreqCases.mo";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "C:/Users/ADMIN/Desktop/ms-project";
  data->modelData->modelGUID = "{33f7e514-762c-4738-896b-84bab362e495}";
  #if defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME)
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  #else
  #if defined(_MSC_VER) /* handle joke compilers */
  {
  /* for MSVC we encode a string like char x[] = {'a', 'b', 'c', '\0'} */
  /* because the string constant limit is 65535 bytes */
  static const char contents_init[] =
    #include "ThesisFreqCases.DroopFFRCase_init.c"
    ;
  static const char contents_info[] =
    #include "ThesisFreqCases.DroopFFRCase_info.c"
    ;
    data->modelData->initXMLData = contents_init;
    data->modelData->modelDataXml.infoXMLData = contents_info;
  }
  #else /* handle real compilers */
  data->modelData->initXMLData =
  #include "ThesisFreqCases.DroopFFRCase_init.c"
    ;
  data->modelData->modelDataXml.infoXMLData =
  #include "ThesisFreqCases.DroopFFRCase_info.c"
    ;
  #endif /* defined(_MSC_VER) */
  #endif /* defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME) */
  data->modelData->modelDataXml.fileName = "ThesisFreqCases.DroopFFRCase_info.json";
  data->modelData->resourcesDir = NULL;
  data->modelData->runTestsuite = 0;
  data->modelData->nStatesArray = 1;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesRealArray = 14;
  data->modelData->nVariablesIntegerArray = 0;
  data->modelData->nVariablesBooleanArray = 0;
  data->modelData->nVariablesStringArray = 0;
  data->modelData->nParametersRealArray = 12;
  data->modelData->nParametersIntegerArray = 0;
  data->modelData->nParametersBooleanArray = 0;
  data->modelData->nParametersStringArray = 0;
  data->modelData->nParametersReal = 12;
  data->modelData->nParametersInteger = 0;
  data->modelData->nParametersBoolean = 0;
  data->modelData->nParametersString = 0;
  data->modelData->nAliasRealArray = 0;
  data->modelData->nAliasIntegerArray = 0;
  data->modelData->nAliasBooleanArray = 0;
  data->modelData->nAliasStringArray = 0;
  data->modelData->nInputVars = 0;
  data->modelData->nOutputVars = 0;
  data->modelData->nZeroCrossings = 1;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 1;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 0;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 25;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 0;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 6;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  data->modelData->nDelayExpressions = 0;
  data->modelData->nBaseClocks = 0;
  data->modelData->nSpatialDistributions = 0;
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
  data->modelData->nSetcVars = 0;
  data->modelData->ndataReconVars = 0;
  data->modelData->nSetbVars = 0;
  data->modelData->nRelatedBoundaryConditions = 0;
  data->modelData->linearizationDumpLanguage = OMC_LINEARIZE_DUMP_LANGUAGE_MODELICA;
}

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}


#if defined(__MINGW32__) || defined(_MSC_VER)

#if !defined(_UNICODE)
#define _UNICODE
#endif
#if !defined(UNICODE)
#define UNICODE
#endif

#include <windows.h>
char** omc_fixWindowsArgv(int argc, wchar_t **wargv)
{
  char** newargv;
  /* Support for non-ASCII characters
  * Read the unicode command line arguments and translate it to char*
  */
  newargv = (char**)malloc(argc*sizeof(char*));
  for (int i = 0; i < argc; i++) {
    newargv[i] = omc_wchar_to_multibyte_str(wargv[i]);
  }
  return newargv;
}

#define OMC_MAIN wmain
#define OMC_CHAR wchar_t
#define OMC_EXPORT __declspec(dllexport) extern

#else
#define omc_fixWindowsArgv(N, A) (A)
#define OMC_MAIN main
#define OMC_CHAR char
#define OMC_EXPORT extern
#endif

#if defined(threadData)
#undef threadData
#endif
/* call the simulation runtime main from our main! */
#if defined(OMC_DLL_MAIN_DEFINE)
OMC_EXPORT int omcDllMain(int argc, OMC_CHAR **argv)
#else
int OMC_MAIN(int argc, OMC_CHAR** argv)
#endif
{
  char** newargv = omc_fixWindowsArgv(argc, argv);
  /*
    Set the error functions to be used for simulation.
    The default value for them is 'functions' version. Change it here to 'simulation' versions
  */
  omc_assert = omc_assert_simulation;
  omc_assert_withEquationIndexes = omc_assert_simulation_withEquationIndexes;

  omc_assert_warning_withEquationIndexes = omc_assert_warning_simulation_withEquationIndexes;
  omc_assert_warning = omc_assert_warning_simulation;
  omc_terminate = omc_terminate_simulation;
  omc_throw = omc_throw_simulation;

  int res;
  DATA data;
  MODEL_DATA modelData;
  SIMULATION_INFO simInfo;
  data.modelData = &modelData;
  data.simulationInfo = &simInfo;
  measure_time_flag = 0;
  compiledInDAEMode = 0;
  compiledWithSymSolver = 0;
  MMC_INIT(0);
  omc_alloc_interface.init();
  {
    MMC_TRY_TOP()
  
    MMC_TRY_STACK()
  
    ThesisFreqCases_DroopFFRCase_setupDataStruc(&data, threadData);
    res = _main_initRuntimeAndSimulation(argc, newargv, &data, threadData);
    if(res == 0) {
      if (omc_flag[FLAG_MOO_OPTIMIZATION]) {
        res = _main_OptimizationRuntime(argc, newargv, &data, threadData);
      } else {
        res = _main_SimulationRuntime(argc, newargv, &data, threadData);
      }
    }
    
    MMC_ELSE()
    rml_execution_failed();
    fprintf(stderr, "Stack overflow detected and was not caught.\nSend us a bug report at https://trac.openmodelica.org/OpenModelica/newticket\n    Include the following trace:\n");
    printStacktraceMessages();
    fflush(NULL);
    return 1;
    MMC_CATCH_STACK()
    
    MMC_CATCH_TOP(return rml_execution_failed());
  }

  fflush(NULL);
  return res;
}

#ifdef __cplusplus
}
#endif


