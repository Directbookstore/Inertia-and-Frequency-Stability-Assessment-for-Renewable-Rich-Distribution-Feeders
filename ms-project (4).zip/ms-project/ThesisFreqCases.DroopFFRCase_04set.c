/* Initial State Set */
#include "ThesisFreqCases.DroopFFRCase_model.h"
#include "ThesisFreqCases.DroopFFRCase_11mix.h"
#include "ThesisFreqCases.DroopFFRCase_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void ThesisFreqCases_DroopFFRCase_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif
