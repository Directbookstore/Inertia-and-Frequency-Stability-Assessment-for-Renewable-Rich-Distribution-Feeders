/* Mixed Systems */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#include "OpenIPSL.Examples.KundurSMIB.SMIB_11mix.h"
/* initial mixed systems */
/* initial_lambda0 mixed systems */
/* parameter mixed systems */
/* model mixed systems */
/* jacobians mixed systems */

