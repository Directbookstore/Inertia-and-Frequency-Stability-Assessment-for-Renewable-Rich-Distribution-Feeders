/* Linear Systems */
#include "ThesisFreqCases.DroopFFRCase_model.h"
#include "ThesisFreqCases.DroopFFRCase_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* linear systems */


#if defined(__cplusplus)
}
#endif
