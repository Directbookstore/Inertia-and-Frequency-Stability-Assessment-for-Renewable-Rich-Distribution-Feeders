/* Delay */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

int OpenIPSL_Examples_KundurSMIB_SMIB_function_storeDelayed(DATA *data, threadData_t *threadData)
{
  int equationIndexes[2] = {1,-1};
  
  return 0;
}

#if defined(__cplusplus)
}
#endif
