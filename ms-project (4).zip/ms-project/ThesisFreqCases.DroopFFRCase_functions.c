#include "omc_simulation_settings.h"
#include "ThesisFreqCases.DroopFFRCase_functions.h"
#ifdef __cplusplus
extern "C" {
#endif

#include "ThesisFreqCases.DroopFFRCase_includes.h"



#ifdef __cplusplus
}
#endif
