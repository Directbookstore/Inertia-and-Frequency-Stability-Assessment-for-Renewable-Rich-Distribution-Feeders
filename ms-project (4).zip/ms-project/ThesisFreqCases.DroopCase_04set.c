/* Initial State Set */
#include "ThesisFreqCases.DroopCase_model.h"
#include "ThesisFreqCases.DroopCase_11mix.h"
#include "ThesisFreqCases.DroopCase_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void ThesisFreqCases_DroopCase_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif
