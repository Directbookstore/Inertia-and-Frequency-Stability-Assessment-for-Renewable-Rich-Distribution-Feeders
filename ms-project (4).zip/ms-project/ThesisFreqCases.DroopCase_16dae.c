/* DAE residuals is empty */
#include "ThesisFreqCases.DroopCase_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int ThesisFreqCases_DroopCase_initializeDAEmodeData(DATA* data, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
