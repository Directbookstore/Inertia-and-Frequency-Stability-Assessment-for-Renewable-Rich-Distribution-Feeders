/* Inline equation file is empty */
#include "ThesisFreqCases.BaseCase_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int ThesisFreqCases_BaseCase_symbolicInlineSystem(DATA *data, threadData_t *threadData){
  return -1;
}
#ifdef __cplusplus
}
#endif
