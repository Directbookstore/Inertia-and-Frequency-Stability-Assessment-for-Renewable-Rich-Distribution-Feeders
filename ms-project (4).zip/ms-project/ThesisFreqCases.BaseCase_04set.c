/* Initial State Set */
#include "ThesisFreqCases.BaseCase_model.h"
#include "ThesisFreqCases.BaseCase_11mix.h"
#include "ThesisFreqCases.BaseCase_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void ThesisFreqCases_BaseCase_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif
