/* Inline equation file is empty */
#include "ThesisFreqCases.DroopCase_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int ThesisFreqCases_DroopCase_symbolicInlineSystem(DATA *data, threadData_t *threadData){
  return -1;
}
#ifdef __cplusplus
}
#endif
