/* Mixed Systems */
#include "ThesisFreqCases.DroopFFRCase_model.h"
#include "ThesisFreqCases.DroopFFRCase_11mix.h"
/* initial mixed systems */
/* initial_lambda0 mixed systems */
/* parameter mixed systems */
/* model mixed systems */
/* jacobians mixed systems */

