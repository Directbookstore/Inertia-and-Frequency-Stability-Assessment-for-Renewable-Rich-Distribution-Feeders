/* DAE residuals is empty */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int OpenIPSL_Examples_KundurSMIB_SMIB_initializeDAEmodeData(DATA* data, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
