/* Initialization */
#include "ThesisFreqCases.DroopCase_model.h"
#include "ThesisFreqCases.DroopCase_11mix.h"
#include "ThesisFreqCases.DroopCase_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void ThesisFreqCases_DroopCase_functionInitialEquations_0(DATA *data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_16(DATA *data, threadData_t *threadData);


/*
equation index: 2
type: SIMPLE_ASSIGN
df = $START.df
*/
void ThesisFreqCases_DroopCase_eqFunction_2(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,2};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* df STATE(1) */) = ((modelica_real *)((data->modelData->realVarsData[0] /* df STATE(1) */).attribute .start.data))[0];
  threadData->lastEquationSolved = 2;
}
extern void ThesisFreqCases_DroopCase_eqFunction_30(DATA *data, threadData_t *threadData);


/*
equation index: 4
type: SIMPLE_ASSIGN
df_droop = $START.df_droop
*/
void ThesisFreqCases_DroopCase_eqFunction_4(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,4};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[1]] /* df_droop STATE(1) */) = ((modelica_real *)((data->modelData->realVarsData[1] /* df_droop STATE(1) */).attribute .start.data))[0];
  threadData->lastEquationSolved = 4;
}
extern void ThesisFreqCases_DroopCase_eqFunction_19(DATA *data, threadData_t *threadData);


/*
equation index: 6
type: SIMPLE_ASSIGN
Pdroop = min(max(Pdroop_raw, -PmaxDroop), PmaxDroop)
*/
void ThesisFreqCases_DroopCase_eqFunction_6(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,6};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[11]] /* Pdroop variable */) = fmin(fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* Pdroop_raw variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[2]] /* PmaxDroop PARAM */))),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[2]] /* PmaxDroop PARAM */));
  threadData->lastEquationSolved = 6;
}
extern void ThesisFreqCases_DroopCase_eqFunction_17(DATA *data, threadData_t *threadData);


/*
equation index: 8
type: SIMPLE_ASSIGN
df_ffr = $START.df_ffr
*/
void ThesisFreqCases_DroopCase_eqFunction_8(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,8};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* df_ffr STATE(1) */) = ((modelica_real *)((data->modelData->realVarsData[2] /* df_ffr STATE(1) */).attribute .start.data))[0];
  threadData->lastEquationSolved = 8;
}
extern void ThesisFreqCases_DroopCase_eqFunction_22(DATA *data, threadData_t *threadData);


/*
equation index: 10
type: SIMPLE_ASSIGN
Pffr = min(max(Pffr_raw, -PmaxFFR), PmaxFFR)
*/
void ThesisFreqCases_DroopCase_eqFunction_10(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,10};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* Pffr variable */) = fmin(fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[14]] /* Pffr_raw variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[3]] /* PmaxFFR PARAM */))),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[3]] /* PmaxFFR PARAM */));
  threadData->lastEquationSolved = 10;
}

/*
equation index: 11
type: SIMPLE_ASSIGN
Psupport = min(max(Pdroop + Pffr, -PmaxTotal), PmaxTotal)
*/
void ThesisFreqCases_DroopCase_eqFunction_11(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,11};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[15]] /* Psupport variable */) = fmin(fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[11]] /* Pdroop variable */) + (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* Pffr variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[4]] /* PmaxTotal PARAM */))),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[4]] /* PmaxTotal PARAM */));
  threadData->lastEquationSolved = 11;
}
extern void ThesisFreqCases_DroopCase_eqFunction_27(DATA *data, threadData_t *threadData);


/*
equation index: 13
type: SIMPLE_ASSIGN
rocofHzps = $DER.df
*/
void ThesisFreqCases_DroopCase_eqFunction_13(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,13};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[17]] /* rocofHzps variable */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[3]] /* der(df) STATE_DER */);
  threadData->lastEquationSolved = 13;
}
extern void ThesisFreqCases_DroopCase_eqFunction_29(DATA *data, threadData_t *threadData);

extern void ThesisFreqCases_DroopCase_eqFunction_18(DATA *data, threadData_t *threadData);

OMC_DISABLE_OPT
void ThesisFreqCases_DroopCase_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  static void (*const eqFunctions[15])(DATA*, threadData_t*) = {
    ThesisFreqCases_DroopCase_eqFunction_16,
    ThesisFreqCases_DroopCase_eqFunction_2,
    ThesisFreqCases_DroopCase_eqFunction_30,
    ThesisFreqCases_DroopCase_eqFunction_4,
    ThesisFreqCases_DroopCase_eqFunction_19,
    ThesisFreqCases_DroopCase_eqFunction_6,
    ThesisFreqCases_DroopCase_eqFunction_17,
    ThesisFreqCases_DroopCase_eqFunction_8,
    ThesisFreqCases_DroopCase_eqFunction_22,
    ThesisFreqCases_DroopCase_eqFunction_10,
    ThesisFreqCases_DroopCase_eqFunction_11,
    ThesisFreqCases_DroopCase_eqFunction_27,
    ThesisFreqCases_DroopCase_eqFunction_13,
    ThesisFreqCases_DroopCase_eqFunction_29,
    ThesisFreqCases_DroopCase_eqFunction_18
  };
  
  for (int id = 0; id < 15; id++) {
    eqFunctions[id](data, threadData);
  }
}

int ThesisFreqCases_DroopCase_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  data->simulationInfo->discreteCall = 1;
  ThesisFreqCases_DroopCase_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  return 0;
}

/* No ThesisFreqCases_DroopCase_functionInitialEquations_lambda0 function */

int ThesisFreqCases_DroopCase_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  return 0;
}


#if defined(__cplusplus)
}
#endif
