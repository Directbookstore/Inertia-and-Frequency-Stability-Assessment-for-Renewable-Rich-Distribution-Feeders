/* Main Simulation File */

#if defined(__cplusplus)
extern "C" {
#endif

#include "ThesisFreqCases.DroopCase_model.h"
#include "simulation/solver/events.h"
#include "util/real_array.h"

/* FIXME these defines are ugly and hard to read, why not use direct function pointers instead? */
#define prefixedName_performSimulation ThesisFreqCases_DroopCase_performSimulation
#define prefixedName_updateContinuousSystem ThesisFreqCases_DroopCase_updateContinuousSystem
#include <simulation/solver/perform_simulation.c.inc>

#define prefixedName_performQSSSimulation ThesisFreqCases_DroopCase_performQSSSimulation
#include <simulation/solver/perform_qss_simulation.c.inc>


/* dummy VARINFO and FILEINFO */
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;

int ThesisFreqCases_DroopCase_input_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int ThesisFreqCases_DroopCase_input_function_init(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int ThesisFreqCases_DroopCase_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int ThesisFreqCases_DroopCase_inputNames(DATA *data, char ** names){
  
  return 0;
}

int ThesisFreqCases_DroopCase_data_function(DATA *data, threadData_t *threadData)
{
  return 0;
}

int ThesisFreqCases_DroopCase_dataReconciliationInputNames(DATA *data, char ** names){
  
  return 0;
}

int ThesisFreqCases_DroopCase_dataReconciliationUnmeasuredVariables(DATA *data, char ** names)
{
  
  return 0;
}

int ThesisFreqCases_DroopCase_output_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int ThesisFreqCases_DroopCase_setc_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int ThesisFreqCases_DroopCase_setb_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}


/*
equation index: 16
type: SIMPLE_ASSIGN
Pdist = if time < tEvent then 0.0 else dPstep
*/
void ThesisFreqCases_DroopCase_eqFunction_16(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,16};
  modelica_boolean tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  tmp1 = 1.0;
  tmp2 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[13]] /* tEvent PARAM */));
  relationhysteresis(data, &tmp0, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[13]] /* tEvent PARAM */), tmp1, tmp2, 0, Less, LessZC);
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[10]] /* Pdist variable */) = (tmp0?0.0:(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[8]] /* dPstep PARAM */));
  threadData->lastEquationSolved = 16;
}

/*
equation index: 17
type: SIMPLE_ASSIGN
$DER.df_droop = (df - df_droop) / T_droop
*/
void ThesisFreqCases_DroopCase_eqFunction_17(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,17};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[4]] /* der(df_droop) STATE_DER */) = DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* df STATE(1) */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[1]] /* df_droop STATE(1) */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[6]] /* T_droop PARAM */),"T_droop",equationIndexes);
  threadData->lastEquationSolved = 17;
}

/*
equation index: 18
type: SIMPLE_ASSIGN
$DER.df_ffr = (df - df_ffr) / T_ffr
*/
void ThesisFreqCases_DroopCase_eqFunction_18(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,18};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[5]] /* der(df_ffr) STATE_DER */) = DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* df STATE(1) */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* df_ffr STATE(1) */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[7]] /* T_ffr PARAM */),"T_ffr",equationIndexes);
  threadData->lastEquationSolved = 18;
}

/*
equation index: 19
type: SIMPLE_ASSIGN
Pdroop_raw = if noEvent(abs(df_droop) <= deadband) then 0.0 else (-df_droop) / R
*/
void ThesisFreqCases_DroopCase_eqFunction_19(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,19};
  modelica_boolean tmp3;
  tmp3 = LessEq(fabs((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[1]] /* df_droop STATE(1) */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[9]] /* deadband PARAM */));
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* Pdroop_raw variable */) = (tmp3?0.0:DIVISION_SIM((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[1]] /* df_droop STATE(1) */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[5]] /* R PARAM */),"R",equationIndexes));
  threadData->lastEquationSolved = 19;
}

/*
equation index: 20
type: SIMPLE_ASSIGN
$cse1 = max(Pdroop_raw, -PmaxDroop)
*/
void ThesisFreqCases_DroopCase_eqFunction_20(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,20};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[7]] /* $cse1 variable */) = fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* Pdroop_raw variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[2]] /* PmaxDroop PARAM */)));
  threadData->lastEquationSolved = 20;
}

/*
equation index: 21
type: SIMPLE_ASSIGN
Pdroop = min($cse1, PmaxDroop)
*/
void ThesisFreqCases_DroopCase_eqFunction_21(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,21};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[11]] /* Pdroop variable */) = fmin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[7]] /* $cse1 variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[2]] /* PmaxDroop PARAM */));
  threadData->lastEquationSolved = 21;
}

/*
equation index: 22
type: SIMPLE_ASSIGN
Pffr_raw = if noEvent(time < tEvent) or noEvent(time > tEvent + ffrDuration) or noEvent(abs(df_ffr) <= deadband) then 0.0 else (-ffrGain) * df_ffr
*/
void ThesisFreqCases_DroopCase_eqFunction_22(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,22};
  modelica_boolean tmp4;
  modelica_boolean tmp5;
  modelica_boolean tmp6;
  tmp4 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[13]] /* tEvent PARAM */));
  tmp5 = Greater(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[13]] /* tEvent PARAM */) + (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[11]] /* ffrDuration PARAM */));
  tmp6 = LessEq(fabs((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* df_ffr STATE(1) */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[9]] /* deadband PARAM */));
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[14]] /* Pffr_raw variable */) = (((tmp4 || tmp5) || tmp6)?0.0:((-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[12]] /* ffrGain PARAM */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* df_ffr STATE(1) */)));
  threadData->lastEquationSolved = 22;
}

/*
equation index: 23
type: SIMPLE_ASSIGN
$cse2 = max(Pffr_raw, -PmaxFFR)
*/
void ThesisFreqCases_DroopCase_eqFunction_23(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,23};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[8]] /* $cse2 variable */) = fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[14]] /* Pffr_raw variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[3]] /* PmaxFFR PARAM */)));
  threadData->lastEquationSolved = 23;
}

/*
equation index: 24
type: SIMPLE_ASSIGN
Pffr = min($cse2, PmaxFFR)
*/
void ThesisFreqCases_DroopCase_eqFunction_24(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,24};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* Pffr variable */) = fmin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[8]] /* $cse2 variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[3]] /* PmaxFFR PARAM */));
  threadData->lastEquationSolved = 24;
}

/*
equation index: 25
type: SIMPLE_ASSIGN
$cse3 = max(Pdroop + Pffr, -PmaxTotal)
*/
void ThesisFreqCases_DroopCase_eqFunction_25(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,25};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[9]] /* $cse3 variable */) = fmax((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[11]] /* Pdroop variable */) + (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* Pffr variable */),(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[4]] /* PmaxTotal PARAM */)));
  threadData->lastEquationSolved = 25;
}

/*
equation index: 26
type: SIMPLE_ASSIGN
Psupport = min($cse3, PmaxTotal)
*/
void ThesisFreqCases_DroopCase_eqFunction_26(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,26};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[15]] /* Psupport variable */) = fmin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[9]] /* $cse3 variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[4]] /* PmaxTotal PARAM */));
  threadData->lastEquationSolved = 26;
}

/*
equation index: 27
type: SIMPLE_ASSIGN
$DER.df = 0.5 * f0 * (Pdist + Psupport - D * df) / H
*/
void ThesisFreqCases_DroopCase_eqFunction_27(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,27};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[3]] /* der(df) STATE_DER */) = (0.5) * (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[10]] /* f0 PARAM */)) * (DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[10]] /* Pdist variable */) + (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[15]] /* Psupport variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[0]] /* D PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* df STATE(1) */))),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[1]] /* H PARAM */),"H",equationIndexes)));
  threadData->lastEquationSolved = 27;
}

/*
equation index: 28
type: SIMPLE_ASSIGN
rocofHzps = der(df)
*/
void ThesisFreqCases_DroopCase_eqFunction_28(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,28};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[17]] /* rocofHzps variable */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[3]] /* der(df) STATE_DER */);
  threadData->lastEquationSolved = 28;
}

/*
equation index: 29
type: SIMPLE_ASSIGN
$DER.fHz = rocofHzps
*/
void ThesisFreqCases_DroopCase_eqFunction_29(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,29};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[6]] /* der(fHz) DUMMY_DER */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[17]] /* rocofHzps variable */);
  threadData->lastEquationSolved = 29;
}

/*
equation index: 30
type: SIMPLE_ASSIGN
fHz = f0 + df
*/
void ThesisFreqCases_DroopCase_eqFunction_30(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,30};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[16]] /* fHz DUMMY_STATE */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[10]] /* f0 PARAM */) + (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* df STATE(1) */);
  threadData->lastEquationSolved = 30;
}

OMC_DISABLE_OPT
int ThesisFreqCases_DroopCase_functionDAE(DATA *data, threadData_t *threadData)
{
  int equationIndexes[1] = {0};
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_DAE);
#endif

  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  ThesisFreqCases_DroopCase_functionLocalKnownVars(data, threadData);
  static void (*const eqFunctions[15])(DATA*, threadData_t*) = {
    ThesisFreqCases_DroopCase_eqFunction_16,
    ThesisFreqCases_DroopCase_eqFunction_17,
    ThesisFreqCases_DroopCase_eqFunction_18,
    ThesisFreqCases_DroopCase_eqFunction_19,
    ThesisFreqCases_DroopCase_eqFunction_20,
    ThesisFreqCases_DroopCase_eqFunction_21,
    ThesisFreqCases_DroopCase_eqFunction_22,
    ThesisFreqCases_DroopCase_eqFunction_23,
    ThesisFreqCases_DroopCase_eqFunction_24,
    ThesisFreqCases_DroopCase_eqFunction_25,
    ThesisFreqCases_DroopCase_eqFunction_26,
    ThesisFreqCases_DroopCase_eqFunction_27,
    ThesisFreqCases_DroopCase_eqFunction_28,
    ThesisFreqCases_DroopCase_eqFunction_29,
    ThesisFreqCases_DroopCase_eqFunction_30
  };
  
  for (int id = 0; id < 15; id++) {
    eqFunctions[id](data, threadData);
  }
  data->simulationInfo->discreteCall = 0;
  
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_DAE);
#endif
  return 0;
}


int ThesisFreqCases_DroopCase_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

/* forwarded equations */
extern void ThesisFreqCases_DroopCase_eqFunction_16(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_17(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_18(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_19(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_20(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_21(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_22(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_23(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_24(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_25(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_26(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_27(DATA* data, threadData_t *threadData);

static void functionODE_system0(DATA *data, threadData_t *threadData)
{
  static void (*const eqFunctions[12])(DATA*, threadData_t*) = {
    ThesisFreqCases_DroopCase_eqFunction_16,
    ThesisFreqCases_DroopCase_eqFunction_17,
    ThesisFreqCases_DroopCase_eqFunction_18,
    ThesisFreqCases_DroopCase_eqFunction_19,
    ThesisFreqCases_DroopCase_eqFunction_20,
    ThesisFreqCases_DroopCase_eqFunction_21,
    ThesisFreqCases_DroopCase_eqFunction_22,
    ThesisFreqCases_DroopCase_eqFunction_23,
    ThesisFreqCases_DroopCase_eqFunction_24,
    ThesisFreqCases_DroopCase_eqFunction_25,
    ThesisFreqCases_DroopCase_eqFunction_26,
    ThesisFreqCases_DroopCase_eqFunction_27
  };
  
  for (int id = 0; id < 12; id++) {
    eqFunctions[id](data, threadData);
  }
}

int ThesisFreqCases_DroopCase_functionODE(DATA *data, threadData_t *threadData)
{
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_FUNCTION_ODE);
#endif

  
  data->simulationInfo->callStatistics.functionODE++;
  
  ThesisFreqCases_DroopCase_functionLocalKnownVars(data, threadData);
  functionODE_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_FUNCTION_ODE);
#endif

  return 0;
}

/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char **argv, DATA *data, threadData_t *threadData);
extern int _main_OptimizationRuntime(int argc, char **argv, DATA *data, threadData_t *threadData);

#include "ThesisFreqCases.DroopCase_12jac.h"
#include "ThesisFreqCases.DroopCase_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks ThesisFreqCases_DroopCase_callback = {
  (int (*)(DATA *, threadData_t *, void *)) ThesisFreqCases_DroopCase_performSimulation,    /* performSimulation */
  (int (*)(DATA *, threadData_t *, void *)) ThesisFreqCases_DroopCase_performQSSSimulation,    /* performQSSSimulation */
  ThesisFreqCases_DroopCase_updateContinuousSystem,    /* updateContinuousSystem */
  ThesisFreqCases_DroopCase_callExternalObjectDestructors,    /* callExternalObjectDestructors */
  NULL,    /* initialNonLinearSystem */
  NULL,    /* initialLinearSystem */
  NULL,    /* initialMixedSystem */
  #if !defined(OMC_NO_STATESELECTION)
  ThesisFreqCases_DroopCase_initializeStateSets,
  #else
  NULL,
  #endif    /* initializeStateSets */
  ThesisFreqCases_DroopCase_initializeDAEmodeData,
  ThesisFreqCases_DroopCase_functionODE,
  ThesisFreqCases_DroopCase_functionAlgebraics,
  ThesisFreqCases_DroopCase_functionDAE,
  ThesisFreqCases_DroopCase_functionLocalKnownVars,
  ThesisFreqCases_DroopCase_input_function,
  ThesisFreqCases_DroopCase_input_function_init,
  ThesisFreqCases_DroopCase_input_function_updateStartValues,
  ThesisFreqCases_DroopCase_data_function,
  ThesisFreqCases_DroopCase_output_function,
  ThesisFreqCases_DroopCase_setc_function,
  ThesisFreqCases_DroopCase_setb_function,
  ThesisFreqCases_DroopCase_function_storeDelayed,
  ThesisFreqCases_DroopCase_function_storeSpatialDistribution,
  ThesisFreqCases_DroopCase_function_initSpatialDistribution,
  ThesisFreqCases_DroopCase_updateBoundVariableAttributes,
  ThesisFreqCases_DroopCase_functionInitialEquations,
  GLOBAL_EQUIDISTANT_HOMOTOPY,
  NULL,
  ThesisFreqCases_DroopCase_functionRemovedInitialEquations,
  ThesisFreqCases_DroopCase_updateBoundParameters,
  ThesisFreqCases_DroopCase_checkForAsserts,
  ThesisFreqCases_DroopCase_function_ZeroCrossingsEquations,
  ThesisFreqCases_DroopCase_function_ZeroCrossings,
  ThesisFreqCases_DroopCase_function_updateRelations,
  ThesisFreqCases_DroopCase_zeroCrossingDescription,
  ThesisFreqCases_DroopCase_relationDescription,
  ThesisFreqCases_DroopCase_function_initSample,
  ThesisFreqCases_DroopCase_INDEX_JAC_A,
  ThesisFreqCases_DroopCase_INDEX_JAC_B,
  ThesisFreqCases_DroopCase_INDEX_JAC_C,
  ThesisFreqCases_DroopCase_INDEX_JAC_D,
  ThesisFreqCases_DroopCase_INDEX_JAC_F,
  ThesisFreqCases_DroopCase_INDEX_JAC_H,
  ThesisFreqCases_DroopCase_initialAnalyticJacobianA,
  ThesisFreqCases_DroopCase_initialAnalyticJacobianB,
  ThesisFreqCases_DroopCase_initialAnalyticJacobianC,
  ThesisFreqCases_DroopCase_initialAnalyticJacobianD,
  ThesisFreqCases_DroopCase_initialAnalyticJacobianF,
  ThesisFreqCases_DroopCase_initialAnalyticJacobianH,
  ThesisFreqCases_DroopCase_functionJacA_column,
  ThesisFreqCases_DroopCase_functionJacB_column,
  ThesisFreqCases_DroopCase_functionJacC_column,
  ThesisFreqCases_DroopCase_functionJacD_column,
  ThesisFreqCases_DroopCase_functionJacF_column,
  ThesisFreqCases_DroopCase_functionJacH_column,
  ThesisFreqCases_DroopCase_linear_model_frame,
  ThesisFreqCases_DroopCase_linear_model_datarecovery_frame,
  ThesisFreqCases_DroopCase_mayer,
  ThesisFreqCases_DroopCase_lagrange,
  ThesisFreqCases_DroopCase_getInputVarIndicesInOptimization,
  ThesisFreqCases_DroopCase_pickUpBoundsForInputsInOptimization,
  ThesisFreqCases_DroopCase_setInputData,
  ThesisFreqCases_DroopCase_getTimeGrid,
  ThesisFreqCases_DroopCase_symbolicInlineSystem,
  ThesisFreqCases_DroopCase_function_initSynchronous,
  ThesisFreqCases_DroopCase_function_updateSynchronous,
  ThesisFreqCases_DroopCase_function_equationsSynchronous,
  ThesisFreqCases_DroopCase_inputNames,
  ThesisFreqCases_DroopCase_dataReconciliationInputNames,
  ThesisFreqCases_DroopCase_dataReconciliationUnmeasuredVariables,
  NULL,
  NULL,
  NULL,
  NULL,
  -1,
  NULL,
  NULL,
  -1

};

#define _OMC_LIT_RESOURCE_0_name_data "Complex"
#define _OMC_LIT_RESOURCE_0_dir_data "C:/Users/ADMIN/AppData/Roaming/.openmodelica/libraries/Complex 4.1.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_name,7,_OMC_LIT_RESOURCE_0_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir,77,_OMC_LIT_RESOURCE_0_dir_data);

#define _OMC_LIT_RESOURCE_1_name_data "Modelica"
#define _OMC_LIT_RESOURCE_1_dir_data "C:/Users/ADMIN/AppData/Roaming/.openmodelica/libraries/Modelica 4.1.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_name,8,_OMC_LIT_RESOURCE_1_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir,78,_OMC_LIT_RESOURCE_1_dir_data);

#define _OMC_LIT_RESOURCE_2_name_data "ModelicaServices"
#define _OMC_LIT_RESOURCE_2_dir_data "C:/Users/ADMIN/AppData/Roaming/.openmodelica/libraries/ModelicaServices 4.1.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_name,16,_OMC_LIT_RESOURCE_2_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir,86,_OMC_LIT_RESOURCE_2_dir_data);

#define _OMC_LIT_RESOURCE_3_name_data "ThesisFreqCases"
#define _OMC_LIT_RESOURCE_3_dir_data "C:/Users/ADMIN/Desktop/ms-project"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_name,15,_OMC_LIT_RESOURCE_3_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir,33,_OMC_LIT_RESOURCE_3_dir_data);

static const MMC_DEFSTRUCTLIT(_OMC_LIT_RESOURCES,8,MMC_ARRAY_TAG) {MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir)}};
void ThesisFreqCases_DroopCase_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  threadData->localRoots[LOCAL_ROOT_SIMULATION_DATA] = data;
  data->callback = &ThesisFreqCases_DroopCase_callback;
  OpenModelica_updateUriMapping(threadData, MMC_REFSTRUCTLIT(_OMC_LIT_RESOURCES));
  data->modelData->modelName = "ThesisFreqCases.DroopCase";
  data->modelData->modelFilePrefix = "ThesisFreqCases.DroopCase";
  data->modelData->modelFileName = "ThesisFreqCases_FIXED.mo";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "C:/Users/ADMIN/Desktop/ms-project";
  data->modelData->modelGUID = "{06b0e137-0230-4b80-a94c-965aec0ad858}";
  #if defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME)
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  #else
  #if defined(_MSC_VER) /* handle joke compilers */
  {
  /* for MSVC we encode a string like char x[] = {'a', 'b', 'c', '\0'} */
  /* because the string constant limit is 65535 bytes */
  static const char contents_init[] =
    #include "ThesisFreqCases.DroopCase_init.c"
    ;
  static const char contents_info[] =
    #include "ThesisFreqCases.DroopCase_info.c"
    ;
    data->modelData->initXMLData = contents_init;
    data->modelData->modelDataXml.infoXMLData = contents_info;
  }
  #else /* handle real compilers */
  data->modelData->initXMLData =
  #include "ThesisFreqCases.DroopCase_init.c"
    ;
  data->modelData->modelDataXml.infoXMLData =
  #include "ThesisFreqCases.DroopCase_info.c"
    ;
  #endif /* defined(_MSC_VER) */
  #endif /* defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME) */
  data->modelData->modelDataXml.fileName = "ThesisFreqCases.DroopCase_info.json";
  data->modelData->resourcesDir = NULL;
  data->modelData->runTestsuite = 0;
  data->modelData->nStatesArray = 3;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesRealArray = 18;
  data->modelData->nVariablesIntegerArray = 0;
  data->modelData->nVariablesBooleanArray = 0;
  data->modelData->nVariablesStringArray = 0;
  data->modelData->nParametersRealArray = 14;
  data->modelData->nParametersIntegerArray = 0;
  data->modelData->nParametersBooleanArray = 0;
  data->modelData->nParametersStringArray = 0;
  data->modelData->nParametersReal = 14;
  data->modelData->nParametersInteger = 0;
  data->modelData->nParametersBoolean = 0;
  data->modelData->nParametersString = 0;
  data->modelData->nAliasRealArray = 0;
  data->modelData->nAliasIntegerArray = 0;
  data->modelData->nAliasBooleanArray = 0;
  data->modelData->nAliasStringArray = 0;
  data->modelData->nInputVars = 0;
  data->modelData->nOutputVars = 0;
  data->modelData->nZeroCrossings = 1;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 1;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 0;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 31;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 0;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 6;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  data->modelData->nDelayExpressions = 0;
  data->modelData->nBaseClocks = 0;
  data->modelData->nSpatialDistributions = 0;
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
  data->modelData->nSetcVars = 0;
  data->modelData->ndataReconVars = 0;
  data->modelData->nSetbVars = 0;
  data->modelData->nRelatedBoundaryConditions = 0;
  data->modelData->linearizationDumpLanguage = OMC_LINEARIZE_DUMP_LANGUAGE_MODELICA;
}

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}


#if defined(__MINGW32__) || defined(_MSC_VER)

#if !defined(_UNICODE)
#define _UNICODE
#endif
#if !defined(UNICODE)
#define UNICODE
#endif

#include <windows.h>
char** omc_fixWindowsArgv(int argc, wchar_t **wargv)
{
  char** newargv;
  /* Support for non-ASCII characters
  * Read the unicode command line arguments and translate it to char*
  */
  newargv = (char**)malloc(argc*sizeof(char*));
  for (int i = 0; i < argc; i++) {
    newargv[i] = omc_wchar_to_multibyte_str(wargv[i]);
  }
  return newargv;
}

#define OMC_MAIN wmain
#define OMC_CHAR wchar_t
#define OMC_EXPORT __declspec(dllexport) extern

#else
#define omc_fixWindowsArgv(N, A) (A)
#define OMC_MAIN main
#define OMC_CHAR char
#define OMC_EXPORT extern
#endif

#if defined(threadData)
#undef threadData
#endif
/* call the simulation runtime main from our main! */
#if defined(OMC_DLL_MAIN_DEFINE)
OMC_EXPORT int omcDllMain(int argc, OMC_CHAR **argv)
#else
int OMC_MAIN(int argc, OMC_CHAR** argv)
#endif
{
  char** newargv = omc_fixWindowsArgv(argc, argv);
  /*
    Set the error functions to be used for simulation.
    The default value for them is 'functions' version. Change it here to 'simulation' versions
  */
  omc_assert = omc_assert_simulation;
  omc_assert_withEquationIndexes = omc_assert_simulation_withEquationIndexes;

  omc_assert_warning_withEquationIndexes = omc_assert_warning_simulation_withEquationIndexes;
  omc_assert_warning = omc_assert_warning_simulation;
  omc_terminate = omc_terminate_simulation;
  omc_throw = omc_throw_simulation;

  int res;
  DATA data;
  MODEL_DATA modelData;
  SIMULATION_INFO simInfo;
  data.modelData = &modelData;
  data.simulationInfo = &simInfo;
  measure_time_flag = 0;
  compiledInDAEMode = 0;
  compiledWithSymSolver = 0;
  MMC_INIT(0);
  omc_alloc_interface.init();
  {
    MMC_TRY_TOP()
  
    MMC_TRY_STACK()
  
    ThesisFreqCases_DroopCase_setupDataStruc(&data, threadData);
    res = _main_initRuntimeAndSimulation(argc, newargv, &data, threadData);
    if(res == 0) {
      if (omc_flag[FLAG_MOO_OPTIMIZATION]) {
        res = _main_OptimizationRuntime(argc, newargv, &data, threadData);
      } else {
        res = _main_SimulationRuntime(argc, newargv, &data, threadData);
      }
    }
    
    MMC_ELSE()
    rml_execution_failed();
    fprintf(stderr, "Stack overflow detected and was not caught.\nSend us a bug report at https://trac.openmodelica.org/OpenModelica/newticket\n    Include the following trace:\n");
    printStacktraceMessages();
    fflush(NULL);
    return 1;
    MMC_CATCH_STACK()
    
    MMC_CATCH_TOP(return rml_execution_failed());
  }

  fflush(NULL);
  return res;
}

#ifdef __cplusplus
}
#endif


