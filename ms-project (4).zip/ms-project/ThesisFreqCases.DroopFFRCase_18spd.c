/* spatialDistribution */
#include "ThesisFreqCases.DroopFFRCase_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

int ThesisFreqCases_DroopFFRCase_function_storeSpatialDistribution(DATA *data, threadData_t *threadData)
{
  int equationIndexes[2] = {1,-1};
  
  return 0;
}

int ThesisFreqCases_DroopFFRCase_function_initSpatialDistribution(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

#if defined(__cplusplus)
}
#endif
