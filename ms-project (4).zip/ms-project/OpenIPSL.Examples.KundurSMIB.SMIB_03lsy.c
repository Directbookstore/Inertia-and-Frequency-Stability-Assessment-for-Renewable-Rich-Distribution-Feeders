/* Linear Systems */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#include "OpenIPSL.Examples.KundurSMIB.SMIB_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* linear systems */
OMC_DISABLE_OPT
void setLinearMatrixA176(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData)
{
  const int equationIndexes[2] = {1,176};
  modelica_boolean tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_boolean tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_boolean tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_boolean tmp9;
  modelica_real tmp10;
  modelica_real tmp11;
  modelica_boolean tmp12;
  modelica_real tmp13;
  modelica_real tmp14;
  modelica_boolean tmp15;
  modelica_real tmp16;
  modelica_real tmp17;
  modelica_boolean tmp18;
  modelica_real tmp19;
  modelica_real tmp20;
  modelica_boolean tmp21;
  modelica_real tmp22;
  modelica_real tmp23;
  tmp1 = 1.0;
  tmp2 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  relationhysteresis(data, &tmp0, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp1, tmp2, 0, GreaterEq, GreaterEqZC);
  tmp4 = 1.0;
  tmp5 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  relationhysteresis(data, &tmp3, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp4, tmp5, 1, Less, LessZC);
  linearSystemData->setAElement(0, 0, (-(((tmp0 && tmp3)?0.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */))))), 0, linearSystemData, threadData);
  tmp7 = 1.0;
  tmp8 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  relationhysteresis(data, &tmp6, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp7, tmp8, 0, GreaterEq, GreaterEqZC);
  tmp10 = 1.0;
  tmp11 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  relationhysteresis(data, &tmp9, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp10, tmp11, 1, Less, LessZC);
  linearSystemData->setAElement(0, 1, (-(((tmp6 && tmp9)?1.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */))))), 1, linearSystemData, threadData);
  tmp13 = 1.0;
  tmp14 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  relationhysteresis(data, &tmp12, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp13, tmp14, 0, GreaterEq, GreaterEqZC);
  tmp16 = 1.0;
  tmp17 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  relationhysteresis(data, &tmp15, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp16, tmp17, 1, Less, LessZC);
  linearSystemData->setAElement(1, 0, (-(((tmp12 && tmp15)?1.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */))))), 2, linearSystemData, threadData);
  tmp19 = 1.0;
  tmp20 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  relationhysteresis(data, &tmp18, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp19, tmp20, 0, GreaterEq, GreaterEqZC);
  tmp22 = 1.0;
  tmp23 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  relationhysteresis(data, &tmp21, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp22, tmp23, 1, Less, LessZC);
  linearSystemData->setAElement(1, 1, (-(((tmp18 && tmp21)?0.0:(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)))), 3, linearSystemData, threadData);
  threadData->lastEquationSolved = 176;
}
OMC_DISABLE_OPT
void setLinearVectorb176(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData)
{
  const int equationIndexes[2] = {1,176};
  modelica_boolean tmp24;
  modelica_real tmp25;
  modelica_real tmp26;
  modelica_boolean tmp27;
  modelica_real tmp28;
  modelica_real tmp29;
  modelica_boolean tmp30;
  modelica_real tmp31;
  modelica_real tmp32;
  modelica_boolean tmp33;
  modelica_real tmp34;
  modelica_real tmp35;
  tmp25 = 1.0;
  tmp26 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  relationhysteresis(data, &tmp24, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp25, tmp26, 0, GreaterEq, GreaterEqZC);
  tmp28 = 1.0;
  tmp29 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  relationhysteresis(data, &tmp27, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp28, tmp29, 1, Less, LessZC);
  linearSystemData->setBElement(0, ((tmp24 && tmp27)?0.0:(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))))), linearSystemData, threadData);
  tmp31 = 1.0;
  tmp32 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  relationhysteresis(data, &tmp30, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp31, tmp32, 0, GreaterEq, GreaterEqZC);
  tmp34 = 1.0;
  tmp35 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  relationhysteresis(data, &tmp33, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp34, tmp35, 1, Less, LessZC);
  linearSystemData->setBElement(1, ((tmp30 && tmp33)?0.0:(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */))))))), linearSystemData, threadData);
  threadData->lastEquationSolved = 176;
}
OMC_DISABLE_OPT
void initializeStaticLSData176(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData, modelica_boolean initSparsePattern)
{
  const int indices[2] = {
    62 /* line_2.ir.re */,
    61 /* line_2.ir.im */
  };
  for (int i = 0; i < 2; ++i) {
    linearSystemData->nominal[i] = data->modelData->realVarsData[indices[i]].attribute.nominal;
    linearSystemData->min[i]     = data->modelData->realVarsData[indices[i]].attribute.min;
    linearSystemData->max[i]     = data->modelData->realVarsData[indices[i]].attribute.max;
  }
}


OMC_DISABLE_OPT
void setLinearMatrixA173(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData)
{
  const int equationIndexes[2] = {1,173};
  modelica_boolean tmp36;
  modelica_real tmp37;
  modelica_real tmp38;
  modelica_boolean tmp39;
  modelica_real tmp40;
  modelica_real tmp41;
  modelica_boolean tmp42;
  modelica_real tmp43;
  modelica_real tmp44;
  modelica_boolean tmp45;
  modelica_real tmp46;
  modelica_real tmp47;
  modelica_boolean tmp48;
  modelica_real tmp49;
  modelica_real tmp50;
  modelica_boolean tmp51;
  modelica_real tmp52;
  modelica_real tmp53;
  modelica_boolean tmp54;
  modelica_real tmp55;
  modelica_real tmp56;
  modelica_boolean tmp57;
  modelica_real tmp58;
  modelica_real tmp59;
  tmp37 = 1.0;
  tmp38 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  relationhysteresis(data, &tmp36, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp37, tmp38, 2, GreaterEq, GreaterEqZC);
  tmp40 = 1.0;
  tmp41 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  relationhysteresis(data, &tmp39, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp40, tmp41, 3, Less, LessZC);
  linearSystemData->setAElement(0, 0, (-(((tmp36 && tmp39)?1.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */))))), 0, linearSystemData, threadData);
  tmp43 = 1.0;
  tmp44 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  relationhysteresis(data, &tmp42, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp43, tmp44, 2, GreaterEq, GreaterEqZC);
  tmp46 = 1.0;
  tmp47 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  relationhysteresis(data, &tmp45, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp46, tmp47, 3, Less, LessZC);
  linearSystemData->setAElement(0, 1, (-(((tmp42 && tmp45)?0.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */))))), 1, linearSystemData, threadData);
  tmp49 = 1.0;
  tmp50 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  relationhysteresis(data, &tmp48, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp49, tmp50, 2, GreaterEq, GreaterEqZC);
  tmp52 = 1.0;
  tmp53 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  relationhysteresis(data, &tmp51, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp52, tmp53, 3, Less, LessZC);
  linearSystemData->setAElement(1, 0, (-(((tmp48 && tmp51)?0.0:(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)))), 2, linearSystemData, threadData);
  tmp55 = 1.0;
  tmp56 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  relationhysteresis(data, &tmp54, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp55, tmp56, 2, GreaterEq, GreaterEqZC);
  tmp58 = 1.0;
  tmp59 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  relationhysteresis(data, &tmp57, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp58, tmp59, 3, Less, LessZC);
  linearSystemData->setAElement(1, 1, (-(((tmp54 && tmp57)?1.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */))))), 3, linearSystemData, threadData);
  threadData->lastEquationSolved = 173;
}
OMC_DISABLE_OPT
void setLinearVectorb173(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData)
{
  const int equationIndexes[2] = {1,173};
  modelica_boolean tmp60;
  modelica_real tmp61;
  modelica_real tmp62;
  modelica_boolean tmp63;
  modelica_real tmp64;
  modelica_real tmp65;
  modelica_boolean tmp66;
  modelica_real tmp67;
  modelica_real tmp68;
  modelica_boolean tmp69;
  modelica_real tmp70;
  modelica_real tmp71;
  tmp61 = 1.0;
  tmp62 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  relationhysteresis(data, &tmp60, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp61, tmp62, 2, GreaterEq, GreaterEqZC);
  tmp64 = 1.0;
  tmp65 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  relationhysteresis(data, &tmp63, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp64, tmp65, 3, Less, LessZC);
  linearSystemData->setBElement(0, ((tmp60 && tmp63)?0.0:(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))))), linearSystemData, threadData);
  tmp67 = 1.0;
  tmp68 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  relationhysteresis(data, &tmp66, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp67, tmp68, 2, GreaterEq, GreaterEqZC);
  tmp70 = 1.0;
  tmp71 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  relationhysteresis(data, &tmp69, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp70, tmp71, 3, Less, LessZC);
  linearSystemData->setBElement(1, ((tmp66 && tmp69)?0.0:(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */))))))), linearSystemData, threadData);
  threadData->lastEquationSolved = 173;
}
OMC_DISABLE_OPT
void initializeStaticLSData173(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData, modelica_boolean initSparsePattern)
{
  const int indices[2] = {
    53 /* line_1.ir.im */,
    54 /* line_1.ir.re */
  };
  for (int i = 0; i < 2; ++i) {
    linearSystemData->nominal[i] = data->modelData->realVarsData[indices[i]].attribute.nominal;
    linearSystemData->min[i]     = data->modelData->realVarsData[indices[i]].attribute.min;
    linearSystemData->max[i]     = data->modelData->realVarsData[indices[i]].attribute.max;
  }
}



/*
equation index: 135
type: SIMPLE_ASSIGN
transformer.is.re = ($cse4 * G1.machine.iq - (-$cse3) * G1.machine.id) * G1.machine.I_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_135(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,135};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* $cse4 variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */)) - (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* $cse3 variable */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */));
  threadData->lastEquationSolved = 135;
}
/*
equation index: 136
type: SIMPLE_ASSIGN
transformer.is.im = ($cse3 * G1.machine.iq - $cse4 * G1.machine.id) * G1.machine.I_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_136(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,136};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* $cse3 variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* $cse4 variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */));
  threadData->lastEquationSolved = 136;
}
/*
equation index: 137
type: SIMPLE_ASSIGN
transformer.vs.re = (transformer.r * transformer.is.re - transformer.x * transformer.is.im + line_2.vs.re / transformer.m) * transformer.m ^ 2.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_137(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,137};
  modelica_real tmp0;
  tmp0 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */);
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */) = (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */))) + DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */),"transformer.m",equationIndexes)) * ((tmp0 * tmp0));
  threadData->lastEquationSolved = 137;
}
/*
equation index: 138
type: SIMPLE_ASSIGN
transformer.vs.im = (transformer.r * transformer.is.im + transformer.x * transformer.is.re + line_2.vs.im / transformer.m) * transformer.m ^ 2.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_138(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,138};
  modelica_real tmp0;
  tmp0 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */);
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */) = (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */)) + DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */),"transformer.m",equationIndexes)) * ((tmp0 * tmp0));
  threadData->lastEquationSolved = 138;
}
/*
equation index: 139
type: SIMPLE_ASSIGN
G1.machine.vd = G1.machine.e2d - (G1.machine.ra * G1.machine.id - G1.machine.x2q * G1.machine.iq)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_139(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,139};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[38]] /* G1.machine.vd variable */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[3]] /* G1.machine.e2d STATE(1) */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */))));
  threadData->lastEquationSolved = 139;
}
/*
equation index: 140
type: SIMPLE_ASSIGN
G1.machine.vq = G1.machine.e2q - (G1.machine.ra * G1.machine.iq + G1.machine.x2d * G1.machine.id)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_140(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,140};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[40]] /* G1.machine.vq variable */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[4]] /* G1.machine.e2q STATE(1) */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[80]] /* G1.machine.x2d PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */)));
  threadData->lastEquationSolved = 140;
}
/*
equation index: 141
type: SIMPLE_ASSIGN
transformer.ir.re = (line_2.vs.im - transformer.vs.im / transformer.m - transformer.r * transformer.ir.im) / transformer.x
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_141(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,141};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[72]] /* transformer.ir.re variable */) = DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) - (DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */),"transformer.m",equationIndexes)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */))),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */),"transformer.x",equationIndexes);
  threadData->lastEquationSolved = 141;
}
/*
equation index: 142
type: SIMPLE_ASSIGN
fault.p.ii = (-line_2.is.im) - line_1.is.im - transformer.ir.im
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_142(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,142};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[41]] /* fault.p.ii variable */) = (-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */);
  threadData->lastEquationSolved = 142;
}
/*
equation index: 143
type: SIMPLE_ASSIGN
fault.p.ir = (-line_2.is.re) - line_1.is.re - transformer.ir.re
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_143(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,143};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[42]] /* fault.p.ir variable */) = (-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[72]] /* transformer.ir.re variable */);
  threadData->lastEquationSolved = 143;
}

void residualFunc171(RESIDUAL_USERDATA* userData, const double* xloc, double* res, const int* iflag)
{
  DATA *data = userData->data;
  threadData_t *threadData = userData->threadData;
  const int equationIndexes[2] = {1,171};
  JACOBIAN* jacobian = NULL;
  modelica_boolean tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_boolean tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_boolean tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_boolean tmp9;
  modelica_real tmp10;
  modelica_real tmp11;
  modelica_boolean tmp12;
  modelica_real tmp13;
  modelica_real tmp14;
  modelica_boolean tmp15;
  modelica_real tmp16;
  modelica_real tmp17;
  modelica_boolean tmp18;
  modelica_real tmp19;
  modelica_real tmp20;
  modelica_boolean tmp21;
  modelica_real tmp22;
  modelica_real tmp23;
  modelica_boolean tmp24;
  modelica_real tmp25;
  modelica_real tmp26;
  modelica_real tmp27;
  modelica_real tmp28;
  modelica_boolean tmp29;
  modelica_real tmp30;
  modelica_boolean tmp31;
  modelica_real tmp32;
  modelica_boolean tmp33;
  modelica_real tmp34;
  modelica_boolean tmp35;
  modelica_real tmp36;
  modelica_real tmp37;
  modelica_boolean tmp38;
  modelica_real tmp39;
  modelica_real tmp40;
  modelica_boolean tmp41;
  modelica_real tmp42;
  modelica_real tmp43;
  modelica_real tmp44;
  modelica_real tmp45;
  modelica_boolean tmp46;
  modelica_real tmp47;
  modelica_boolean tmp48;
  modelica_real tmp49;
  modelica_boolean tmp50;
  modelica_real tmp51;
  modelica_boolean tmp52;
  modelica_real tmp53;
  modelica_real tmp54;
  modelica_boolean tmp55;
  modelica_real tmp56;
  modelica_real tmp57;
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */) = xloc[0];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */) = xloc[1];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */) = xloc[2];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */) = xloc[3];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */) = xloc[4];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */) = xloc[5];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */) = xloc[6];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) = xloc[7];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) = xloc[8];
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_135(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_136(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_137(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_138(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_139(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_140(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_141(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_142(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_143(data, threadData);
  res[0] = ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[72]] /* transformer.ir.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */)))) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */);
  threadData->lastEquationSolved = 152;
  tmp1 = 1.0;
  tmp2 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  relationhysteresis(data, &tmp0, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp1, tmp2, 0, GreaterEq, GreaterEqZC);
  tmp4 = 1.0;
  tmp5 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  relationhysteresis(data, &tmp3, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp4, tmp5, 1, Less, LessZC);
  res[1] = ((tmp0 && tmp3)?(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */):(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */) + ((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))))));
  threadData->lastEquationSolved = 151;
  tmp7 = 1.0;
  tmp8 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  relationhysteresis(data, &tmp6, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */), tmp7, tmp8, 0, GreaterEq, GreaterEqZC);
  tmp10 = 1.0;
  tmp11 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  relationhysteresis(data, &tmp9, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */), tmp10, tmp11, 1, Less, LessZC);
  res[2] = ((tmp6 && tmp9)?(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */):(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */) + ((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */))))));
  threadData->lastEquationSolved = 150;
  tmp13 = 1.0;
  tmp14 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  relationhysteresis(data, &tmp12, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp13, tmp14, 2, GreaterEq, GreaterEqZC);
  tmp16 = 1.0;
  tmp17 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  relationhysteresis(data, &tmp15, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp16, tmp17, 3, Less, LessZC);
  res[3] = ((tmp12 && tmp15)?(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */):(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */) + ((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))))));
  threadData->lastEquationSolved = 149;
  tmp19 = 1.0;
  tmp20 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */));
  relationhysteresis(data, &tmp18, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */), tmp19, tmp20, 4, Less, LessZC);
  tmp33 = (modelica_boolean)tmp18;
  if(tmp33)
  {
    tmp34 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[41]] /* fault.p.ii variable */);
  }
  else
  {
    tmp22 = 1.0;
    tmp23 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
    relationhysteresis(data, &tmp21, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */), tmp22, tmp23, 5, Less, LessZC);
    tmp31 = (modelica_boolean)(tmp21 && (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[45]] /* fault.ground PARAM */));
    if(tmp31)
    {
      tmp32 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) - 1e-10;
    }
    else
    {
      tmp25 = 1.0;
      tmp26 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
      relationhysteresis(data, &tmp24, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */), tmp25, tmp26, 5, Less, LessZC);
      tmp29 = (modelica_boolean)tmp24;
      if(tmp29)
      {
        tmp27 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp28 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp30 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[41]] /* fault.p.ii variable */) - (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */))),(tmp27 * tmp27) + (tmp28 * tmp28),"fault.X ^ 2.0 + fault.R ^ 2.0",equationIndexes));
      }
      else
      {
        tmp30 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[41]] /* fault.p.ii variable */);
      }
      tmp32 = tmp30;
    }
    tmp34 = tmp32;
  }
  res[4] = tmp34;
  threadData->lastEquationSolved = 148;
  tmp36 = 1.0;
  tmp37 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */));
  relationhysteresis(data, &tmp35, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */), tmp36, tmp37, 4, Less, LessZC);
  tmp50 = (modelica_boolean)tmp35;
  if(tmp50)
  {
    tmp51 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[42]] /* fault.p.ir variable */);
  }
  else
  {
    tmp39 = 1.0;
    tmp40 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
    relationhysteresis(data, &tmp38, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */), tmp39, tmp40, 5, Less, LessZC);
    tmp48 = (modelica_boolean)(tmp38 && (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[45]] /* fault.ground PARAM */));
    if(tmp48)
    {
      tmp49 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */);
    }
    else
    {
      tmp42 = 1.0;
      tmp43 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
      relationhysteresis(data, &tmp41, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */), tmp42, tmp43, 5, Less, LessZC);
      tmp46 = (modelica_boolean)tmp41;
      if(tmp46)
      {
        tmp44 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp45 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp47 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[42]] /* fault.p.ir variable */) - (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)),(tmp44 * tmp44) + (tmp45 * tmp45),"fault.R ^ 2.0 + fault.X ^ 2.0",equationIndexes));
      }
      else
      {
        tmp47 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[42]] /* fault.p.ir variable */);
      }
      tmp49 = tmp47;
    }
    tmp51 = tmp49;
  }
  res[5] = tmp51;
  threadData->lastEquationSolved = 147;
  tmp53 = 1.0;
  tmp54 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  relationhysteresis(data, &tmp52, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */), tmp53, tmp54, 2, GreaterEq, GreaterEqZC);
  tmp56 = 1.0;
  tmp57 = fabs((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  relationhysteresis(data, &tmp55, data->localData[0]->timeValue, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */), tmp56, tmp57, 3, Less, LessZC);
  res[6] = ((tmp52 && tmp55)?(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */):(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */) + ((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */))))));
  threadData->lastEquationSolved = 146;
  res[7] = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* $cse3 variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[40]] /* G1.machine.vq variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* $cse4 variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[38]] /* G1.machine.vd variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */);
  threadData->lastEquationSolved = 145;
  res[8] = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* $cse3 variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[38]] /* G1.machine.vd variable */)) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* $cse4 variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[40]] /* G1.machine.vq variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */);
  threadData->lastEquationSolved = 144;
  threadData->lastEquationSolved = 171;
}
OMC_DISABLE_OPT
void initializeStaticLSData171(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData, modelica_boolean initSparsePattern)
{
  const int indices[9] = {
    56 /* line_1.is.re */,
    64 /* line_2.is.re */,
    55 /* line_1.is.im */,
    63 /* line_2.is.im */,
    71 /* transformer.ir.im */,
    34 /* G1.machine.id */,
    35 /* G1.machine.iq */,
    65 /* line_2.vs.im */,
    66 /* line_2.vs.re */
  };
  for (int i = 0; i < 9; ++i) {
    linearSystemData->nominal[i] = data->modelData->realVarsData[indices[i]].attribute.nominal;
    linearSystemData->min[i]     = data->modelData->realVarsData[indices[i]].attribute.min;
    linearSystemData->max[i]     = data->modelData->realVarsData[indices[i]].attribute.max;
  }
}


OMC_DISABLE_OPT
void setLinearMatrixA97(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData)
{
  const int equationIndexes[2] = {1,97};
  modelica_boolean tmp58;
  modelica_boolean tmp59;
  modelica_boolean tmp60;
  modelica_boolean tmp61;
  modelica_boolean tmp62;
  modelica_boolean tmp63;
  modelica_boolean tmp64;
  modelica_boolean tmp65;
  tmp58 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp59 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  linearSystemData->setAElement(0, 0, (-(((tmp58 && tmp59)?0.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */))))), 0, linearSystemData, threadData);
  tmp60 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp61 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  linearSystemData->setAElement(0, 1, (-(((tmp60 && tmp61)?1.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */))))), 1, linearSystemData, threadData);
  tmp62 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp63 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  linearSystemData->setAElement(1, 0, (-(((tmp62 && tmp63)?1.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */))))), 2, linearSystemData, threadData);
  tmp64 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp65 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  linearSystemData->setAElement(1, 1, (-(((tmp64 && tmp65)?0.0:(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)))), 3, linearSystemData, threadData);
  threadData->lastEquationSolved = 97;
}
OMC_DISABLE_OPT
void setLinearVectorb97(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData)
{
  const int equationIndexes[2] = {1,97};
  modelica_boolean tmp66;
  modelica_boolean tmp67;
  modelica_boolean tmp68;
  modelica_boolean tmp69;
  tmp66 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp67 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  linearSystemData->setBElement(0, ((tmp66 && tmp67)?0.0:(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))))), linearSystemData, threadData);
  tmp68 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp69 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  linearSystemData->setBElement(1, ((tmp68 && tmp69)?0.0:(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */))))))), linearSystemData, threadData);
  threadData->lastEquationSolved = 97;
}
OMC_DISABLE_OPT
void initializeStaticLSData97(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData, modelica_boolean initSparsePattern)
{
  const int indices[2] = {
    54 /* line_1.ir.re */,
    53 /* line_1.ir.im */
  };
  for (int i = 0; i < 2; ++i) {
    linearSystemData->nominal[i] = data->modelData->realVarsData[indices[i]].attribute.nominal;
    linearSystemData->min[i]     = data->modelData->realVarsData[indices[i]].attribute.min;
    linearSystemData->max[i]     = data->modelData->realVarsData[indices[i]].attribute.max;
  }
}


OMC_DISABLE_OPT
void setLinearMatrixA92(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData)
{
  const int equationIndexes[2] = {1,92};
  modelica_boolean tmp70;
  modelica_boolean tmp71;
  modelica_boolean tmp72;
  modelica_boolean tmp73;
  modelica_boolean tmp74;
  modelica_boolean tmp75;
  modelica_boolean tmp76;
  modelica_boolean tmp77;
  tmp70 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp71 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  linearSystemData->setAElement(0, 0, (-(((tmp70 && tmp71)?0.0:(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)))), 0, linearSystemData, threadData);
  tmp72 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp73 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  linearSystemData->setAElement(0, 1, (-(((tmp72 && tmp73)?1.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */))))), 1, linearSystemData, threadData);
  tmp74 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp75 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  linearSystemData->setAElement(1, 0, (-(((tmp74 && tmp75)?1.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */))))), 2, linearSystemData, threadData);
  tmp76 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp77 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  linearSystemData->setAElement(1, 1, (-(((tmp76 && tmp77)?0.0:(-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */))))), 3, linearSystemData, threadData);
  threadData->lastEquationSolved = 92;
}
OMC_DISABLE_OPT
void setLinearVectorb92(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData)
{
  const int equationIndexes[2] = {1,92};
  modelica_boolean tmp78;
  modelica_boolean tmp79;
  modelica_boolean tmp80;
  modelica_boolean tmp81;
  tmp78 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp79 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  linearSystemData->setBElement(0, ((tmp78 && tmp79)?0.0:(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */))))))), linearSystemData, threadData);
  tmp80 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp81 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  linearSystemData->setBElement(1, ((tmp80 && tmp81)?0.0:(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))))), linearSystemData, threadData);
  threadData->lastEquationSolved = 92;
}
OMC_DISABLE_OPT
void initializeStaticLSData92(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData, modelica_boolean initSparsePattern)
{
  const int indices[2] = {
    61 /* line_2.ir.im */,
    62 /* line_2.ir.re */
  };
  for (int i = 0; i < 2; ++i) {
    linearSystemData->nominal[i] = data->modelData->realVarsData[indices[i]].attribute.nominal;
    linearSystemData->min[i]     = data->modelData->realVarsData[indices[i]].attribute.min;
    linearSystemData->max[i]     = data->modelData->realVarsData[indices[i]].attribute.max;
  }
}



/*
equation index: 47
type: SIMPLE_ASSIGN
G1.machine.e1d = G1.machine.iq * (G1.machine.xq + (-G1.machine.x1q) - G1.machine.T2q0 * G1.machine.x2q * (G1.machine.xq - G1.machine.x1q) / G1.machine.x1q / G1.machine.T1q0) - $DER.G1.machine.e1d * G1.machine.T1q0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_47(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,47};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[1]] /* G1.machine.e1d STATE(1) */) = ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */) + (-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[46]] /* G1.machine.T2q0 PARAM */)) * (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */),"G1.machine.x1q",equationIndexes)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[44]] /* G1.machine.T1q0 PARAM */),"G1.machine.T1q0",equationIndexes)))) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[7]] /* der(G1.machine.e1d) STATE_DER */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[44]] /* G1.machine.T1q0 PARAM */)));
  threadData->lastEquationSolved = 47;
}
/*
equation index: 48
type: SIMPLE_ASSIGN
G1.machine.e2d = (-$DER.G1.machine.e2d) * G1.machine.T2q0 - ((-G1.machine.e1d) - (G1.machine.x1q + G1.machine.T2q0 * G1.machine.x2q * (G1.machine.xq - G1.machine.x1q) / G1.machine.x1q / G1.machine.T1q0 - G1.machine.x2q) * G1.machine.iq)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_48(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,48};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[3]] /* G1.machine.e2d STATE(1) */) = ((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[9]] /* der(G1.machine.e2d) STATE_DER */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[46]] /* G1.machine.T2q0 PARAM */)) - ((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[1]] /* G1.machine.e1d STATE(1) */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[46]] /* G1.machine.T2q0 PARAM */)) * (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */),"G1.machine.x1q",equationIndexes)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[44]] /* G1.machine.T1q0 PARAM */),"G1.machine.T1q0",equationIndexes)) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */))));
  threadData->lastEquationSolved = 48;
}
/*
equation index: 49
type: SIMPLE_ASSIGN
transformer.is.im = (sin(G1.machine.delta) * G1.machine.iq - cos(G1.machine.delta) * G1.machine.id) * G1.machine.I_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_49(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,49};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */) = ((sin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */)) - ((cos((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */));
  threadData->lastEquationSolved = 49;
}
/*
equation index: 50
type: SIMPLE_ASSIGN
transformer.is.re = (cos(G1.machine.delta) * G1.machine.iq - (-sin(G1.machine.delta)) * G1.machine.id) * G1.machine.I_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_50(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,50};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */) = ((cos((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */)) - (((-sin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */)))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */));
  threadData->lastEquationSolved = 50;
}
/*
equation index: 51
type: SIMPLE_ASSIGN
G1.machine.vd = G1.machine.e2d - (G1.machine.ra * G1.machine.id - G1.machine.x2q * G1.machine.iq)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_51(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,51};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[38]] /* G1.machine.vd variable */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[3]] /* G1.machine.e2d STATE(1) */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */))));
  threadData->lastEquationSolved = 51;
}
/*
equation index: 52
type: SIMPLE_ASSIGN
G1.machine.vq = G1.machine.e2q - (G1.machine.ra * G1.machine.iq + G1.machine.x2d * G1.machine.id)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_52(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,52};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[40]] /* G1.machine.vq variable */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[4]] /* G1.machine.e2q STATE(1) */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[80]] /* G1.machine.x2d PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */)));
  threadData->lastEquationSolved = 52;
}
/*
equation index: 53
type: SIMPLE_ASSIGN
transformer.vs.re = (sin(G1.machine.delta) * G1.machine.vd + cos(G1.machine.delta) * G1.machine.vq) * G1.machine.V_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_53(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,53};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */) = ((sin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[38]] /* G1.machine.vd variable */)) + (cos((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[40]] /* G1.machine.vq variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */));
  threadData->lastEquationSolved = 53;
}
/*
equation index: 54
type: SIMPLE_ASSIGN
line_2.vs.re = (transformer.vs.re / transformer.m ^ 2.0 - (transformer.r * transformer.is.re - transformer.x * transformer.is.im)) * transformer.m
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_54(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,54};
  modelica_real tmp0;
  tmp0 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */);
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) = (DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */),(tmp0 * tmp0),"transformer.m ^ 2.0",equationIndexes) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */))))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */));
  threadData->lastEquationSolved = 54;
}
/*
equation index: 55
type: SIMPLE_ASSIGN
transformer.vs.im = (sin(G1.machine.delta) * G1.machine.vq - cos(G1.machine.delta) * G1.machine.vd) * G1.machine.V_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_55(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,55};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */) = ((sin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[40]] /* G1.machine.vq variable */)) - ((cos((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[38]] /* G1.machine.vd variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */));
  threadData->lastEquationSolved = 55;
}
/*
equation index: 56
type: SIMPLE_ASSIGN
line_2.vs.im = (transformer.vs.im / transformer.m ^ 2.0 - (transformer.r * transformer.is.im + transformer.x * transformer.is.re)) * transformer.m
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_56(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,56};
  modelica_real tmp0;
  tmp0 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */);
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) = (DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */),(tmp0 * tmp0),"transformer.m ^ 2.0",equationIndexes) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */));
  threadData->lastEquationSolved = 56;
}
/*
equation index: 57
type: SIMPLE_ASSIGN
transformer.ir.re = (line_2.vs.im - transformer.vs.im / transformer.m - transformer.r * transformer.ir.im) / transformer.x
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_57(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,57};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[72]] /* transformer.ir.re variable */) = DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) - (DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */),"transformer.m",equationIndexes)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */))),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */),"transformer.x",equationIndexes);
  threadData->lastEquationSolved = 57;
}
/*
equation index: 58
type: SIMPLE_ASSIGN
fault.p.ii = (-line_2.is.im) - line_1.is.im - transformer.ir.im
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_58(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,58};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[41]] /* fault.p.ii variable */) = (-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */);
  threadData->lastEquationSolved = 58;
}
/*
equation index: 59
type: SIMPLE_ASSIGN
fault.p.ir = (-line_2.is.re) - line_1.is.re - transformer.ir.re
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_59(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,59};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[42]] /* fault.p.ir variable */) = (-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[72]] /* transformer.ir.re variable */);
  threadData->lastEquationSolved = 59;
}

void residualFunc89(RESIDUAL_USERDATA* userData, const double* xloc, double* res, const int* iflag)
{
  DATA *data = userData->data;
  threadData_t *threadData = userData->threadData;
  const int equationIndexes[2] = {1,89};
  JACOBIAN* jacobian = NULL;
  modelica_boolean tmp0;
  modelica_boolean tmp1;
  modelica_boolean tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_boolean tmp5;
  modelica_real tmp6;
  modelica_boolean tmp7;
  modelica_real tmp8;
  modelica_boolean tmp9;
  modelica_real tmp10;
  modelica_boolean tmp11;
  modelica_boolean tmp12;
  modelica_boolean tmp13;
  modelica_real tmp14;
  modelica_real tmp15;
  modelica_boolean tmp16;
  modelica_real tmp17;
  modelica_boolean tmp18;
  modelica_real tmp19;
  modelica_boolean tmp20;
  modelica_real tmp21;
  modelica_boolean tmp22;
  modelica_boolean tmp23;
  modelica_boolean tmp24;
  modelica_boolean tmp25;
  modelica_boolean tmp26;
  modelica_boolean tmp27;
  modelica_boolean tmp28;
  modelica_boolean tmp29;
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */) = xloc[0];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */) = xloc[1];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */) = xloc[2];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */) = xloc[3];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */) = xloc[4];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */) = xloc[5];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */) = xloc[6];
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_47(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_48(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_49(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_50(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_51(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_52(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_53(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_54(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_55(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_56(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_57(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_58(data, threadData);
  /* local constraints */
  OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_59(data, threadData);
  tmp0 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */));
  tmp9 = (modelica_boolean)tmp0;
  if(tmp9)
  {
    tmp10 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[41]] /* fault.p.ii variable */);
  }
  else
  {
    tmp1 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
    tmp7 = (modelica_boolean)(tmp1 && (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[45]] /* fault.ground PARAM */));
    if(tmp7)
    {
      tmp8 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) - 1e-10;
    }
    else
    {
      tmp2 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
      tmp5 = (modelica_boolean)tmp2;
      if(tmp5)
      {
        tmp3 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp4 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp6 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[41]] /* fault.p.ii variable */) - (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */))),(tmp3 * tmp3) + (tmp4 * tmp4),"fault.X ^ 2.0 + fault.R ^ 2.0",equationIndexes));
      }
      else
      {
        tmp6 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[41]] /* fault.p.ii variable */);
      }
      tmp8 = tmp6;
    }
    tmp10 = tmp8;
  }
  res[0] = tmp10;
  threadData->lastEquationSolved = 66;
  tmp11 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[91]] /* fault.t1 PARAM */));
  tmp20 = (modelica_boolean)tmp11;
  if(tmp20)
  {
    tmp21 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[42]] /* fault.p.ir variable */);
  }
  else
  {
    tmp12 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
    tmp18 = (modelica_boolean)(tmp12 && (data->simulationInfo->booleanParameter[data->simulationInfo->booleanParamsIndex[45]] /* fault.ground PARAM */));
    if(tmp18)
    {
      tmp19 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */);
    }
    else
    {
      tmp13 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[92]] /* fault.t2 PARAM */));
      tmp16 = (modelica_boolean)tmp13;
      if(tmp16)
      {
        tmp14 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */);
        tmp15 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */);
        tmp17 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[42]] /* fault.p.ir variable */) - (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[89]] /* fault.R PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[90]] /* fault.X PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)),(tmp14 * tmp14) + (tmp15 * tmp15),"fault.R ^ 2.0 + fault.X ^ 2.0",equationIndexes));
      }
      else
      {
        tmp17 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[42]] /* fault.p.ir variable */);
      }
      tmp19 = tmp17;
    }
    tmp21 = tmp19;
  }
  res[1] = tmp21;
  threadData->lastEquationSolved = 65;
  tmp22 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp23 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  res[2] = ((tmp22 && tmp23)?(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */):(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */) + ((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))))));
  threadData->lastEquationSolved = 64;
  tmp24 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp25 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  res[3] = ((tmp24 && tmp25)?(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */):(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */) + ((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))))));
  threadData->lastEquationSolved = 63;
  res[4] = ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[131]] /* transformer.x PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */))) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[129]] /* transformer.r PARAM */)) * (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[72]] /* transformer.ir.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[128]] /* transformer.m PARAM */)))) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */);
  threadData->lastEquationSolved = 62;
  tmp26 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[120]] /* line_2.t1 PARAM */));
  tmp27 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[121]] /* line_2.t2 PARAM */));
  res[5] = ((tmp26 && tmp27)?(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */):(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[119]] /* line_2.Z.re PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */) + ((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[118]] /* line_2.Z.im PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[116]] /* line_2.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[117]] /* line_2.Y.re PARAM */))))));
  threadData->lastEquationSolved = 61;
  tmp28 = GreaterEq(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[109]] /* line_1.t1 PARAM */));
  tmp29 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[110]] /* line_1.t2 PARAM */));
  res[6] = ((tmp28 && tmp29)?(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */):(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[108]] /* line_1.Z.re PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */) + ((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */)))) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[107]] /* line_1.Z.im PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[105]] /* line_1.Y.im PARAM */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[106]] /* line_1.Y.re PARAM */))))));
  threadData->lastEquationSolved = 60;
  threadData->lastEquationSolved = 89;
}
OMC_DISABLE_OPT
void initializeStaticLSData89(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData, modelica_boolean initSparsePattern)
{
  const int indices[7] = {
    56 /* line_1.is.re */,
    64 /* line_2.is.re */,
    63 /* line_2.is.im */,
    55 /* line_1.is.im */,
    71 /* transformer.ir.im */,
    34 /* G1.machine.id */,
    35 /* G1.machine.iq */
  };
  for (int i = 0; i < 7; ++i) {
    linearSystemData->nominal[i] = data->modelData->realVarsData[indices[i]].attribute.nominal;
    linearSystemData->min[i]     = data->modelData->realVarsData[indices[i]].attribute.min;
    linearSystemData->max[i]     = data->modelData->realVarsData[indices[i]].attribute.max;
  }
}

/* Prototypes for the strict sets (Dynamic Tearing) */

/* Global constraints for the casual sets */
/* function initialize linear systems */
void OpenIPSL_Examples_KundurSMIB_SMIB_initialLinearSystem(int nLinearSystems, LINEAR_SYSTEM_DATA* linearSystemData)
{
  /* linear systems */
  assertStreamPrint(NULL, nLinearSystems > 5, "Internal Error: nLinearSystems mismatch!");
  linearSystemData[5].equationIndex = 176;
  linearSystemData[5].size = 2;
  linearSystemData[5].nnz = 4;
  linearSystemData[5].method = 0;   /* No symbolic Jacobian available */
  linearSystemData[5].strictTearingFunctionCall = NULL;
  linearSystemData[5].setA = setLinearMatrixA176;
  linearSystemData[5].setb = setLinearVectorb176;
  linearSystemData[5].initializeStaticLSData = initializeStaticLSData176;
  
  assertStreamPrint(NULL, nLinearSystems > 4, "Internal Error: nLinearSystems mismatch!");
  linearSystemData[4].equationIndex = 173;
  linearSystemData[4].size = 2;
  linearSystemData[4].nnz = 4;
  linearSystemData[4].method = 0;   /* No symbolic Jacobian available */
  linearSystemData[4].strictTearingFunctionCall = NULL;
  linearSystemData[4].setA = setLinearMatrixA173;
  linearSystemData[4].setb = setLinearVectorb173;
  linearSystemData[4].initializeStaticLSData = initializeStaticLSData173;
  
  assertStreamPrint(NULL, nLinearSystems > 3, "Internal Error: indexlinearSystem mismatch!");
  linearSystemData[3].equationIndex = 171;
  linearSystemData[3].size = 9;
  linearSystemData[3].nnz = 0;
  linearSystemData[3].method = 1;   /* Symbolic Jacobian available */
  linearSystemData[3].residualFunc = residualFunc171;
  linearSystemData[3].strictTearingFunctionCall = NULL;
  linearSystemData[3].analyticalJacobianColumn = OpenIPSL_Examples_KundurSMIB_SMIB_functionJacLSJac7_column;
  linearSystemData[3].initialAnalyticalJacobian = OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianLSJac7;
  linearSystemData[3].jacobianIndex = 1 /*jacInx*/;
  linearSystemData[3].setA = NULL;  //setLinearMatrixA171;
  linearSystemData[3].setb = NULL;  //setLinearVectorb171;
  linearSystemData[3].initializeStaticLSData = initializeStaticLSData171;
  
  assertStreamPrint(NULL, nLinearSystems > 2, "Internal Error: nLinearSystems mismatch!");
  linearSystemData[2].equationIndex = 97;
  linearSystemData[2].size = 2;
  linearSystemData[2].nnz = 4;
  linearSystemData[2].method = 0;   /* No symbolic Jacobian available */
  linearSystemData[2].strictTearingFunctionCall = NULL;
  linearSystemData[2].setA = setLinearMatrixA97;
  linearSystemData[2].setb = setLinearVectorb97;
  linearSystemData[2].initializeStaticLSData = initializeStaticLSData97;
  
  assertStreamPrint(NULL, nLinearSystems > 1, "Internal Error: nLinearSystems mismatch!");
  linearSystemData[1].equationIndex = 92;
  linearSystemData[1].size = 2;
  linearSystemData[1].nnz = 4;
  linearSystemData[1].method = 0;   /* No symbolic Jacobian available */
  linearSystemData[1].strictTearingFunctionCall = NULL;
  linearSystemData[1].setA = setLinearMatrixA92;
  linearSystemData[1].setb = setLinearVectorb92;
  linearSystemData[1].initializeStaticLSData = initializeStaticLSData92;
  
  assertStreamPrint(NULL, nLinearSystems > 0, "Internal Error: indexlinearSystem mismatch!");
  linearSystemData[0].equationIndex = 89;
  linearSystemData[0].size = 7;
  linearSystemData[0].nnz = 0;
  linearSystemData[0].method = 1;   /* Symbolic Jacobian available */
  linearSystemData[0].residualFunc = residualFunc89;
  linearSystemData[0].strictTearingFunctionCall = NULL;
  linearSystemData[0].analyticalJacobianColumn = OpenIPSL_Examples_KundurSMIB_SMIB_functionJacLSJac6_column;
  linearSystemData[0].initialAnalyticalJacobian = OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianLSJac6;
  linearSystemData[0].jacobianIndex = 0 /*jacInx*/;
  linearSystemData[0].setA = NULL;  //setLinearMatrixA89;
  linearSystemData[0].setb = NULL;  //setLinearVectorb89;
  linearSystemData[0].initializeStaticLSData = initializeStaticLSData89;
}

#if defined(__cplusplus)
}
#endif
