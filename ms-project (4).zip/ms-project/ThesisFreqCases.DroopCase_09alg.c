/* Algebraic */
#include "ThesisFreqCases.DroopCase_model.h"

#ifdef __cplusplus
extern "C" {
#endif

/* forwarded equations */
extern void ThesisFreqCases_DroopCase_eqFunction_28(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_29(DATA* data, threadData_t *threadData);
extern void ThesisFreqCases_DroopCase_eqFunction_30(DATA* data, threadData_t *threadData);

static void functionAlg_system0(DATA *data, threadData_t *threadData)
{
  static void (*const eqFunctions[3])(DATA*, threadData_t*) = {
    ThesisFreqCases_DroopCase_eqFunction_28,
    ThesisFreqCases_DroopCase_eqFunction_29,
    ThesisFreqCases_DroopCase_eqFunction_30
  };
  
  for (int id = 0; id < 3; id++) {
    eqFunctions[id](data, threadData);
  }
}
/* for continuous time variables */
int ThesisFreqCases_DroopCase_functionAlgebraics(DATA *data, threadData_t *threadData)
{

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_ALGEBRAICS);
#endif
  data->simulationInfo->callStatistics.functionAlgebraics++;

  ThesisFreqCases_DroopCase_function_savePreSynchronous(data, threadData);
  
  functionAlg_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_ALGEBRAICS);
#endif

  return 0;
}

#ifdef __cplusplus
}
#endif
