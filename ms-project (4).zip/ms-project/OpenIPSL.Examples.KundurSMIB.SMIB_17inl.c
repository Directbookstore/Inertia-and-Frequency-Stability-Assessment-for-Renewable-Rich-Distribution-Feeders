/* Inline equation file is empty */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int OpenIPSL_Examples_KundurSMIB_SMIB_symbolicInlineSystem(DATA *data, threadData_t *threadData){
  return -1;
}
#ifdef __cplusplus
}
#endif
