/* Initial State Set */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#include "OpenIPSL.Examples.KundurSMIB.SMIB_11mix.h"
#include "OpenIPSL.Examples.KundurSMIB.SMIB_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void OpenIPSL_Examples_KundurSMIB_SMIB_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif
