/* Algebraic */
#include "ThesisFreqCases.DroopFFRCase_model.h"

#ifdef __cplusplus
extern "C" {
#endif

/* forwarded equations */
extern void ThesisFreqCases_DroopFFRCase_eqFunction_24(DATA* data, threadData_t *threadData);

static void functionAlg_system0(DATA *data, threadData_t *threadData)
{
  static void (*const eqFunctions[1])(DATA*, threadData_t*) = {
    ThesisFreqCases_DroopFFRCase_eqFunction_24
  };
  
  for (int id = 0; id < 1; id++) {
    eqFunctions[id](data, threadData);
  }
}
/* for continuous time variables */
int ThesisFreqCases_DroopFFRCase_functionAlgebraics(DATA *data, threadData_t *threadData)
{

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_ALGEBRAICS);
#endif
  data->simulationInfo->callStatistics.functionAlgebraics++;

  ThesisFreqCases_DroopFFRCase_function_savePreSynchronous(data, threadData);
  
  functionAlg_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_ALGEBRAICS);
#endif

  return 0;
}

#ifdef __cplusplus
}
#endif
