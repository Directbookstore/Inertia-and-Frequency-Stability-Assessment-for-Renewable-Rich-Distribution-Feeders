/* Main Simulation File */

#if defined(__cplusplus)
extern "C" {
#endif

#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#include "simulation/solver/events.h"
#include "util/real_array.h"

/* FIXME these defines are ugly and hard to read, why not use direct function pointers instead? */
#define prefixedName_performSimulation OpenIPSL_Examples_KundurSMIB_SMIB_performSimulation
#define prefixedName_updateContinuousSystem OpenIPSL_Examples_KundurSMIB_SMIB_updateContinuousSystem
#include <simulation/solver/perform_simulation.c.inc>

#define prefixedName_performQSSSimulation OpenIPSL_Examples_KundurSMIB_SMIB_performQSSSimulation
#include <simulation/solver/perform_qss_simulation.c.inc>


/* dummy VARINFO and FILEINFO */
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;

int OpenIPSL_Examples_KundurSMIB_SMIB_input_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_input_function_init(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_inputNames(DATA *data, char ** names){
  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_data_function(DATA *data, threadData_t *threadData)
{
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_dataReconciliationInputNames(DATA *data, char ** names){
  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_dataReconciliationUnmeasuredVariables(DATA *data, char ** names)
{
  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_output_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_setc_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

int OpenIPSL_Examples_KundurSMIB_SMIB_setb_function(DATA *data, threadData_t *threadData)
{
  
  return 0;
}


/*
equation index: 132
type: SIMPLE_ASSIGN
$DER.G1.machine.delta = G1.machine.w_b * (-1.0 + G1.machine.w)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_132(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,132};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[6]] /* der(G1.machine.delta) STATE_DER */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[77]] /* G1.machine.w_b PARAM */)) * (-1.0 + (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[5]] /* G1.machine.w STATE(1) */));
  threadData->lastEquationSolved = 132;
}

/*
equation index: 133
type: SIMPLE_ASSIGN
$cse4 = cos(G1.machine.delta)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_133(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,133};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[13]] /* $cse4 variable */) = cos((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */));
  threadData->lastEquationSolved = 133;
}

/*
equation index: 134
type: SIMPLE_ASSIGN
$cse3 = sin(G1.machine.delta)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_134(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,134};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[12]] /* $cse3 variable */) = sin((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */));
  threadData->lastEquationSolved = 134;
}

/*
equation index: 171
type: LINEAR

<var>line_1.is.re</var>
<var>line_2.is.re</var>
<var>line_1.is.im</var>
<var>line_2.is.im</var>
<var>transformer.ir.im</var>
<var>G1.machine.id</var>
<var>G1.machine.iq</var>
<var>line_2.vs.im</var>
<var>line_2.vs.re</var>
<row>

</row>
<matrix>
</matrix>
*/
OMC_DISABLE_OPT
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_171(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,171};
  /* Linear equation system */
  int retValue;
  double aux_x[9] = { (data->localData[1]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) };
  infoStreamPrint(OMC_LOG_DT, 0, "Solving linear system 171 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);

  retValue = solve_linear_system(data, threadData, 3, &aux_x[0]);

  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,171};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving linear system 171 failed at time=%.15g.\nFor more information please use -lv LOG_LS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */) = aux_x[0];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */) = aux_x[1];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */) = aux_x[2];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */) = aux_x[3];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */) = aux_x[4];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */) = aux_x[5];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */) = aux_x[6];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */) = aux_x[7];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */) = aux_x[8];

  threadData->lastEquationSolved = 171;
}

/*
equation index: 172
type: SIMPLE_ASSIGN
B2.v = sqrt(line_2.vs.re ^ 2.0 + line_2.vs.im ^ 2.0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_172(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,172};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  tmp0 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */);
  tmp1 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */);
  tmp2 = (tmp0 * tmp0) + (tmp1 * tmp1);
  if(!(tmp2 >= 0.0))
  {
    if (data->simulationInfo->noThrowAsserts) {
      FILE_INFO info = {"",0,0,0,0,0};
      infoStreamPrintWithEquationIndexes(OMC_LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
      data->simulationInfo->needToReThrow = 1;
    } else {
      FILE_INFO info = {"",0,0,0,0,0};
      omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
      throwStreamPrintWithEquationIndexes(threadData, info, equationIndexes, "Model error: Argument of sqrt(line_2.vs.re ^ 2.0 + line_2.vs.im ^ 2.0) was %g should be >= 0", tmp2);
    }
  }
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[23]] /* B2.v variable */) = sqrt(tmp2);
  threadData->lastEquationSolved = 172;
}

/*
equation index: 173
type: LINEAR

<var>line_1.ir.im</var>
<var>line_1.ir.re</var>
<row>
  <cell>if time >= line_1.t1 and time < line_1.t2 then 0.0 else infinite_bus.p.vi - line_2.vs.im - (line_1.Z.re * ((-infinite_bus.p.vr) * line_1.Y.im - infinite_bus.p.vi * line_1.Y.re) + line_1.Z.im * (infinite_bus.p.vi * line_1.Y.im - infinite_bus.p.vr * line_1.Y.re))</cell>
  <cell>if time >= line_1.t1 and time < line_1.t2 then 0.0 else infinite_bus.p.vr - line_2.vs.re - (line_1.Z.re * (infinite_bus.p.vi * line_1.Y.im - infinite_bus.p.vr * line_1.Y.re) - line_1.Z.im * ((-infinite_bus.p.vr) * line_1.Y.im - infinite_bus.p.vi * line_1.Y.re))</cell>
</row>
<matrix>
  <cell row="0" col="0">
    <residual>-(if time >= line_1.t1 and time < line_1.t2 then 1.0 else -line_1.Z.re)</residual>
  </cell><cell row="0" col="1">
    <residual>-(if time >= line_1.t1 and time < line_1.t2 then 0.0 else -line_1.Z.im)</residual>
  </cell><cell row="1" col="0">
    <residual>-(if time >= line_1.t1 and time < line_1.t2 then 0.0 else line_1.Z.im)</residual>
  </cell><cell row="1" col="1">
    <residual>-(if time >= line_1.t1 and time < line_1.t2 then 1.0 else -line_1.Z.re)</residual>
  </cell>
</matrix>
*/
OMC_DISABLE_OPT
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_173(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,173};
  /* Linear equation system */
  int retValue;
  double aux_x[2] = { (data->localData[1]->realVars[data->simulationInfo->realVarsIndex[53]] /* line_1.ir.im variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[54]] /* line_1.ir.re variable */) };
  infoStreamPrint(OMC_LOG_DT, 0, "Solving linear system 173 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);

  retValue = solve_linear_system(data, threadData, 4, &aux_x[0]);

  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,173};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving linear system 173 failed at time=%.15g.\nFor more information please use -lv LOG_LS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[53]] /* line_1.ir.im variable */) = aux_x[0];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[54]] /* line_1.ir.re variable */) = aux_x[1];

  threadData->lastEquationSolved = 173;
}

/*
equation index: 174
type: SIMPLE_ASSIGN
line_1.P21 = ((-infinite_bus.p.vr) * line_1.ir.re - infinite_bus.p.vi * line_1.ir.im) * line_1.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_174(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,174};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[50]] /* line_1.P21 variable */) = (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[54]] /* line_1.ir.re variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[53]] /* line_1.ir.im variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[103]] /* line_1.S_b PARAM */));
  threadData->lastEquationSolved = 174;
}

/*
equation index: 175
type: SIMPLE_ASSIGN
line_1.Q21 = (infinite_bus.p.vr * line_1.ir.im - infinite_bus.p.vi * line_1.ir.re) * line_1.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_175(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,175};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[52]] /* line_1.Q21 variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[53]] /* line_1.ir.im variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[54]] /* line_1.ir.re variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[103]] /* line_1.S_b PARAM */));
  threadData->lastEquationSolved = 175;
}

/*
equation index: 176
type: LINEAR

<var>line_2.ir.re</var>
<var>line_2.ir.im</var>
<row>
  <cell>if time >= line_2.t1 and time < line_2.t2 then 0.0 else infinite_bus.p.vi - line_2.vs.im - (line_2.Z.re * ((-infinite_bus.p.vr) * line_2.Y.im - infinite_bus.p.vi * line_2.Y.re) + line_2.Z.im * (infinite_bus.p.vi * line_2.Y.im - infinite_bus.p.vr * line_2.Y.re))</cell>
  <cell>if time >= line_2.t1 and time < line_2.t2 then 0.0 else infinite_bus.p.vr - line_2.vs.re - (line_2.Z.re * (infinite_bus.p.vi * line_2.Y.im - infinite_bus.p.vr * line_2.Y.re) - line_2.Z.im * ((-infinite_bus.p.vr) * line_2.Y.im - infinite_bus.p.vi * line_2.Y.re))</cell>
</row>
<matrix>
  <cell row="0" col="0">
    <residual>-(if time >= line_2.t1 and time < line_2.t2 then 0.0 else -line_2.Z.im)</residual>
  </cell><cell row="0" col="1">
    <residual>-(if time >= line_2.t1 and time < line_2.t2 then 1.0 else -line_2.Z.re)</residual>
  </cell><cell row="1" col="0">
    <residual>-(if time >= line_2.t1 and time < line_2.t2 then 1.0 else -line_2.Z.re)</residual>
  </cell><cell row="1" col="1">
    <residual>-(if time >= line_2.t1 and time < line_2.t2 then 0.0 else line_2.Z.im)</residual>
  </cell>
</matrix>
*/
OMC_DISABLE_OPT
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_176(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,176};
  /* Linear equation system */
  int retValue;
  double aux_x[2] = { (data->localData[1]->realVars[data->simulationInfo->realVarsIndex[62]] /* line_2.ir.re variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[61]] /* line_2.ir.im variable */) };
  infoStreamPrint(OMC_LOG_DT, 0, "Solving linear system 176 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);

  retValue = solve_linear_system(data, threadData, 5, &aux_x[0]);

  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,176};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving linear system 176 failed at time=%.15g.\nFor more information please use -lv LOG_LS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[62]] /* line_2.ir.re variable */) = aux_x[0];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[61]] /* line_2.ir.im variable */) = aux_x[1];

  threadData->lastEquationSolved = 176;
}

/*
equation index: 177
type: SIMPLE_ASSIGN
infinite_bus.p.ir = (-line_2.ir.re) - line_1.ir.re
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_177(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,177};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[46]] /* infinite_bus.p.ir variable */) = (-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[62]] /* line_2.ir.re variable */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[54]] /* line_1.ir.re variable */);
  threadData->lastEquationSolved = 177;
}

/*
equation index: 178
type: SIMPLE_ASSIGN
infinite_bus.p.ii = (-line_2.ir.im) - line_1.ir.im
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_178(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,178};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[45]] /* infinite_bus.p.ii variable */) = (-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[61]] /* line_2.ir.im variable */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[53]] /* line_1.ir.im variable */);
  threadData->lastEquationSolved = 178;
}

/*
equation index: 179
type: SIMPLE_ASSIGN
infinite_bus.P = ((-infinite_bus.p.vr) * infinite_bus.p.ir - infinite_bus.p.vi * infinite_bus.p.ii) * infinite_bus.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_179(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,179};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[43]] /* infinite_bus.P variable */) = (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[46]] /* infinite_bus.p.ir variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[45]] /* infinite_bus.p.ii variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[95]] /* infinite_bus.S_b PARAM */));
  threadData->lastEquationSolved = 179;
}

/*
equation index: 180
type: SIMPLE_ASSIGN
infinite_bus.Q = (infinite_bus.p.vr * infinite_bus.p.ii - infinite_bus.p.vi * infinite_bus.p.ir) * infinite_bus.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_180(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,180};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[44]] /* infinite_bus.Q variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[45]] /* infinite_bus.p.ii variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[46]] /* infinite_bus.p.ir variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[95]] /* infinite_bus.S_b PARAM */));
  threadData->lastEquationSolved = 180;
}

/*
equation index: 181
type: SIMPLE_ASSIGN
line_2.P21 = ((-infinite_bus.p.vr) * line_2.ir.re - infinite_bus.p.vi * line_2.ir.im) * line_2.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_181(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,181};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[58]] /* line_2.P21 variable */) = (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[62]] /* line_2.ir.re variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[61]] /* line_2.ir.im variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[114]] /* line_2.S_b PARAM */));
  threadData->lastEquationSolved = 181;
}

/*
equation index: 182
type: SIMPLE_ASSIGN
line_2.Q21 = (infinite_bus.p.vr * line_2.ir.im - infinite_bus.p.vi * line_2.ir.re) * line_2.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_182(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,182};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[60]] /* line_2.Q21 variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[61]] /* line_2.ir.im variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[62]] /* line_2.ir.re variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[114]] /* line_2.S_b PARAM */));
  threadData->lastEquationSolved = 182;
}

/*
equation index: 183
type: SIMPLE_ASSIGN
line_2.P12 = (line_2.vs.re * line_2.is.re + line_2.vs.im * line_2.is.im) * line_2.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_183(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,183};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[57]] /* line_2.P12 variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */)) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[114]] /* line_2.S_b PARAM */));
  threadData->lastEquationSolved = 183;
}

/*
equation index: 184
type: SIMPLE_ASSIGN
line_2.Q12 = (line_2.vs.im * line_2.is.re - line_2.vs.re * line_2.is.im) * line_2.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_184(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,184};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[59]] /* line_2.Q12 variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[114]] /* line_2.S_b PARAM */));
  threadData->lastEquationSolved = 184;
}

/*
equation index: 185
type: SIMPLE_ASSIGN
B2.angle = atan2(line_2.vs.im, line_2.vs.re)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_185(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,185};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[19]] /* B2.angle variable */) = atan2((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */), (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */));
  threadData->lastEquationSolved = 185;
}

/*
equation index: 186
type: SIMPLE_ASSIGN
B2.angleDisplay = 57.29577951308232 * B2.angle
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_186(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,186};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[20]] /* B2.angleDisplay variable */) = (57.29577951308232) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[19]] /* B2.angle variable */));
  threadData->lastEquationSolved = 186;
}

/*
equation index: 187
type: SIMPLE_ASSIGN
line_1.P12 = (line_2.vs.re * line_1.is.re + line_2.vs.im * line_1.is.im) * line_1.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_187(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,187};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[49]] /* line_1.P12 variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */)) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[103]] /* line_1.S_b PARAM */));
  threadData->lastEquationSolved = 187;
}

/*
equation index: 188
type: SIMPLE_ASSIGN
line_1.Q12 = (line_2.vs.im * line_1.is.re - line_2.vs.re * line_1.is.im) * line_1.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_188(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,188};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[51]] /* line_1.Q12 variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[103]] /* line_1.S_b PARAM */));
  threadData->lastEquationSolved = 188;
}

/*
equation index: 189
type: SIMPLE_ASSIGN
transformer.P21 = ((-line_2.vs.re) * transformer.ir.re - line_2.vs.im * transformer.ir.im) * transformer.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_189(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,189};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[68]] /* transformer.P21 variable */) = (((-(data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[72]] /* transformer.ir.re variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[122]] /* transformer.S_b PARAM */));
  threadData->lastEquationSolved = 189;
}

/*
equation index: 190
type: SIMPLE_ASSIGN
transformer.Q21 = (line_2.vs.re * transformer.ir.im - line_2.vs.im * transformer.ir.re) * transformer.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_190(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,190};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[70]] /* transformer.Q21 variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[66]] /* line_2.vs.re variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[65]] /* line_2.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[72]] /* transformer.ir.re variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[122]] /* transformer.S_b PARAM */));
  threadData->lastEquationSolved = 190;
}

/*
equation index: 191
type: SIMPLE_ASSIGN
B1.v = sqrt(transformer.vs.re ^ 2.0 + transformer.vs.im ^ 2.0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_191(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,191};
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  tmp3 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */);
  tmp4 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */);
  tmp5 = (tmp3 * tmp3) + (tmp4 * tmp4);
  if(!(tmp5 >= 0.0))
  {
    if (data->simulationInfo->noThrowAsserts) {
      FILE_INFO info = {"",0,0,0,0,0};
      infoStreamPrintWithEquationIndexes(OMC_LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
      data->simulationInfo->needToReThrow = 1;
    } else {
      FILE_INFO info = {"",0,0,0,0,0};
      omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
      throwStreamPrintWithEquationIndexes(threadData, info, equationIndexes, "Model error: Argument of sqrt(transformer.vs.re ^ 2.0 + transformer.vs.im ^ 2.0) was %g should be >= 0", tmp5);
    }
  }
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[18]] /* B1.v variable */) = sqrt(tmp5);
  threadData->lastEquationSolved = 191;
}

/*
equation index: 192
type: SIMPLE_ASSIGN
G1.machine.v = B1.v
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_192(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,192};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[37]] /* G1.machine.v variable */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[18]] /* B1.v variable */);
  threadData->lastEquationSolved = 192;
}

/*
equation index: 193
type: SIMPLE_ASSIGN
B1.angle = atan2(transformer.vs.im, transformer.vs.re)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_193(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,193};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[14]] /* B1.angle variable */) = atan2((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */), (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */));
  threadData->lastEquationSolved = 193;
}

/*
equation index: 194
type: SIMPLE_ASSIGN
B1.angleDisplay = 57.29577951308232 * B1.angle
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_194(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,194};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[15]] /* B1.angleDisplay variable */) = (57.29577951308232) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[14]] /* B1.angle variable */));
  threadData->lastEquationSolved = 194;
}

/*
equation index: 195
type: SIMPLE_ASSIGN
G1.machine.anglev = B1.angle
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_195(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,195};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[33]] /* G1.machine.anglev variable */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[14]] /* B1.angle variable */);
  threadData->lastEquationSolved = 195;
}

/*
equation index: 196
type: SIMPLE_ASSIGN
transformer.P12 = (transformer.vs.re * transformer.is.re + transformer.vs.im * transformer.is.im) * transformer.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_196(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,196};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[67]] /* transformer.P12 variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */)) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[122]] /* transformer.S_b PARAM */));
  threadData->lastEquationSolved = 196;
}

/*
equation index: 197
type: SIMPLE_ASSIGN
transformer.Q12 = (transformer.vs.im * transformer.is.re - transformer.vs.re * transformer.is.im) * transformer.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_197(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,197};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[69]] /* transformer.Q12 variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[122]] /* transformer.S_b PARAM */));
  threadData->lastEquationSolved = 197;
}

/*
equation index: 198
type: SIMPLE_ASSIGN
G1.machine.P = transformer.vs.re * transformer.is.re + transformer.vs.im * transformer.is.im
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_198(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,198};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[31]] /* G1.machine.P variable */) = ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */)) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */));
  threadData->lastEquationSolved = 198;
}

/*
equation index: 199
type: SIMPLE_ASSIGN
G1.machine.Q = transformer.vs.im * transformer.is.re - transformer.vs.re * transformer.is.im
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_199(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,199};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[32]] /* G1.machine.Q variable */) = ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */)));
  threadData->lastEquationSolved = 199;
}

/*
equation index: 200
type: SIMPLE_ASSIGN
G1.P = (transformer.vs.im * transformer.is.im + transformer.vs.re * transformer.is.re) * G1.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_200(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,200};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[29]] /* G1.P variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */)) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[23]] /* G1.S_b PARAM */));
  threadData->lastEquationSolved = 200;
}

/*
equation index: 201
type: SIMPLE_ASSIGN
G1.Q = (transformer.vs.im * transformer.is.re - transformer.vs.re * transformer.is.im) * G1.S_b
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_201(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,201};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[30]] /* G1.Q variable */) = (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */)) - (((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[23]] /* G1.S_b PARAM */));
  threadData->lastEquationSolved = 201;
}

/*
equation index: 202
type: SIMPLE_ASSIGN
$DER.G1.machine.e1d = ((G1.machine.xq + (-G1.machine.x1q) - G1.machine.T2q0 * G1.machine.x2q * (G1.machine.xq - G1.machine.x1q) / G1.machine.x1q / G1.machine.T1q0) * G1.machine.iq - G1.machine.e1d) / G1.machine.T1q0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_202(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,202};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[7]] /* der(G1.machine.e1d) STATE_DER */) = DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */) + (-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[46]] /* G1.machine.T2q0 PARAM */)) * (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */),"G1.machine.x1q",equationIndexes)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[44]] /* G1.machine.T1q0 PARAM */),"G1.machine.T1q0",equationIndexes)))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[1]] /* G1.machine.e1d STATE(1) */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[44]] /* G1.machine.T1q0 PARAM */),"G1.machine.T1q0",equationIndexes);
  threadData->lastEquationSolved = 202;
}

/*
equation index: 203
type: SIMPLE_ASSIGN
$DER.G1.machine.e2d = (G1.machine.e1d + (G1.machine.x1q + G1.machine.T2q0 * G1.machine.x2q * (G1.machine.xq - G1.machine.x1q) / G1.machine.x1q / G1.machine.T1q0 - G1.machine.x2q) * G1.machine.iq - G1.machine.e2d) / G1.machine.T2q0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_203(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,203};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[9]] /* der(G1.machine.e2d) STATE_DER */) = DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[1]] /* G1.machine.e1d STATE(1) */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[46]] /* G1.machine.T2q0 PARAM */)) * (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */),"G1.machine.x1q",equationIndexes)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[44]] /* G1.machine.T1q0 PARAM */),"G1.machine.T1q0",equationIndexes)) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[3]] /* G1.machine.e2d STATE(1) */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[46]] /* G1.machine.T2q0 PARAM */),"G1.machine.T2q0",equationIndexes);
  threadData->lastEquationSolved = 203;
}

/*
equation index: 204
type: SIMPLE_ASSIGN
$DER.G1.machine.e1q = ((1.0 - G1.machine.Taa / G1.machine.T1d0) * G1.machine.vf_MB + (G1.machine.T2d0 * G1.machine.x2d * (G1.machine.xd - G1.machine.x1d) / G1.machine.x1d / G1.machine.T1d0 + G1.machine.x1d - G1.machine.xd) * G1.machine.id - G1.machine.e1q) / G1.machine.T1d0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_204(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,204};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[8]] /* der(G1.machine.e1q) STATE_DER */) = DIVISION_SIM((1.0 - (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[47]] /* G1.machine.Taa PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[43]] /* G1.machine.T1d0 PARAM */),"G1.machine.T1d0",equationIndexes))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[39]] /* G1.machine.vf_MB variable */)) + (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[45]] /* G1.machine.T2d0 PARAM */)) * (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[80]] /* G1.machine.x2d PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[82]] /* G1.machine.xd PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */),"G1.machine.x1d",equationIndexes)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[43]] /* G1.machine.T1d0 PARAM */),"G1.machine.T1d0",equationIndexes)) + (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[82]] /* G1.machine.xd PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* G1.machine.e1q STATE(1) */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[43]] /* G1.machine.T1d0 PARAM */),"G1.machine.T1d0",equationIndexes);
  threadData->lastEquationSolved = 204;
}

/*
equation index: 205
type: SIMPLE_ASSIGN
$DER.G1.machine.e2q = (G1.machine.e1q + (G1.machine.x2d - G1.machine.T2d0 * G1.machine.x2d * (G1.machine.xd - G1.machine.x1d) / G1.machine.x1d / G1.machine.T1d0 - G1.machine.x1d) * G1.machine.id + G1.machine.Taa * G1.machine.vf_MB / G1.machine.T1d0 - G1.machine.e2q) / G1.machine.T2d0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_205(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,205};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[10]] /* der(G1.machine.e2q) STATE_DER */) = DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* G1.machine.e1q STATE(1) */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[80]] /* G1.machine.x2d PARAM */) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[45]] /* G1.machine.T2d0 PARAM */)) * (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[80]] /* G1.machine.x2d PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[82]] /* G1.machine.xd PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */),"G1.machine.x1d",equationIndexes)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[43]] /* G1.machine.T1d0 PARAM */),"G1.machine.T1d0",equationIndexes))) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[78]] /* G1.machine.x1d PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[47]] /* G1.machine.Taa PARAM */)) * (DIVISION_SIM((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[39]] /* G1.machine.vf_MB variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[43]] /* G1.machine.T1d0 PARAM */),"G1.machine.T1d0",equationIndexes)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[4]] /* G1.machine.e2q STATE(1) */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[45]] /* G1.machine.T2d0 PARAM */),"G1.machine.T2d0",equationIndexes);
  threadData->lastEquationSolved = 205;
}

/*
equation index: 206
type: SIMPLE_ASSIGN
G1.machine.pe = (G1.machine.vq + G1.machine.ra * G1.machine.iq) * G1.machine.iq + (G1.machine.vd + G1.machine.ra * G1.machine.id) * G1.machine.id
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_206(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,206};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[36]] /* G1.machine.pe variable */) = ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[40]] /* G1.machine.vq variable */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */)) + ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[38]] /* G1.machine.vd variable */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */))) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */));
  threadData->lastEquationSolved = 206;
}

/*
equation index: 207
type: SIMPLE_ASSIGN
$DER.G1.machine.w = (G1.machine.pm00 * G1.machine.S_SBtoMB - G1.machine.pe) / G1.machine.M
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_207(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,207};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[11]] /* der(G1.machine.w) STATE_DER */) = DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[68]] /* G1.machine.pm00 PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[40]] /* G1.machine.S_SBtoMB PARAM */)) - (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[36]] /* G1.machine.pe variable */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[35]] /* G1.machine.M PARAM */),"G1.machine.M",equationIndexes);
  threadData->lastEquationSolved = 207;
}

OMC_DISABLE_OPT
int OpenIPSL_Examples_KundurSMIB_SMIB_functionDAE(DATA *data, threadData_t *threadData)
{
  int equationIndexes[1] = {0};
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_DAE);
#endif

  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  OpenIPSL_Examples_KundurSMIB_SMIB_functionLocalKnownVars(data, threadData);
  static void (*const eqFunctions[40])(DATA*, threadData_t*) = {
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_132,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_133,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_134,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_171,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_172,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_173,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_174,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_175,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_176,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_177,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_178,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_179,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_180,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_181,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_182,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_183,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_184,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_185,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_186,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_187,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_188,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_189,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_190,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_191,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_192,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_193,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_194,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_195,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_196,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_197,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_198,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_199,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_200,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_201,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_202,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_203,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_204,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_205,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_206,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_207
  };
  
  for (int id = 0; id < 40; id++) {
    eqFunctions[id](data, threadData);
  }
  data->simulationInfo->discreteCall = 0;
  
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_DAE);
#endif
  return 0;
}


int OpenIPSL_Examples_KundurSMIB_SMIB_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  
  return 0;
}

/* forwarded equations */
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_132(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_133(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_134(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_171(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_202(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_203(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_204(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_205(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_206(DATA* data, threadData_t *threadData);
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_207(DATA* data, threadData_t *threadData);

static void functionODE_system0(DATA *data, threadData_t *threadData)
{
  static void (*const eqFunctions[10])(DATA*, threadData_t*) = {
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_132,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_133,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_134,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_171,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_202,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_203,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_204,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_205,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_206,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_207
  };
  
  for (int id = 0; id < 10; id++) {
    eqFunctions[id](data, threadData);
  }
}

int OpenIPSL_Examples_KundurSMIB_SMIB_functionODE(DATA *data, threadData_t *threadData)
{
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_FUNCTION_ODE);
#endif

  
  data->simulationInfo->callStatistics.functionODE++;
  
  OpenIPSL_Examples_KundurSMIB_SMIB_functionLocalKnownVars(data, threadData);
  functionODE_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_FUNCTION_ODE);
#endif

  return 0;
}

/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char **argv, DATA *data, threadData_t *threadData);
extern int _main_OptimizationRuntime(int argc, char **argv, DATA *data, threadData_t *threadData);

#include "OpenIPSL.Examples.KundurSMIB.SMIB_12jac.h"
#include "OpenIPSL.Examples.KundurSMIB.SMIB_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks OpenIPSL_Examples_KundurSMIB_SMIB_callback = {
  (int (*)(DATA *, threadData_t *, void *)) OpenIPSL_Examples_KundurSMIB_SMIB_performSimulation,    /* performSimulation */
  (int (*)(DATA *, threadData_t *, void *)) OpenIPSL_Examples_KundurSMIB_SMIB_performQSSSimulation,    /* performQSSSimulation */
  OpenIPSL_Examples_KundurSMIB_SMIB_updateContinuousSystem,    /* updateContinuousSystem */
  OpenIPSL_Examples_KundurSMIB_SMIB_callExternalObjectDestructors,    /* callExternalObjectDestructors */
  NULL,    /* initialNonLinearSystem */
  OpenIPSL_Examples_KundurSMIB_SMIB_initialLinearSystem,    /* initialLinearSystem */
  NULL,    /* initialMixedSystem */
  #if !defined(OMC_NO_STATESELECTION)
  OpenIPSL_Examples_KundurSMIB_SMIB_initializeStateSets,
  #else
  NULL,
  #endif    /* initializeStateSets */
  OpenIPSL_Examples_KundurSMIB_SMIB_initializeDAEmodeData,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionODE,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionAlgebraics,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionDAE,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionLocalKnownVars,
  OpenIPSL_Examples_KundurSMIB_SMIB_input_function,
  OpenIPSL_Examples_KundurSMIB_SMIB_input_function_init,
  OpenIPSL_Examples_KundurSMIB_SMIB_input_function_updateStartValues,
  OpenIPSL_Examples_KundurSMIB_SMIB_data_function,
  OpenIPSL_Examples_KundurSMIB_SMIB_output_function,
  OpenIPSL_Examples_KundurSMIB_SMIB_setc_function,
  OpenIPSL_Examples_KundurSMIB_SMIB_setb_function,
  OpenIPSL_Examples_KundurSMIB_SMIB_function_storeDelayed,
  OpenIPSL_Examples_KundurSMIB_SMIB_function_storeSpatialDistribution,
  OpenIPSL_Examples_KundurSMIB_SMIB_function_initSpatialDistribution,
  OpenIPSL_Examples_KundurSMIB_SMIB_updateBoundVariableAttributes,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionInitialEquations,
  GLOBAL_EQUIDISTANT_HOMOTOPY,
  NULL,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionRemovedInitialEquations,
  OpenIPSL_Examples_KundurSMIB_SMIB_updateBoundParameters,
  OpenIPSL_Examples_KundurSMIB_SMIB_checkForAsserts,
  OpenIPSL_Examples_KundurSMIB_SMIB_function_ZeroCrossingsEquations,
  OpenIPSL_Examples_KundurSMIB_SMIB_function_ZeroCrossings,
  OpenIPSL_Examples_KundurSMIB_SMIB_function_updateRelations,
  OpenIPSL_Examples_KundurSMIB_SMIB_zeroCrossingDescription,
  OpenIPSL_Examples_KundurSMIB_SMIB_relationDescription,
  OpenIPSL_Examples_KundurSMIB_SMIB_function_initSample,
  OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_A,
  OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_B,
  OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_C,
  OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_D,
  OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_F,
  OpenIPSL_Examples_KundurSMIB_SMIB_INDEX_JAC_H,
  OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianA,
  OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianB,
  OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianC,
  OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianD,
  OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianF,
  OpenIPSL_Examples_KundurSMIB_SMIB_initialAnalyticJacobianH,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionJacA_column,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionJacB_column,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionJacC_column,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionJacD_column,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionJacF_column,
  OpenIPSL_Examples_KundurSMIB_SMIB_functionJacH_column,
  OpenIPSL_Examples_KundurSMIB_SMIB_linear_model_frame,
  OpenIPSL_Examples_KundurSMIB_SMIB_linear_model_datarecovery_frame,
  OpenIPSL_Examples_KundurSMIB_SMIB_mayer,
  OpenIPSL_Examples_KundurSMIB_SMIB_lagrange,
  OpenIPSL_Examples_KundurSMIB_SMIB_getInputVarIndicesInOptimization,
  OpenIPSL_Examples_KundurSMIB_SMIB_pickUpBoundsForInputsInOptimization,
  OpenIPSL_Examples_KundurSMIB_SMIB_setInputData,
  OpenIPSL_Examples_KundurSMIB_SMIB_getTimeGrid,
  OpenIPSL_Examples_KundurSMIB_SMIB_symbolicInlineSystem,
  OpenIPSL_Examples_KundurSMIB_SMIB_function_initSynchronous,
  OpenIPSL_Examples_KundurSMIB_SMIB_function_updateSynchronous,
  OpenIPSL_Examples_KundurSMIB_SMIB_function_equationsSynchronous,
  OpenIPSL_Examples_KundurSMIB_SMIB_inputNames,
  OpenIPSL_Examples_KundurSMIB_SMIB_dataReconciliationInputNames,
  OpenIPSL_Examples_KundurSMIB_SMIB_dataReconciliationUnmeasuredVariables,
  NULL,
  NULL,
  NULL,
  NULL,
  -1,
  NULL,
  NULL,
  -1

};

#define _OMC_LIT_RESOURCE_0_name_data "Complex"
#define _OMC_LIT_RESOURCE_0_dir_data "C:/Users/ADMIN/AppData/Roaming/.openmodelica/libraries/Complex 4.1.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_name,7,_OMC_LIT_RESOURCE_0_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir,77,_OMC_LIT_RESOURCE_0_dir_data);

#define _OMC_LIT_RESOURCE_1_name_data "Modelica"
#define _OMC_LIT_RESOURCE_1_dir_data "C:/Users/ADMIN/AppData/Roaming/.openmodelica/libraries/Modelica 4.1.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_name,8,_OMC_LIT_RESOURCE_1_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir,78,_OMC_LIT_RESOURCE_1_dir_data);

#define _OMC_LIT_RESOURCE_2_name_data "ModelicaServices"
#define _OMC_LIT_RESOURCE_2_dir_data "C:/Users/ADMIN/AppData/Roaming/.openmodelica/libraries/ModelicaServices 4.1.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_name,16,_OMC_LIT_RESOURCE_2_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir,86,_OMC_LIT_RESOURCE_2_dir_data);

#define _OMC_LIT_RESOURCE_3_name_data "OpenIPSL"
#define _OMC_LIT_RESOURCE_3_dir_data "C:/Users/ADMIN/OpenIPSL/OpenIPSL"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_name,8,_OMC_LIT_RESOURCE_3_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir,32,_OMC_LIT_RESOURCE_3_dir_data);

static const MMC_DEFSTRUCTLIT(_OMC_LIT_RESOURCES,8,MMC_ARRAY_TAG) {MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir)}};
void OpenIPSL_Examples_KundurSMIB_SMIB_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  threadData->localRoots[LOCAL_ROOT_SIMULATION_DATA] = data;
  data->callback = &OpenIPSL_Examples_KundurSMIB_SMIB_callback;
  OpenModelica_updateUriMapping(threadData, MMC_REFSTRUCTLIT(_OMC_LIT_RESOURCES));
  data->modelData->modelName = "OpenIPSL.Examples.KundurSMIB.SMIB";
  data->modelData->modelFilePrefix = "OpenIPSL.Examples.KundurSMIB.SMIB";
  data->modelData->modelFileName = "SMIB.mo";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "C:/Users/ADMIN/OpenIPSL/OpenIPSL/Examples/KundurSMIB";
  data->modelData->modelGUID = "{520c10e5-24eb-42fd-8b20-2d302b6fbe8a}";
  #if defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME)
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  #else
  #if defined(_MSC_VER) /* handle joke compilers */
  {
  /* for MSVC we encode a string like char x[] = {'a', 'b', 'c', '\0'} */
  /* because the string constant limit is 65535 bytes */
  static const char contents_init[] =
    #include "OpenIPSL.Examples.KundurSMIB.SMIB_init.c"
    ;
  static const char contents_info[] =
    #include "OpenIPSL.Examples.KundurSMIB.SMIB_info.c"
    ;
    data->modelData->initXMLData = contents_init;
    data->modelData->modelDataXml.infoXMLData = contents_info;
  }
  #else /* handle real compilers */
  data->modelData->initXMLData =
  #include "OpenIPSL.Examples.KundurSMIB.SMIB_init.c"
    ;
  data->modelData->modelDataXml.infoXMLData =
  #include "OpenIPSL.Examples.KundurSMIB.SMIB_info.c"
    ;
  #endif /* defined(_MSC_VER) */
  #endif /* defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME) */
  data->modelData->modelDataXml.fileName = "OpenIPSL.Examples.KundurSMIB.SMIB_info.json";
  data->modelData->resourcesDir = NULL;
  data->modelData->runTestsuite = 0;
  data->modelData->nStatesArray = 6;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesRealArray = 77;
  data->modelData->nVariablesIntegerArray = 0;
  data->modelData->nVariablesBooleanArray = 0;
  data->modelData->nVariablesStringArray = 0;
  data->modelData->nParametersRealArray = 133;
  data->modelData->nParametersIntegerArray = 2;
  data->modelData->nParametersBooleanArray = 59;
  data->modelData->nParametersStringArray = 0;
  data->modelData->nParametersReal = 133;
  data->modelData->nParametersInteger = 2;
  data->modelData->nParametersBoolean = 59;
  data->modelData->nParametersString = 0;
  data->modelData->nAliasRealArray = 52;
  data->modelData->nAliasIntegerArray = 0;
  data->modelData->nAliasBooleanArray = 0;
  data->modelData->nAliasStringArray = 0;
  data->modelData->nInputVars = 0;
  data->modelData->nOutputVars = 0;
  data->modelData->nZeroCrossings = 9;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 6;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 3;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 331;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 6;
  data->modelData->nNonLinearSystems = 0;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 8;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  data->modelData->nDelayExpressions = 0;
  data->modelData->nBaseClocks = 0;
  data->modelData->nSpatialDistributions = 0;
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
  data->modelData->nSetcVars = 0;
  data->modelData->ndataReconVars = 0;
  data->modelData->nSetbVars = 0;
  data->modelData->nRelatedBoundaryConditions = 0;
  data->modelData->linearizationDumpLanguage = OMC_LINEARIZE_DUMP_LANGUAGE_MODELICA;
}

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}


#if defined(__MINGW32__) || defined(_MSC_VER)

#if !defined(_UNICODE)
#define _UNICODE
#endif
#if !defined(UNICODE)
#define UNICODE
#endif

#include <windows.h>
char** omc_fixWindowsArgv(int argc, wchar_t **wargv)
{
  char** newargv;
  /* Support for non-ASCII characters
  * Read the unicode command line arguments and translate it to char*
  */
  newargv = (char**)malloc(argc*sizeof(char*));
  for (int i = 0; i < argc; i++) {
    newargv[i] = omc_wchar_to_multibyte_str(wargv[i]);
  }
  return newargv;
}

#define OMC_MAIN wmain
#define OMC_CHAR wchar_t
#define OMC_EXPORT __declspec(dllexport) extern

#else
#define omc_fixWindowsArgv(N, A) (A)
#define OMC_MAIN main
#define OMC_CHAR char
#define OMC_EXPORT extern
#endif

#if defined(threadData)
#undef threadData
#endif
/* call the simulation runtime main from our main! */
#if defined(OMC_DLL_MAIN_DEFINE)
OMC_EXPORT int omcDllMain(int argc, OMC_CHAR **argv)
#else
int OMC_MAIN(int argc, OMC_CHAR** argv)
#endif
{
  char** newargv = omc_fixWindowsArgv(argc, argv);
  /*
    Set the error functions to be used for simulation.
    The default value for them is 'functions' version. Change it here to 'simulation' versions
  */
  omc_assert = omc_assert_simulation;
  omc_assert_withEquationIndexes = omc_assert_simulation_withEquationIndexes;

  omc_assert_warning_withEquationIndexes = omc_assert_warning_simulation_withEquationIndexes;
  omc_assert_warning = omc_assert_warning_simulation;
  omc_terminate = omc_terminate_simulation;
  omc_throw = omc_throw_simulation;

  int res;
  DATA data;
  MODEL_DATA modelData;
  SIMULATION_INFO simInfo;
  data.modelData = &modelData;
  data.simulationInfo = &simInfo;
  measure_time_flag = 0;
  compiledInDAEMode = 0;
  compiledWithSymSolver = 0;
  MMC_INIT(0);
  omc_alloc_interface.init();
  {
    MMC_TRY_TOP()
  
    MMC_TRY_STACK()
  
    OpenIPSL_Examples_KundurSMIB_SMIB_setupDataStruc(&data, threadData);
    res = _main_initRuntimeAndSimulation(argc, newargv, &data, threadData);
    if(res == 0) {
      if (omc_flag[FLAG_MOO_OPTIMIZATION]) {
        res = _main_OptimizationRuntime(argc, newargv, &data, threadData);
      } else {
        res = _main_SimulationRuntime(argc, newargv, &data, threadData);
      }
    }
    
    MMC_ELSE()
    rml_execution_failed();
    fprintf(stderr, "Stack overflow detected and was not caught.\nSend us a bug report at https://trac.openmodelica.org/OpenModelica/newticket\n    Include the following trace:\n");
    printStacktraceMessages();
    fflush(NULL);
    return 1;
    MMC_CATCH_STACK()
    
    MMC_CATCH_TOP(return rml_execution_failed());
  }

  fflush(NULL);
  return res;
}

#ifdef __cplusplus
}
#endif


