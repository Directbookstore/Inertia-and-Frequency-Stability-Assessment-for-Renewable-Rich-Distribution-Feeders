/* Mixed Systems */
#include "ThesisFreqCases.BaseCase_model.h"
#include "ThesisFreqCases.BaseCase_11mix.h"
/* initial mixed systems */
/* initial_lambda0 mixed systems */
/* parameter mixed systems */
/* model mixed systems */
/* jacobians mixed systems */

