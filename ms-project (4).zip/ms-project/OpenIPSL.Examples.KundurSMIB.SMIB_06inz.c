/* Initialization */
#include "OpenIPSL.Examples.KundurSMIB.SMIB_model.h"
#include "OpenIPSL.Examples.KundurSMIB.SMIB_11mix.h"
#include "OpenIPSL.Examples.KundurSMIB.SMIB_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void OpenIPSL_Examples_KundurSMIB_SMIB_functionInitialEquations_0(DATA *data, threadData_t *threadData);

/*
equation index: 1
type: SIMPLE_ASSIGN
G1.machine.Vt0.re = G1.machine.v_0 * cos(G1.machine.angle_0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_1(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,1};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[54]] /* G1.machine.Vt0.re PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[71]] /* G1.machine.v_0 PARAM */)) * (cos((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[56]] /* G1.machine.angle_0 PARAM */)));
  threadData->lastEquationSolved = 1;
}

/*
equation index: 2
type: SIMPLE_ASSIGN
G1.machine.Vt0.im = G1.machine.v_0 * sin(G1.machine.angle_0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_2(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,2};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[53]] /* G1.machine.Vt0.im PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[71]] /* G1.machine.v_0 PARAM */)) * (sin((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[56]] /* G1.machine.angle_0 PARAM */)));
  threadData->lastEquationSolved = 2;
}

/*
equation index: 3
type: SIMPLE_ASSIGN
G1.machine.I0.im = (G1.machine.S0.im * G1.machine.Vt0.re + G1.machine.S0.re * G1.machine.Vt0.im) / (G1.machine.Vt0.re ^ 2.0 + G1.machine.Vt0.im ^ 2.0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_3(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,3};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[54]] /* G1.machine.Vt0.re PARAM */);
  tmp1 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[53]] /* G1.machine.Vt0.im PARAM */);
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[28]] /* G1.machine.I0.im PARAM */) = DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[38]] /* G1.machine.S0.im PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[54]] /* G1.machine.Vt0.re PARAM */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[39]] /* G1.machine.S0.re PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[53]] /* G1.machine.Vt0.im PARAM */)),(tmp0 * tmp0) + (tmp1 * tmp1),"G1.machine.Vt0.re ^ 2.0 + G1.machine.Vt0.im ^ 2.0",equationIndexes);
  threadData->lastEquationSolved = 3;
}

/*
equation index: 4
type: SIMPLE_ASSIGN
G1.machine.I0.re = (G1.machine.S0.re * G1.machine.Vt0.re - G1.machine.S0.im * G1.machine.Vt0.im) / (G1.machine.Vt0.re ^ 2.0 + G1.machine.Vt0.im ^ 2.0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_4(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,4};
  modelica_real tmp2;
  modelica_real tmp3;
  tmp2 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[54]] /* G1.machine.Vt0.re PARAM */);
  tmp3 = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[53]] /* G1.machine.Vt0.im PARAM */);
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[29]] /* G1.machine.I0.re PARAM */) = DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[39]] /* G1.machine.S0.re PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[54]] /* G1.machine.Vt0.re PARAM */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[38]] /* G1.machine.S0.im PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[53]] /* G1.machine.Vt0.im PARAM */))),(tmp2 * tmp2) + (tmp3 * tmp3),"G1.machine.Vt0.re ^ 2.0 + G1.machine.Vt0.im ^ 2.0",equationIndexes);
  threadData->lastEquationSolved = 4;
}

/*
equation index: 5
type: SIMPLE_ASSIGN
infinite_bus.p.vr = infinite_bus.v_0 * cos(infinite_bus.angle_0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_5(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,5};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[99]] /* infinite_bus.v_0 PARAM */)) * (cos((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[97]] /* infinite_bus.angle_0 PARAM */)));
  threadData->lastEquationSolved = 5;
}

/*
equation index: 6
type: SIMPLE_ASSIGN
infinite_bus.p.vi = infinite_bus.v_0 * sin(infinite_bus.angle_0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_6(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,6};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[99]] /* infinite_bus.v_0 PARAM */)) * (sin((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[97]] /* infinite_bus.angle_0 PARAM */)));
  threadData->lastEquationSolved = 6;
}

/*
equation index: 7
type: SIMPLE_ASSIGN
B3.v = sqrt(infinite_bus.p.vr ^ 2.0 + infinite_bus.p.vi ^ 2.0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_7(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,7};
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  tmp4 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */);
  tmp5 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */);
  tmp6 = (tmp4 * tmp4) + (tmp5 * tmp5);
  if(!(tmp6 >= 0.0))
  {
    if (data->simulationInfo->noThrowAsserts) {
      FILE_INFO info = {"",0,0,0,0,0};
      infoStreamPrintWithEquationIndexes(OMC_LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
      data->simulationInfo->needToReThrow = 1;
    } else {
      FILE_INFO info = {"",0,0,0,0,0};
      omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
      throwStreamPrintWithEquationIndexes(threadData, info, equationIndexes, "Model error: Argument of sqrt(infinite_bus.p.vr ^ 2.0 + infinite_bus.p.vi ^ 2.0) was %g should be >= 0", tmp6);
    }
  }
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[28]] /* B3.v variable */) = sqrt(tmp6);
  threadData->lastEquationSolved = 7;
}

/*
equation index: 8
type: SIMPLE_ASSIGN
B3.angle = atan2(infinite_bus.p.vi, infinite_bus.p.vr)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_8(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,8};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[24]] /* B3.angle variable */) = atan2((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[47]] /* infinite_bus.p.vi variable */), (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[48]] /* infinite_bus.p.vr variable */));
  threadData->lastEquationSolved = 8;
}

/*
equation index: 9
type: SIMPLE_ASSIGN
B3.angleDisplay = 57.29577951308232 * B3.angle
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_9(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,9};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[25]] /* B3.angleDisplay variable */) = (57.29577951308232) * ((data->localData[0]->realVars[data->simulationInfo->realVarsIndex[24]] /* B3.angle variable */));
  threadData->lastEquationSolved = 9;
}

/*
equation index: 10
type: SIMPLE_ASSIGN
G1.machine.vr0 = G1.machine.Vt0.re
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_10(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,10};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[76]] /* G1.machine.vr0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[54]] /* G1.machine.Vt0.re PARAM */);
  threadData->lastEquationSolved = 10;
}

/*
equation index: 11
type: SIMPLE_ASSIGN
G1.machine.vi0 = G1.machine.Vt0.im
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_11(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,11};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[74]] /* G1.machine.vi0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[53]] /* G1.machine.Vt0.im PARAM */);
  threadData->lastEquationSolved = 11;
}

/*
equation index: 12
type: SIMPLE_ASSIGN
G1.machine.ir0 = -G1.machine.I0.re
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_12(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,12};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[66]] /* G1.machine.ir0 PARAM */) = (-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[29]] /* G1.machine.I0.re PARAM */));
  threadData->lastEquationSolved = 12;
}

/*
equation index: 13
type: SIMPLE_ASSIGN
G1.machine.ii0 = -G1.machine.I0.im
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_13(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,13};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[64]] /* G1.machine.ii0 PARAM */) = (-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[28]] /* G1.machine.I0.im PARAM */));
  threadData->lastEquationSolved = 13;
}

/*
equation index: 14
type: SIMPLE_ASSIGN
G1.machine.delta0 = Modelica.Math.atan3(G1.machine.Vt0.im + (G1.machine.ra * G1.machine.I0.im + G1.machine.xq0 * G1.machine.I0.re) * G1.machine.Z_MBtoSB, G1.machine.Vt0.re + (G1.machine.ra * G1.machine.I0.re - G1.machine.xq0 * G1.machine.I0.im) * G1.machine.Z_MBtoSB, 0.0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_14(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,14};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[57]] /* G1.machine.delta0 PARAM */) = omc_Modelica_Math_atan3(threadData, (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[53]] /* G1.machine.Vt0.im PARAM */) + (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[28]] /* G1.machine.I0.im PARAM */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[84]] /* G1.machine.xq0 PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[29]] /* G1.machine.I0.re PARAM */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[55]] /* G1.machine.Z_MBtoSB PARAM */)), (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[54]] /* G1.machine.Vt0.re PARAM */) + (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[29]] /* G1.machine.I0.re PARAM */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[84]] /* G1.machine.xq0 PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[28]] /* G1.machine.I0.im PARAM */)))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[55]] /* G1.machine.Z_MBtoSB PARAM */)), 0.0);
  threadData->lastEquationSolved = 14;
}

/*
equation index: 15
type: SIMPLE_ASSIGN
G1.machine.Vdq0.im = G1.machine.Vt0.re * sin(1.5707963267948966 - G1.machine.delta0) / G1.machine.V_MBtoSB + G1.machine.Vt0.im * cos(1.5707963267948966 - G1.machine.delta0) / G1.machine.V_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_15(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,15};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[50]] /* G1.machine.Vdq0.im PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[54]] /* G1.machine.Vt0.re PARAM */)) * (DIVISION_SIM(sin(1.5707963267948966 - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[57]] /* G1.machine.delta0 PARAM */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */),"G1.machine.V_MBtoSB",equationIndexes)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[53]] /* G1.machine.Vt0.im PARAM */)) * (DIVISION_SIM(cos(1.5707963267948966 - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[57]] /* G1.machine.delta0 PARAM */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */),"G1.machine.V_MBtoSB",equationIndexes));
  threadData->lastEquationSolved = 15;
}

/*
equation index: 16
type: SIMPLE_ASSIGN
G1.machine.Vdq0.re = G1.machine.Vt0.re * cos(1.5707963267948966 - G1.machine.delta0) / G1.machine.V_MBtoSB - G1.machine.Vt0.im * sin(1.5707963267948966 - G1.machine.delta0) / G1.machine.V_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_16(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,16};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[51]] /* G1.machine.Vdq0.re PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[54]] /* G1.machine.Vt0.re PARAM */)) * (DIVISION_SIM(cos(1.5707963267948966 - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[57]] /* G1.machine.delta0 PARAM */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */),"G1.machine.V_MBtoSB",equationIndexes)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[53]] /* G1.machine.Vt0.im PARAM */)) * (DIVISION_SIM(sin(1.5707963267948966 - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[57]] /* G1.machine.delta0 PARAM */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */),"G1.machine.V_MBtoSB",equationIndexes)));
  threadData->lastEquationSolved = 16;
}

/*
equation index: 17
type: SIMPLE_ASSIGN
G1.machine.Idq0.im = G1.machine.I0.re * sin(1.5707963267948966 - G1.machine.delta0) / G1.machine.I_MBtoSB + G1.machine.I0.im * cos(1.5707963267948966 - G1.machine.delta0) / G1.machine.I_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_17(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,17};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[31]] /* G1.machine.Idq0.im PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[29]] /* G1.machine.I0.re PARAM */)) * (DIVISION_SIM(sin(1.5707963267948966 - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[57]] /* G1.machine.delta0 PARAM */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */),"G1.machine.I_MBtoSB",equationIndexes)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[28]] /* G1.machine.I0.im PARAM */)) * (DIVISION_SIM(cos(1.5707963267948966 - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[57]] /* G1.machine.delta0 PARAM */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */),"G1.machine.I_MBtoSB",equationIndexes));
  threadData->lastEquationSolved = 17;
}

/*
equation index: 18
type: SIMPLE_ASSIGN
G1.machine.Idq0.re = G1.machine.I0.re * cos(1.5707963267948966 - G1.machine.delta0) / G1.machine.I_MBtoSB - G1.machine.I0.im * sin(1.5707963267948966 - G1.machine.delta0) / G1.machine.I_MBtoSB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_18(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,18};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[32]] /* G1.machine.Idq0.re PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[29]] /* G1.machine.I0.re PARAM */)) * (DIVISION_SIM(cos(1.5707963267948966 - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[57]] /* G1.machine.delta0 PARAM */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */),"G1.machine.I_MBtoSB",equationIndexes)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[28]] /* G1.machine.I0.im PARAM */)) * (DIVISION_SIM(sin(1.5707963267948966 - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[57]] /* G1.machine.delta0 PARAM */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[30]] /* G1.machine.I_MBtoSB PARAM */),"G1.machine.I_MBtoSB",equationIndexes)));
  threadData->lastEquationSolved = 18;
}

/*
equation index: 19
type: SIMPLE_ASSIGN
G1.machine.vd0 = G1.machine.Vdq0.re
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_19(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,19};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[72]] /* G1.machine.vd0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[51]] /* G1.machine.Vdq0.re PARAM */);
  threadData->lastEquationSolved = 19;
}

/*
equation index: 20
type: SIMPLE_ASSIGN
G1.machine.iq0 = G1.machine.Idq0.im
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_20(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,20};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[65]] /* G1.machine.iq0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[31]] /* G1.machine.Idq0.im PARAM */);
  threadData->lastEquationSolved = 20;
}

/*
equation index: 21
type: SIMPLE_ASSIGN
G1.machine.e1d0 = (G1.machine.xq + (-G1.machine.x1q) - G1.machine.T2q0 * G1.machine.x2q * (G1.machine.xq - G1.machine.x1q) / (G1.machine.x1q * G1.machine.T1q0)) * G1.machine.iq0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_21(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,21};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[58]] /* G1.machine.e1d0 PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */) + (-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[46]] /* G1.machine.T2q0 PARAM */)) * (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[83]] /* G1.machine.xq PARAM */) - (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */),((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[79]] /* G1.machine.x1q PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[44]] /* G1.machine.T1q0 PARAM */)),"G1.machine.x1q * G1.machine.T1q0",equationIndexes))))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[65]] /* G1.machine.iq0 PARAM */));
  threadData->lastEquationSolved = 21;
}

/*
equation index: 22
type: SIMPLE_ASSIGN
G1.machine.vq0 = G1.machine.Vdq0.im
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_22(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,22};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[75]] /* G1.machine.vq0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[50]] /* G1.machine.Vdq0.im PARAM */);
  threadData->lastEquationSolved = 22;
}

/*
equation index: 23
type: SIMPLE_ASSIGN
G1.machine.id0 = G1.machine.Idq0.re
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_23(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,23};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[63]] /* G1.machine.id0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[32]] /* G1.machine.Idq0.re PARAM */);
  threadData->lastEquationSolved = 23;
}

/*
equation index: 24
type: SIMPLE_ASSIGN
G1.machine.e2q0 = G1.machine.vq0 + G1.machine.ra * G1.machine.iq0 + G1.machine.x2d * G1.machine.id0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_24(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,24};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[61]] /* G1.machine.e2q0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[75]] /* G1.machine.vq0 PARAM */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[65]] /* G1.machine.iq0 PARAM */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[80]] /* G1.machine.x2d PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[63]] /* G1.machine.id0 PARAM */));
  threadData->lastEquationSolved = 24;
}

/*
equation index: 25
type: SIMPLE_ASSIGN
G1.machine.e1q0 = G1.machine.e2q0 + G1.machine.K2 * G1.machine.id0 - G1.machine.Taa * ((G1.machine.K1 + G1.machine.K2) * G1.machine.id0 + G1.machine.e2q0) / G1.machine.T1d0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_25(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,25};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[59]] /* G1.machine.e1q0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[61]] /* G1.machine.e2q0 PARAM */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[34]] /* G1.machine.K2 PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[63]] /* G1.machine.id0 PARAM */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[47]] /* G1.machine.Taa PARAM */)) * (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[33]] /* G1.machine.K1 PARAM */) + (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[34]] /* G1.machine.K2 PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[63]] /* G1.machine.id0 PARAM */)) + (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[61]] /* G1.machine.e2q0 PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[43]] /* G1.machine.T1d0 PARAM */),"G1.machine.T1d0",equationIndexes)));
  threadData->lastEquationSolved = 25;
}

/*
equation index: 26
type: SIMPLE_ASSIGN
G1.machine.vf00 = G1.machine.V_MBtoSB * (G1.machine.K1 * G1.machine.id0 + G1.machine.e1q0) / (1.0 - G1.machine.Taa / G1.machine.T1d0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_26(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,26};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[73]] /* G1.machine.vf00 PARAM */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[48]] /* G1.machine.V_MBtoSB PARAM */)) * (DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[33]] /* G1.machine.K1 PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[63]] /* G1.machine.id0 PARAM */)) + (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[59]] /* G1.machine.e1q0 PARAM */),1.0 - (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[47]] /* G1.machine.Taa PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[43]] /* G1.machine.T1d0 PARAM */),"G1.machine.T1d0",equationIndexes)),"1.0 - G1.machine.Taa / G1.machine.T1d0",equationIndexes));
  threadData->lastEquationSolved = 26;
}

/*
equation index: 27
type: SIMPLE_ASSIGN
G1.machine.vf_MB = G1.machine.vf00 * G1.machine.V_b / G1.machine.Vn
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_27(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,27};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[39]] /* G1.machine.vf_MB variable */) = ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[73]] /* G1.machine.vf00 PARAM */)) * (DIVISION_SIM((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[49]] /* G1.machine.V_b PARAM */),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[52]] /* G1.machine.Vn PARAM */),"G1.machine.Vn",equationIndexes));
  threadData->lastEquationSolved = 27;
}

/*
equation index: 28
type: SIMPLE_ASSIGN
G1.machine.e2d0 = G1.machine.vd0 + G1.machine.ra * G1.machine.id0 - G1.machine.x2q * G1.machine.iq0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_28(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,28};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[60]] /* G1.machine.e2d0 PARAM */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[72]] /* G1.machine.vd0 PARAM */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[63]] /* G1.machine.id0 PARAM */)) - (((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[81]] /* G1.machine.x2q PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[65]] /* G1.machine.iq0 PARAM */)));
  threadData->lastEquationSolved = 28;
}

/*
equation index: 29
type: SIMPLE_ASSIGN
G1.machine.pm00 = ((G1.machine.vq0 + G1.machine.ra * G1.machine.iq0) * G1.machine.iq0 + (G1.machine.vd0 + G1.machine.ra * G1.machine.id0) * G1.machine.id0) / G1.machine.S_SBtoMB
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_29(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,29};
  (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[68]] /* G1.machine.pm00 PARAM */) = DIVISION_SIM(((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[75]] /* G1.machine.vq0 PARAM */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[65]] /* G1.machine.iq0 PARAM */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[65]] /* G1.machine.iq0 PARAM */)) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[72]] /* G1.machine.vd0 PARAM */) + ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[70]] /* G1.machine.ra PARAM */)) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[63]] /* G1.machine.id0 PARAM */))) * ((data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[63]] /* G1.machine.id0 PARAM */)),(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[40]] /* G1.machine.S_SBtoMB PARAM */),"G1.machine.S_SBtoMB",equationIndexes);
  threadData->lastEquationSolved = 29;
}

/*
equation index: 30
type: SIMPLE_ASSIGN
$START.transformer.is.re = -G1.machine.ir0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_30(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,30};
  ((modelica_real *)((data->modelData->realVarsData[74] /* transformer.is.re variable */).attribute .start.data))[0] = (-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[66]] /* G1.machine.ir0 PARAM */));
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */) = ((modelica_real *)((data->modelData->realVarsData[74] /* transformer.is.re variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[74].info /* transformer.is.re */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[74]] /* transformer.is.re variable */));
  threadData->lastEquationSolved = 30;
}

/*
equation index: 31
type: SIMPLE_ASSIGN
$START.transformer.is.im = -G1.machine.ii0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_31(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,31};
  ((modelica_real *)((data->modelData->realVarsData[73] /* transformer.is.im variable */).attribute .start.data))[0] = (-(data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[64]] /* G1.machine.ii0 PARAM */));
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */) = ((modelica_real *)((data->modelData->realVarsData[73] /* transformer.is.im variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[73].info /* transformer.is.im */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[73]] /* transformer.is.im variable */));
  threadData->lastEquationSolved = 31;
}

/*
equation index: 32
type: SIMPLE_ASSIGN
$START.G1.machine.delta = G1.machine.delta0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_32(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,32};
  ((modelica_real *)((data->modelData->realVarsData[0] /* G1.machine.delta STATE(1) */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[57]] /* G1.machine.delta0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */) = ((modelica_real *)((data->modelData->realVarsData[0] /* G1.machine.delta STATE(1) */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[0].info /* G1.machine.delta */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */));
  threadData->lastEquationSolved = 32;
}

/*
equation index: 33
type: SIMPLE_ASSIGN
G1.machine.delta = $START.G1.machine.delta
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_33(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,33};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[0]] /* G1.machine.delta STATE(1) */) = ((modelica_real *)((data->modelData->realVarsData[0] /* G1.machine.delta STATE(1) */).attribute .start.data))[0];
  threadData->lastEquationSolved = 33;
}

/*
equation index: 34
type: SIMPLE_ASSIGN
$START.G1.machine.vd = G1.machine.vd0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_34(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,34};
  ((modelica_real *)((data->modelData->realVarsData[38] /* G1.machine.vd variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[72]] /* G1.machine.vd0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[38]] /* G1.machine.vd variable */) = ((modelica_real *)((data->modelData->realVarsData[38] /* G1.machine.vd variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[38].info /* G1.machine.vd */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[38]] /* G1.machine.vd variable */));
  threadData->lastEquationSolved = 34;
}

/*
equation index: 35
type: SIMPLE_ASSIGN
$START.G1.machine.vq = G1.machine.vq0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_35(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,35};
  ((modelica_real *)((data->modelData->realVarsData[40] /* G1.machine.vq variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[75]] /* G1.machine.vq0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[40]] /* G1.machine.vq variable */) = ((modelica_real *)((data->modelData->realVarsData[40] /* G1.machine.vq variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[40].info /* G1.machine.vq */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[40]] /* G1.machine.vq variable */));
  threadData->lastEquationSolved = 35;
}

/*
equation index: 36
type: SIMPLE_ASSIGN
$START.G1.machine.id = G1.machine.id0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_36(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,36};
  ((modelica_real *)((data->modelData->realVarsData[34] /* G1.machine.id variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[63]] /* G1.machine.id0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */) = ((modelica_real *)((data->modelData->realVarsData[34] /* G1.machine.id variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[34].info /* G1.machine.id */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */));
  threadData->lastEquationSolved = 36;
}

/*
equation index: 37
type: SIMPLE_ASSIGN
$START.G1.machine.iq = G1.machine.iq0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_37(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,37};
  ((modelica_real *)((data->modelData->realVarsData[35] /* G1.machine.iq variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[65]] /* G1.machine.iq0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */) = ((modelica_real *)((data->modelData->realVarsData[35] /* G1.machine.iq variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[35].info /* G1.machine.iq */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */));
  threadData->lastEquationSolved = 37;
}

/*
equation index: 38
type: SIMPLE_ASSIGN
$START.G1.machine.pe = G1.machine.pm00
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_38(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,38};
  ((modelica_real *)((data->modelData->realVarsData[36] /* G1.machine.pe variable */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[68]] /* G1.machine.pm00 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[36]] /* G1.machine.pe variable */) = ((modelica_real *)((data->modelData->realVarsData[36] /* G1.machine.pe variable */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[36].info /* G1.machine.pe */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[36]] /* G1.machine.pe variable */));
  threadData->lastEquationSolved = 38;
}

/*
equation index: 39
type: SIMPLE_ASSIGN
$START.G1.machine.e1q = G1.machine.e1q0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_39(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,39};
  ((modelica_real *)((data->modelData->realVarsData[2] /* G1.machine.e1q STATE(1) */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[59]] /* G1.machine.e1q0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* G1.machine.e1q STATE(1) */) = ((modelica_real *)((data->modelData->realVarsData[2] /* G1.machine.e1q STATE(1) */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[2].info /* G1.machine.e1q */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* G1.machine.e1q STATE(1) */));
  threadData->lastEquationSolved = 39;
}

/*
equation index: 40
type: SIMPLE_ASSIGN
G1.machine.e1q = G1.machine.e1q0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_40(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,40};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[2]] /* G1.machine.e1q STATE(1) */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[59]] /* G1.machine.e1q0 PARAM */);
  threadData->lastEquationSolved = 40;
}

/*
equation index: 41
type: SIMPLE_ASSIGN
$START.G1.machine.e1d = G1.machine.e1d0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_41(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,41};
  ((modelica_real *)((data->modelData->realVarsData[1] /* G1.machine.e1d STATE(1) */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[58]] /* G1.machine.e1d0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[1]] /* G1.machine.e1d STATE(1) */) = ((modelica_real *)((data->modelData->realVarsData[1] /* G1.machine.e1d STATE(1) */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[1].info /* G1.machine.e1d */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[1]] /* G1.machine.e1d STATE(1) */));
  threadData->lastEquationSolved = 41;
}

/*
equation index: 42
type: SIMPLE_ASSIGN
$START.G1.machine.e2q = G1.machine.e2q0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_42(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,42};
  ((modelica_real *)((data->modelData->realVarsData[4] /* G1.machine.e2q STATE(1) */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[61]] /* G1.machine.e2q0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[4]] /* G1.machine.e2q STATE(1) */) = ((modelica_real *)((data->modelData->realVarsData[4] /* G1.machine.e2q STATE(1) */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[4].info /* G1.machine.e2q */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[4]] /* G1.machine.e2q STATE(1) */));
  threadData->lastEquationSolved = 42;
}

/*
equation index: 43
type: SIMPLE_ASSIGN
G1.machine.e2q = G1.machine.e2q0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_43(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,43};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[4]] /* G1.machine.e2q STATE(1) */) = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[61]] /* G1.machine.e2q0 PARAM */);
  threadData->lastEquationSolved = 43;
}

/*
equation index: 44
type: SIMPLE_ASSIGN
$START.G1.machine.e2d = G1.machine.e2d0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_44(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,44};
  ((modelica_real *)((data->modelData->realVarsData[3] /* G1.machine.e2d STATE(1) */).attribute .start.data))[0] = (data->simulationInfo->realParameter[data->simulationInfo->realParamsIndex[60]] /* G1.machine.e2d0 PARAM */);
    (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[3]] /* G1.machine.e2d STATE(1) */) = ((modelica_real *)((data->modelData->realVarsData[3] /* G1.machine.e2d STATE(1) */).attribute .start.data))[0];
    infoStreamPrint(OMC_LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[3].info /* G1.machine.e2d */.name, (modelica_real) (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[3]] /* G1.machine.e2d STATE(1) */));
  threadData->lastEquationSolved = 44;
}

/*
equation index: 45
type: SIMPLE_ASSIGN
$DER.G1.machine.e2d = 0.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_45(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,45};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[9]] /* der(G1.machine.e2d) STATE_DER */) = 0.0;
  threadData->lastEquationSolved = 45;
}

/*
equation index: 46
type: SIMPLE_ASSIGN
$DER.G1.machine.e1d = 0.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_46(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,46};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[7]] /* der(G1.machine.e1d) STATE_DER */) = 0.0;
  threadData->lastEquationSolved = 46;
}

/*
equation index: 89
type: LINEAR

<var>line_1.is.re</var>
<var>line_2.is.re</var>
<var>line_2.is.im</var>
<var>line_1.is.im</var>
<var>transformer.ir.im</var>
<var>G1.machine.id</var>
<var>G1.machine.iq</var>
<row>

</row>
<matrix>
</matrix>
*/
OMC_DISABLE_OPT
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_89(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,89};
  /* Linear equation system */
  int retValue;
  double aux_x[7] = { (data->localData[1]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */) };
  infoStreamPrint(OMC_LOG_DT, 0, "Solving linear system 89 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);

  retValue = solve_linear_system(data, threadData, 0, &aux_x[0]);

  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,89};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving linear system 89 failed at time=%.15g.\nFor more information please use -lv LOG_LS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[56]] /* line_1.is.re variable */) = aux_x[0];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[64]] /* line_2.is.re variable */) = aux_x[1];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[63]] /* line_2.is.im variable */) = aux_x[2];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[55]] /* line_1.is.im variable */) = aux_x[3];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[71]] /* transformer.ir.im variable */) = aux_x[4];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[34]] /* G1.machine.id variable */) = aux_x[5];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[35]] /* G1.machine.iq variable */) = aux_x[6];

  threadData->lastEquationSolved = 89;
}
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_205(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_204(DATA *data, threadData_t *threadData);


/*
equation index: 92
type: LINEAR

<var>line_2.ir.im</var>
<var>line_2.ir.re</var>
<row>
  <cell>if time >= line_2.t1 and time < line_2.t2 then 0.0 else infinite_bus.p.vr - line_2.vs.re - (line_2.Z.re * (infinite_bus.p.vi * line_2.Y.im - infinite_bus.p.vr * line_2.Y.re) - line_2.Z.im * ((-infinite_bus.p.vr) * line_2.Y.im - infinite_bus.p.vi * line_2.Y.re))</cell>
  <cell>if time >= line_2.t1 and time < line_2.t2 then 0.0 else infinite_bus.p.vi - line_2.vs.im - (line_2.Z.re * ((-infinite_bus.p.vr) * line_2.Y.im - infinite_bus.p.vi * line_2.Y.re) + line_2.Z.im * (infinite_bus.p.vi * line_2.Y.im - infinite_bus.p.vr * line_2.Y.re))</cell>
</row>
<matrix>
  <cell row="0" col="0">
    <residual>-(if time >= line_2.t1 and time < line_2.t2 then 0.0 else line_2.Z.im)</residual>
  </cell><cell row="0" col="1">
    <residual>-(if time >= line_2.t1 and time < line_2.t2 then 1.0 else -line_2.Z.re)</residual>
  </cell><cell row="1" col="0">
    <residual>-(if time >= line_2.t1 and time < line_2.t2 then 1.0 else -line_2.Z.re)</residual>
  </cell><cell row="1" col="1">
    <residual>-(if time >= line_2.t1 and time < line_2.t2 then 0.0 else -line_2.Z.im)</residual>
  </cell>
</matrix>
*/
OMC_DISABLE_OPT
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_92(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,92};
  /* Linear equation system */
  int retValue;
  double aux_x[2] = { (data->localData[1]->realVars[data->simulationInfo->realVarsIndex[61]] /* line_2.ir.im variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[62]] /* line_2.ir.re variable */) };
  infoStreamPrint(OMC_LOG_DT, 0, "Solving linear system 92 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);

  retValue = solve_linear_system(data, threadData, 1, &aux_x[0]);

  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,92};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving linear system 92 failed at time=%.15g.\nFor more information please use -lv LOG_LS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[61]] /* line_2.ir.im variable */) = aux_x[0];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[62]] /* line_2.ir.re variable */) = aux_x[1];

  threadData->lastEquationSolved = 92;
}
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_182(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_181(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_184(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_183(DATA *data, threadData_t *threadData);


/*
equation index: 97
type: LINEAR

<var>line_1.ir.re</var>
<var>line_1.ir.im</var>
<row>
  <cell>if time >= line_1.t1 and time < line_1.t2 then 0.0 else infinite_bus.p.vi - line_2.vs.im - (line_1.Z.re * ((-infinite_bus.p.vr) * line_1.Y.im - infinite_bus.p.vi * line_1.Y.re) + line_1.Z.im * (infinite_bus.p.vi * line_1.Y.im - infinite_bus.p.vr * line_1.Y.re))</cell>
  <cell>if time >= line_1.t1 and time < line_1.t2 then 0.0 else infinite_bus.p.vr - line_2.vs.re - (line_1.Z.re * (infinite_bus.p.vi * line_1.Y.im - infinite_bus.p.vr * line_1.Y.re) - line_1.Z.im * ((-infinite_bus.p.vr) * line_1.Y.im - infinite_bus.p.vi * line_1.Y.re))</cell>
</row>
<matrix>
  <cell row="0" col="0">
    <residual>-(if time >= line_1.t1 and time < line_1.t2 then 0.0 else -line_1.Z.im)</residual>
  </cell><cell row="0" col="1">
    <residual>-(if time >= line_1.t1 and time < line_1.t2 then 1.0 else -line_1.Z.re)</residual>
  </cell><cell row="1" col="0">
    <residual>-(if time >= line_1.t1 and time < line_1.t2 then 1.0 else -line_1.Z.re)</residual>
  </cell><cell row="1" col="1">
    <residual>-(if time >= line_1.t1 and time < line_1.t2 then 0.0 else line_1.Z.im)</residual>
  </cell>
</matrix>
*/
OMC_DISABLE_OPT
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_97(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,97};
  /* Linear equation system */
  int retValue;
  double aux_x[2] = { (data->localData[1]->realVars[data->simulationInfo->realVarsIndex[54]] /* line_1.ir.re variable */),(data->localData[1]->realVars[data->simulationInfo->realVarsIndex[53]] /* line_1.ir.im variable */) };
  infoStreamPrint(OMC_LOG_DT, 0, "Solving linear system 97 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);

  retValue = solve_linear_system(data, threadData, 2, &aux_x[0]);

  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,97};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving linear system 97 failed at time=%.15g.\nFor more information please use -lv LOG_LS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[54]] /* line_1.ir.re variable */) = aux_x[0];
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[53]] /* line_1.ir.im variable */) = aux_x[1];

  threadData->lastEquationSolved = 97;
}
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_177(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_175(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_174(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_178(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_180(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_179(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_188(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_187(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_190(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_189(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_201(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_200(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_199(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_198(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_206(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_207(DATA *data, threadData_t *threadData);


/*
equation index: 114
type: SIMPLE_ASSIGN
G1.machine.v = sqrt(transformer.vs.re ^ 2.0 + transformer.vs.im ^ 2.0)
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_114(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,114};
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  tmp7 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[76]] /* transformer.vs.re variable */);
  tmp8 = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[75]] /* transformer.vs.im variable */);
  tmp9 = (tmp7 * tmp7) + (tmp8 * tmp8);
  if(!(tmp9 >= 0.0))
  {
    if (data->simulationInfo->noThrowAsserts) {
      FILE_INFO info = {"",0,0,0,0,0};
      infoStreamPrintWithEquationIndexes(OMC_LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
      data->simulationInfo->needToReThrow = 1;
    } else {
      FILE_INFO info = {"",0,0,0,0,0};
      omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
      throwStreamPrintWithEquationIndexes(threadData, info, equationIndexes, "Model error: Argument of sqrt(transformer.vs.re ^ 2.0 + transformer.vs.im ^ 2.0) was %g should be >= 0", tmp9);
    }
  }
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[37]] /* G1.machine.v variable */) = sqrt(tmp9);
  threadData->lastEquationSolved = 114;
}

/*
equation index: 115
type: SIMPLE_ASSIGN
B1.v = G1.machine.v
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_115(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,115};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[18]] /* B1.v variable */) = (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[37]] /* G1.machine.v variable */);
  threadData->lastEquationSolved = 115;
}
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_197(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_196(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_185(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_186(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_172(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_193(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_194(DATA *data, threadData_t *threadData);

extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_195(DATA *data, threadData_t *threadData);


/*
equation index: 124
type: SIMPLE_ASSIGN
B1.p.ir = 0.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_124(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,124};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[17]] /* B1.p.ir variable */) = 0.0;
  threadData->lastEquationSolved = 124;
}

/*
equation index: 125
type: SIMPLE_ASSIGN
B1.p.ii = 0.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_125(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,125};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[16]] /* B1.p.ii variable */) = 0.0;
  threadData->lastEquationSolved = 125;
}

/*
equation index: 126
type: SIMPLE_ASSIGN
B2.p.ir = 0.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_126(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,126};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[22]] /* B2.p.ir variable */) = 0.0;
  threadData->lastEquationSolved = 126;
}

/*
equation index: 127
type: SIMPLE_ASSIGN
B2.p.ii = 0.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_127(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,127};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[21]] /* B2.p.ii variable */) = 0.0;
  threadData->lastEquationSolved = 127;
}

/*
equation index: 128
type: SIMPLE_ASSIGN
B3.p.ir = 0.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_128(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,128};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[27]] /* B3.p.ir variable */) = 0.0;
  threadData->lastEquationSolved = 128;
}

/*
equation index: 129
type: SIMPLE_ASSIGN
B3.p.ii = 0.0
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_129(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,129};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[26]] /* B3.p.ii variable */) = 0.0;
  threadData->lastEquationSolved = 129;
}

/*
equation index: 130
type: SIMPLE_ASSIGN
G1.machine.w = $START.G1.machine.w
*/
void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_130(DATA *data, threadData_t *threadData)
{
  const int equationIndexes[2] = {1,130};
  (data->localData[0]->realVars[data->simulationInfo->realVarsIndex[5]] /* G1.machine.w STATE(1) */) = ((modelica_real *)((data->modelData->realVarsData[5] /* G1.machine.w STATE(1) */).attribute .start.data))[0];
  threadData->lastEquationSolved = 130;
}
extern void OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_132(DATA *data, threadData_t *threadData);

OMC_DISABLE_OPT
void OpenIPSL_Examples_KundurSMIB_SMIB_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  static void (*const eqFunctions[89])(DATA*, threadData_t*) = {
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_1,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_2,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_3,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_4,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_5,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_6,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_7,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_8,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_9,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_10,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_11,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_12,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_13,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_14,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_15,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_16,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_17,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_18,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_19,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_20,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_21,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_22,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_23,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_24,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_25,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_26,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_27,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_28,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_29,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_30,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_31,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_32,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_33,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_34,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_35,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_36,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_37,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_38,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_39,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_40,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_41,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_42,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_43,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_44,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_45,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_46,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_89,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_205,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_204,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_92,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_182,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_181,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_184,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_183,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_97,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_177,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_175,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_174,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_178,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_180,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_179,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_188,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_187,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_190,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_189,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_201,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_200,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_199,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_198,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_206,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_207,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_114,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_115,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_197,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_196,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_185,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_186,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_172,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_193,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_194,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_195,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_124,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_125,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_126,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_127,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_128,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_129,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_130,
    OpenIPSL_Examples_KundurSMIB_SMIB_eqFunction_132
  };
  
  for (int id = 0; id < 89; id++) {
    eqFunctions[id](data, threadData);
  }
}

int OpenIPSL_Examples_KundurSMIB_SMIB_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  data->simulationInfo->discreteCall = 1;
  OpenIPSL_Examples_KundurSMIB_SMIB_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  return 0;
}

/* No OpenIPSL_Examples_KundurSMIB_SMIB_functionInitialEquations_lambda0 function */

int OpenIPSL_Examples_KundurSMIB_SMIB_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  return 0;
}


#if defined(__cplusplus)
}
#endif
