import re, csv, urllib.request

RAW_URL = "https://raw.githubusercontent.com/MATPOWER/matpower/master/data/case33bw.m"

text = urllib.request.urlopen(RAW_URL).read().decode("utf-8", errors="ignore")

def extract_matrix(varname):
    m = re.search(rf"{re.escape(varname)}\s*=\s*\[(.*?)\];", text, flags=re.S)
    if not m:
        raise RuntimeError(f"Could not find {varname} in case file.")
    block = m.group(1)
    rows = []
    for line in block.splitlines():
        line = line.strip()
        if not line or line.startswith("%"):
            continue
        line = line.split("%")[0].strip()  # strip comments
        nums = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", line)
        if nums:
            rows.append([float(x) for x in nums])
    return rows

bus = extract_matrix("mpc.bus")
branch = extract_matrix("mpc.branch")

# MATPOWER CASEFORMAT explains columns. :contentReference[oaicite:2]{index=2}
# bus: [bus_i, type, Pd, Qd, ...]
# branch: [fbus, tbus, r, x, b, rateA, rateB, rateC, ratio, angle, status, angmin, angmax]

# Make PowerFactory-friendly CSVs
with open("ieee33_loads.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["bus", "P_MW", "Q_MVAr"])
    for row in bus:
        bus_i = int(row[0])
        Pd = float(row[2])
        Qd = float(row[3])
        if Pd != 0.0 or Qd != 0.0:
            w.writerow([bus_i, Pd, Qd])

with open("ieee33_lines.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["from_bus", "to_bus", "R", "X", "length_km"])
    for row in branch:
        fbus = int(row[0])
        tbus = int(row[1])
        r = float(row[2])
        x = float(row[3])
        w.writerow([fbus, tbus, r, x, 1.0])  # use length_km=1.0 so R/X act as total per line

print("Saved: ieee33_loads.csv and ieee33_lines.csv")

# Sanity check: total load should be about 3.715 MW and 2.30 MVAr in the common IEEE-33 dataset. :contentReference[oaicite:3]{index=3}
Ptot = sum(float(r[1]) for r in csv.reader(open("ieee33_loads.csv")) if r and r[0].isdigit())
Qtot = sum(float(r[2]) for r in csv.reader(open("ieee33_loads.csv")) if r and r[0].isdigit())
print("Total load (MW, MVAr):", Ptot, Qtot)
